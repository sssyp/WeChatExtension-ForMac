//
//  PruManerge.h
//  ATNet3.0
//
//  Created by ATBJB10 on 15/9/15.
//  Copyright (c) 2015年 ATBJB10. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PruManerge : NSObject

+(instancetype)sharePruManerge;


//-(NSMutableString*)parserPruXML:(NSString*)key;

-(NSString*)getPrukey:(NSDictionary*)dic;
-(NSString *)getMD5Key:(NSDictionary *)dic;//获取MD5签名
-(NSString *)getTime;//获取时间戳
- (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;


@end
