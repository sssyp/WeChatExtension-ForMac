//
//  WebController.m
//  ATYiYuanWealth
//
//  Created by Itachi on 15/8/6.
//  Copyright (c) 2015年 AT. All rights reserved.
//

#import "WebController.h"
//#import "ATJyJlViewController.h"
//#import "ATWdTzViewController.h"
//#import "ATZqZrViewController.h"
//#import "NewMyAccountViewController.h"
//#import "ZFSQAllOrderDetailViewController.h"
//#import "ZFSQNewAllOrderDetailViewController.h"
//#import <UMShare/UMShare.h>

@interface WebController ()<UIWebViewDelegate>


@property (assign, nonatomic) NSUInteger loadCount;
//进度条
@property (strong, nonatomic) UIProgressView *progressView;

@property (strong, nonatomic) UIButton* refreshButton;

@property (strong, nonatomic) UIImageView* shouYeImage;//首页
@property (strong, nonatomic) UIImageView* touZiImage;//投资
@property (strong, nonatomic) UIImageView* woDeImage;//我的账户
@property (strong, nonatomic) UILabel* shouYeLabel;//首页
@property (strong, nonatomic) UILabel* touZiLabel;//投资
@property (strong, nonatomic) UILabel* woDeLabel;//我的账户


@end

@implementation WebController

@synthesize webView;

- (void)viewDidLoad {
    [super viewDidLoad];
//    [super viewDidLoad];
    self.navigationController.navigationBar.translucent = NO;
    if ([self.tag isEqualToString:@"100"]) {
        self.title = @"账户开户";
    }else if ([self.tag isEqualToString:@"200"]){
        self.title = @"充值";
    }else if ([self.tag isEqualToString:@"300"]){
        self.title = @"提现";
    }else if ([self.tag isEqualToString:@"400"]){
        self.title = @"绑定银行卡";
    }else if ([self.tag isEqualToString:@"500"]){
        self.title = @"公告";
    }else if ([self.tag isEqualToString:@"600"]){
        self.title = @"投资";
    }else if ([self.tag isEqualToString:@"700"]){
        self.title = @"认购";
    }else if ([self.tag isEqualToString:@"800"]){
        self.title = @"关于我们";
    }else if ([self.tag isEqualToString:@"900"]){
        self.title = @"客服电话";
    }else if ([self.tag isEqualToString:@"1000"]){
        self.title = @"最新活动";
    }else if ([self.tag isEqualToString:@"1100"]){
        self.title = @"安全保障";
    }else if ([self.tag isEqualToString:@"505"]){
        self.title = @"支付";
    }
    {
        self.title = @"";
    }

    // 进度条
    UIProgressView *progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 0)];
    progressView.tintColor = [UIColor blueColor];
    progressView.trackTintColor = [UIColor whiteColor];
    [self.view addSubview:progressView];
    self.progressView = progressView;
    
    webView = [[UIWebView alloc] initWithFrame:[UIScreen mainScreen].bounds];
//    webView.contentMode =  UIViewContentModeScaleAspectFill;
    webView.scalesPageToFit = YES;
    webView.userInteractionEnabled = YES;
    webView.allowsInlineMediaPlayback = YES;

    if ([self.tag isEqualToString:@"700"] || [self.tag isEqualToString:@"1000"]) {
           webView.scalesPageToFit = YES;
    }
    if([self.tag isEqualToString:@"100001"]){
        [self.navigationController setNavigationBarHidden:YES];
        webView.frame =CGRectMake(0, 0, ATGetDeviceWidth, ATGetDeviceHeight-44);
        [self setButton];
    }
    
    webView.delegate = self;
//    [self.view addSubview:webView];
    [self.view insertSubview:webView belowSubview:progressView];//把前一个View放在后一个View 的下面
//    [MBProgressHUD showMessage:@"正在加载页面..."];
    [self loadWebView];
    
    if (1) {
        webView.frame = CGRectMake(0, 64+iPhoneX_SPACE_TOP, ATGetDeviceWidth, ATGetDeviceHeight-64);
        
        UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(14,30+iPhoneX_SPACE_TOP,23,23)];
        [self.view addSubview:leftBtn];
        [leftBtn setImage:[UIImage imageNamed:@"icon-back"] forState:UIControlStateNormal];
        [leftBtn addTarget:self action:@selector(didBackAction) forControlEvents:UIControlEventTouchUpInside];
        //    leftBtn.backgroundColor = [UIColor redColor];
        
        UILabel *title = [[UILabel alloc]initWithFrame:CGRectMake(0, 34+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 17)];
        [self.view addSubview:title];
        title.textAlignment = NSTextAlignmentCenter;
        title.font = [UIFont systemFontOfSize:15];
        title.text = @"隐私政策";
    }
    
}
#pragma mark -添加底部按钮-
-(void)didBackAction
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)setButton
{
    
    _shouYeImage = [[UIImageView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/6+0*ATGetDeviceWidth/3 -20, ATGetDeviceHeight-44, 40, 21)];
    _shouYeImage.image = [UIImage imageNamed:@"ico11"];
    [self.view addSubview:_shouYeImage];
    
    _touZiImage = [[UIImageView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/6+1*ATGetDeviceWidth/3 -20, ATGetDeviceHeight-44, 40, 21)];
    _touZiImage.image = [UIImage imageNamed:@"ico44"];
    [self.view addSubview:_touZiImage];
    
    
    _woDeImage = [[UIImageView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/6+2*ATGetDeviceWidth/3 -20, ATGetDeviceHeight-44, 40, 21)];
    _woDeImage.image = [UIImage imageNamed:@"ico66"];
    [self.view addSubview:_woDeImage];
    
    _shouYeLabel = [[UILabel alloc]initWithFrame:CGRectMake(0*ATGetDeviceWidth/3, ATGetDeviceHeight-20, ATGetDeviceWidth/3, 15)];
    _shouYeLabel.font = [UIFont systemFontOfSize:12];
    _shouYeLabel.textAlignment = NSTextAlignmentCenter;
    _shouYeLabel.text = @"首页";
    _shouYeLabel.textColor = GetColor1;
    [self.view addSubview:_shouYeLabel];
    
    
    _touZiLabel = [[UILabel alloc]initWithFrame:CGRectMake(1*ATGetDeviceWidth/3, ATGetDeviceHeight-20, ATGetDeviceWidth/3, 15)];
    _touZiLabel.font = [UIFont systemFontOfSize:12];
    _touZiLabel.textAlignment = NSTextAlignmentCenter;
    _touZiLabel.text = @"我要投资";
    _touZiLabel.textColor = rgba(145, 145, 145, 1);
    [self.view addSubview:_touZiLabel];
    
    
    _woDeLabel= [[UILabel alloc]initWithFrame:CGRectMake(2*ATGetDeviceWidth/3, ATGetDeviceHeight-20, ATGetDeviceWidth/3, 15)];
    _woDeLabel.font = [UIFont systemFontOfSize:12];
    _woDeLabel.textAlignment = NSTextAlignmentCenter;
    _woDeLabel.text = @"我的账户";
    _woDeLabel.textColor = rgba(145, 145, 145, 1);
    [self.view addSubview:_woDeLabel];
    
    for (int i =0; i<3; i++) {
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(i*ATGetDeviceWidth/3, ATGetDeviceHeight-44, ATGetDeviceWidth/3, 44)];
        btn.tag = i;
        [btn addTarget:self action:@selector(didBtn:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
        
    }
}
-(void)didBtn:(UIButton *)btn
{
    switch (btn.tag) {
        case 0:
            _shouYeLabel.textColor = GetColor1;
            _shouYeImage.image = [UIImage imageNamed:@"ico11"];
            _touZiLabel.textColor = rgba(145, 145, 145, 1);
            _touZiImage.image = [UIImage imageNamed:@"ico44"];
            _woDeLabel.textColor = rgba(145, 145, 145, 1);
            _woDeImage.image = [UIImage imageNamed:@"ico66"];
            break;
        case 1:
            _shouYeLabel.textColor =rgba(145, 145, 145, 1);
            _shouYeImage.image = [UIImage imageNamed:@"ico22"];
            _touZiLabel.textColor = GetColor1;
            _touZiImage.image = [UIImage imageNamed:@"ico33"];
            _woDeLabel.textColor = rgba(145, 145, 145, 1);
            _woDeImage.image = [UIImage imageNamed:@"ico66"];
            break;
        default:
            _shouYeLabel.textColor = rgba(145, 145, 145, 1);
            _shouYeImage.image = [UIImage imageNamed:@"ico22"];
            _touZiLabel.textColor = rgba(145, 145, 145, 1);
            _touZiImage.image = [UIImage imageNamed:@"ico44"];
            _woDeLabel.textColor = GetColor1;
            _woDeImage.image = [UIImage imageNamed:@"ico55"];
            break;
    }
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;

//    [MBProgressHUD showMessage:@"正在加载页面..."];
//    [self loadWebView];
}

// 计算webView进度条
- (void)setLoadCount:(NSUInteger)loadCount {
    _loadCount = loadCount;
    if (loadCount == 0) {
        self.progressView.hidden = YES;
        [self.progressView setProgress:0 animated:NO];
    }else {
        self.progressView.hidden = NO;
        CGFloat oldP = self.progressView.progress;
        CGFloat newP = (1.0 - oldP) / (loadCount + 1) + oldP;
        if (newP > 0.95) {
            newP = 0.95;
        }
        [self.progressView setProgress:newP animated:YES];
    }
}


- (void)webViewDidStartLoad:(UIWebView *)webView {
    self.loadCount ++;
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
//    [self.view addSubview:[self refreshButton]];
    self.loadCount --;
}

-(UIButton* )refreshButton{
    if (_refreshButton==nil) {
        UIButton* refreshButton1=[UIButton buttonWithType:UIButtonTypeCustom];
        refreshButton1.center=CGPointMake(ATGetDeviceWidth/2.0, ATGetDeviceHeight/2.0-100);
        refreshButton1.bounds=CGRectMake(0, 0, 200, 50);
        [refreshButton1 setTitle:@"加载失败,点击刷新!" forState:UIControlStateNormal];
        [refreshButton1 addTarget:self action:@selector(investBtnClick) forControlEvents:UIControlEventTouchUpInside];
        refreshButton1.backgroundColor=GetYellewColor;
        refreshButton1.layer.masksToBounds=YES;
        refreshButton1.layer.cornerRadius=4;
        _refreshButton=refreshButton1;
    }
    return _refreshButton;
    
}

-(void)investBtnClick
{
    
    [self loadWebView];
    [self.refreshButton removeFromSuperview];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
//    [MBProgressHUD hideHUD];
    //    2、都有效果
//    NSString *js=@"var script = document.createElement('script');"
//    "script.type = 'text/javascript';"
//    "script.text = \"function ResizeImages() { "
//    "var myimg,oldwidth;"
//    "var maxwidth = %f;"
//    "for(i=0;i <document.images.length;i++){"
//    "myimg = document.images[i];"
//    "if(myimg.width > maxwidth){"
//    "oldwidth = myimg.width;"
//    "myimg.width = %f;"
//    "}"
//    "}"
//    "}\";"
//    "document.getElementsByTagName('head')[0].appendChild(script);";
//    js=[NSString stringWithFormat:js,[UIScreen mainScreen].bounds.size.width,[UIScreen mainScreen].bounds.size.width-15];
//    [webView stringByEvaluatingJavaScriptFromString:js];
//    [webView stringByEvaluatingJavaScriptFromString:@"ResizeImages();"];
//
//    CGFloat offsetHeight = [[self.webView stringByEvaluatingJavaScriptFromString:@"document.body.offsetHeight"] floatValue];
//    CGFloat scrollHeight = [[self.webView stringByEvaluatingJavaScriptFromString:@"document.body.scrollHeight"] floatValue];
//
//    NSLog(@"The height of offsetHeight is %f", offsetHeight);
//    NSLog(@"The height of scrollHeight is %f", scrollHeight);
//    webView.height = scrollHeight;
    self.loadCount --;
}

-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{

//    现在隐藏的代码
    NSString *requestString = [[request URL] absoluteString];//获取请求的绝对路径.
    NSArray *components = [requestString componentsSeparatedByString:@"#"];//提交请求时候分割参数的分隔符
    if ([components count] > 1)
    {
        if([(NSString *)[components objectAtIndex:1] isEqualToString:@"back"])
        {
            if (_type ==2) {
                [self dismissViewControllerAnimated:NO completion:nil];
            }else
            {
                [self.navigationController popViewControllerAnimated:YES];
            }
        }else
        {
            NSString *title = @"";
            NSString *content = @"";
            NSString *url = @"";
            NSString *imageUrl = @"";

            NSArray *component = [[components objectAtIndex:1] componentsSeparatedByString:@";"];//提交请求时候分割参数的分隔符
//            for (int i = 0; i<component.count; i++) {
//                NSString *string = component[i];
//                NSArray *com = [string componentsSeparatedByString:@"$"];//提交请求时候分割参数的分隔符
//                if (i == 0) {
//                    imageUrl = com[1];
//                }
//                if (i == 1) {
//                    title = [com[1] stringByRemovingPercentEncoding];
//                }
//                if (i == 2) {
//                    content = [com[1] stringByRemovingPercentEncoding];
//                }
//                if (i == 3) {
//                    url = com[1];
//                }
//            }

            
        }
    }
    
    
    
    
    if ([components count] > 1 && [(NSString *)[components objectAtIndex:0] isEqualToString:@"testapp"]) {
        ATLog(@"%@",[components objectAtIndex:1]);
        if([(NSString *)[components objectAtIndex:1] isEqualToString:@"best"])
            {
//                ZFSQNewAllOrderDetailViewController *vc = [[ZFSQNewAllOrderDetailViewController alloc]init];
//                vc.OrderNo = self.OrderNo;
//            [self.navigationController pushViewController:vc animated:YES];
            }
        //过滤请求是否是我们需要的.不需要的请求不进入条件
//        if([(NSString *)[components objectAtIndex:1] isEqualToString:@"chongzhi"])
//        {
//            [self.navigationController pushViewController:[ATJyJlViewController new] animated:YES];
//        }
//        if([(NSString *)[components objectAtIndex:1] isEqualToString:@"rengou"])
//        {
//             [self.navigationController pushViewController:[ATZqZrViewController new] animated:YES];
//        }
//        if([(NSString *)[components objectAtIndex:1] isEqualToString:@"touzi"])
//        {
//            [self.navigationController pushViewController:[ATWdTzViewController new] animated:YES];
//        }
//
//        if([(NSString *)[components objectAtIndex:1] isEqualToString:@"tixian"])
//        {
//            [self.navigationController pushViewController:[ATJyJlViewController new] animated:YES];
//
//        }
//        if([(NSString *)[components objectAtIndex:1] isEqualToString:@"kaihu"])
//        {
//            for (UIViewController *controller in self.navigationController.viewControllers) {
//                if ([controller isKindOfClass:[NewMyAccountViewController class]]) {
//                    [self.navigationController popToViewController:controller animated:YES];
//                }
//            }
//
//        }
        return NO;
    }
    return YES;
}

- (void)loadWebView{

    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:self.submitURL];
    [webView loadRequest:request];
   
}


//- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error{
//    NSLog(<#NSString * _Nonnull format, ...#>)
//}



/**
 *  添加右滑手势
 */
- (void)addSwipeRecognizer
{
    // 初始化手势并添加执行方法
    UISwipeGestureRecognizer *swipeRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(return)];
    // 手势方向
    swipeRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
    // 响应的手指数
    swipeRecognizer.numberOfTouchesRequired = 1;
    // 添加手势
    [[self view] addGestureRecognizer:swipeRecognizer];
}

#pragma mark 返回上一级
- (void)return
{
    // 最低控制器无需返回
    if (self.navigationController.viewControllers.count <= 1) return;
    
    // pop返回上一级
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if ([self.tag isEqualToString:@"100"]) {
        if (_delegate && [_delegate respondsToSelector:@selector(WebNewUserDelegateWithRefresh)]) {
            [_delegate WebNewUserDelegateWithRefresh];
        }
    }
}


@end
