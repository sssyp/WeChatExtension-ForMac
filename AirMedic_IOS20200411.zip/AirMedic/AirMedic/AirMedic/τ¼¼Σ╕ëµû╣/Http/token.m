//
//  token.m
//  ATNet3.0
//
//  Created by atbjb20 on 15/9/2.
//  Copyright (c) 2015年 ATBJB10. All rights reserved.
//

#import "token.h"

@implementation token
+(void)whriteValue:(NSString* )value
{
    if (![value isEqual:[NSNull null]]) {
        [[NSUserDefaults standardUserDefaults] setValue:value forKey:@"Token"];
        
        
    }else{
        [[NSUserDefaults standardUserDefaults] setValue:@"1"forKey:@"Token"];
    }
}

+(NSString* )getValue
{
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"Token"] isEqualToString:@"1"])
    {
        return @"";
    }
    else{
        return [[NSUserDefaults standardUserDefaults] objectForKey:@"Token"];
    }
    
        
    
}
@end
