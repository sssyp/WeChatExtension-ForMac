//
//  token.h
//  ATNet3.0
//
//  Created by atbjb20 on 15/9/2.
//  Copyright (c) 2015年 ATBJB10. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface token : NSObject
+(void)whriteValue:(NSString* )value;
+(NSString* )getValue;
@end
