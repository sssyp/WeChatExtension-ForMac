//
//  PruManerge.m
//  ATNet3.0
//
//  Created by ATBJB10 on 15/9/15.
//  Copyright (c) 2015年 ATBJB10. All rights reserved.
//

#import "PruManerge.h"
//#import <RMQClient/RMQClient.h>
#import <sys/utsname.h>
#import <sys/socket.h>
#import <sys/sockio.h>
#import <sys/ioctl.h>
#import <net/if.h>
#import <arpa/inet.h>

@interface PruManerge ()<NSXMLParserDelegate>
{
    NSMutableString* _bufferStr;
    NSString* backString;
    
    NSString* signedStrings;
}

@end


@implementation PruManerge

- (NSString *)iphoneType
{
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];
    
    if ([platform isEqualToString:@"iPhone1,1"]) return @"iPhone 2G";
    
    if ([platform isEqualToString:@"iPhone1,2"]) return @"iPhone 3G";
    
    if ([platform isEqualToString:@"iPhone2,1"]) return @"iPhone 3GS";
    
    if ([platform isEqualToString:@"iPhone3,1"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone3,2"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone3,3"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone4,1"]) return @"iPhone 4S";
    
    if ([platform isEqualToString:@"iPhone5,1"]) return @"iPhone 5";
    
    if ([platform isEqualToString:@"iPhone5,2"]) return @"iPhone 5";
    
    if ([platform isEqualToString:@"iPhone5,3"]) return @"iPhone 5c";
    
    if ([platform isEqualToString:@"iPhone5,4"]) return @"iPhone 5c";
    
    if ([platform isEqualToString:@"iPhone6,1"]) return @"iPhone 5s";
    
    if ([platform isEqualToString:@"iPhone6,2"]) return @"iPhone 5s";
    
    if ([platform isEqualToString:@"iPhone7,1"]) return @"iPhone 6 Plus";
    
    if ([platform isEqualToString:@"iPhone7,2"]) return @"iPhone 6";
    
    if ([platform isEqualToString:@"iPhone8,1"]) return @"iPhone 6s";
    
    if ([platform isEqualToString:@"iPhone8,2"]) return @"iPhone 6s Plus";
    
    if ([platform isEqualToString:@"iPhone8,4"]) return @"iPhone SE";
    
    if ([platform isEqualToString:@"iPhone9,1"]) return @"iPhone 7";
    
    if ([platform isEqualToString:@"iPhone9,2"]) return @"iPhone 7 Plus";
    
    if ([platform isEqualToString:@"iPod1,1"])   return @"iPod Touch 1G";
    
    if ([platform isEqualToString:@"iPod2,1"])   return @"iPod Touch 2G";
    
    if ([platform isEqualToString:@"iPod3,1"])   return @"iPod Touch 3G";
    
    if ([platform isEqualToString:@"iPod4,1"])   return @"iPod Touch 4G";
    
    if ([platform isEqualToString:@"iPod5,1"])   return @"iPod Touch 5G";
    
    if ([platform isEqualToString:@"iPad1,1"])   return @"iPad 1G";
    
    if ([platform isEqualToString:@"iPad2,1"])   return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,2"])   return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,3"])   return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,4"])   return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,5"])   return @"iPad Mini 1G";
    
    if ([platform isEqualToString:@"iPad2,6"])   return @"iPad Mini 1G";
    
    if ([platform isEqualToString:@"iPad2,7"])   return @"iPad Mini 1G";
    
    if ([platform isEqualToString:@"iPad3,1"])   return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,2"])   return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,3"])   return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,4"])   return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad3,5"])   return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad3,6"])   return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad4,1"])   return @"iPad Air";
    
    if ([platform isEqualToString:@"iPad4,2"])   return @"iPad Air";
    
    if ([platform isEqualToString:@"iPad4,3"])   return @"iPad Air";
    
    if ([platform isEqualToString:@"iPad4,4"])   return @"iPad Mini 2G";
    
    if ([platform isEqualToString:@"iPad4,5"])   return @"iPad Mini 2G";
    
    if ([platform isEqualToString:@"iPad4,6"])   return @"iPad Mini 2G";
    
    if ([platform isEqualToString:@"i386"])      return @"iPhone Simulator";
    
    if ([platform isEqualToString:@"x86_64"])    return @"iPhone Simulator";
    
    return platform;
    
}

+(instancetype)sharePruManerge{
    static PruManerge* pruManeger=nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        pruManeger=[[PruManerge alloc]init];
    });
    return pruManeger;
    
}
-(NSString *)getTime
{
//    NSDate *senddate = [NSDate date];
    NSString *date2 =  [self getNowTimeTimestamp3];
//    NSString *date2 = [NSString stringWithFormat:@"%ld999", (long)[senddate timeIntervalSince1970]];
    return date2;
}
-(NSString *)getNowTimeTimestamp3{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init] ;
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss SSS"]; // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    
    //设置时区,这个对于时间的处理有时很重要
    
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    
    [formatter setTimeZone:timeZone];
    
    NSDate *datenow = [NSDate date];//现在时间,你可以输出来看下是什么格式
    
    NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[datenow timeIntervalSince1970]*1000];
    
    return timeSp;
    
}


-(NSString *)deviceWANIPAdress
{
    NSError *error;
    NSURL *ipURL = [NSURL URLWithString:@"http://pv.sohu.com/cityjson?ie=utf-8"];
    if (ipURL!=nil) {
        NSMutableString *ip = [NSMutableString stringWithContentsOfURL:ipURL encoding:NSUTF8StringEncoding error:&error];
        //判断返回字符串是否为所需数据
        if ([ip hasPrefix:@"var returnCitySN = "]) {
            //对字符串进行处理，然后进行json解析
            //删除字符串多余字符串
            NSRange range = NSMakeRange(0, 19);
            [ip deleteCharactersInRange:range];
            NSString * nowIp =[ip substringToIndex:ip.length-1];
            //将字符串转换成二进制进行Json解析
            NSData * data = [nowIp dataUsingEncoding:NSUTF8StringEncoding];
            
            NSDictionary * dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            return dict[@"cip"];
        }
        return @"0.0.0.0";
    }
    return @"0.0.0.0";
    
}
-(NSString*)getPrukey:(NSDictionary*)dic{
    
    NSString* str=[self dictionaryToJson:dic];
    
    //ATLog(@"%lu",(unsigned long)str.length);
    
    if (str.length>39) {
        signedStrings=@"";
        for (int i=0; i<str.length%39; i++) {
            
            NSString* string=[str substringWithRange:NSMakeRange(39*i, 39)];
            
            
            NSString*string0=[str substringFromIndex:39*(i+1)];
            
            NSString*signedString0=[self encryptWithString:string];
            backString=[NSString stringWithFormat:@"%@",signedString0];
            backString=[NSString stringWithFormat:@"%@%@",signedStrings,signedString0];
            signedStrings=backString;
            if (string0.length<39) {
                // NSString*string0=[str substringFromIndex:35*i];
                NSString*signedString1=[self encryptWithString:string0];
                backString=[NSString stringWithFormat:@"%@%@",signedStrings,signedString1];
                
                break;
            }
            
            
        }
        
        // ATLog(@"backString======%@",backString);
        return backString;
        
    }else{
        NSString* signedString=[self encryptWithString:str];
        return signedString;
        //ATLog(@"signedString======%@",signedString);
        
    }
    
}


- (NSString*)dictionaryToJson:(NSDictionary *)dic//字典转json格式字符串
{
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
}


- (NSString *)encryptWithString:(NSString *)content
{
    NSData *publicKey = [NSData dataFromBase64String:@"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCY6qVctIzU6GDUGpVodY3LVjFmqOjvd/HAMCPzHYeFmUR9+Fw/u5J5+Ib/9Yk2ZDk5lXqIGHUR8Un/cQ5X50ymGGe0s9Ha4tprCAWo8O0D6t+sPFCDIMR65HK2j/q/V085v9G3XUSZJmxcLRGTkj/nk/1AtRyzTOIW4rj4rR6JNwIDAQAB"];
    NSData *usernamm = [content dataUsingEncoding: NSUTF8StringEncoding];
    NSData *newKey= [SecKeyWrapper encrypt:usernamm publicKey:publicKey];
    NSString *result = [newKey base64EncodedString];
    return result;
}
-(NSString*)getCurrentTime
{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];[formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSString *dateTime = [formatter stringFromDate:[NSDate date]];
    
    return dateTime;
    
}

@end
