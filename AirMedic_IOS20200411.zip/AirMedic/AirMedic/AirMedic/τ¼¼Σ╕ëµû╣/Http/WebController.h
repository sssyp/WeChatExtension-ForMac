//
//  WebController.h
//  ATYiYuanWealth
//
//  Created by Itachi on 15/8/6.
//  Copyright (c) 2015年 AT. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol WebNewUserDelegate <NSObject>

-(void)WebNewUserDelegateWithRefresh;

@end
@interface WebController : UIViewController

@property (nonatomic, copy) NSURL *submitURL;
@property (nonatomic, assign) NSString *tag;
@property (nonatomic, strong) UIWebView *webView;
@property (nonatomic,copy) NSString *OrderNo;
@property(nonatomic,weak) id<WebNewUserDelegate>delegate;
@property (nonatomic,assign) NSInteger type;//2表示隐私

@end
