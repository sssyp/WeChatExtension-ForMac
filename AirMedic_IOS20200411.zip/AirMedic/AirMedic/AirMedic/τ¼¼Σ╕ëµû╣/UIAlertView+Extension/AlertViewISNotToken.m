//
//  AlertViewISNotToken.m
//  ATNet3.0
//
//  Created by atbjb20 on 15/9/3.
//  Copyright (c) 2015年 ATBJB10. All rights reserved.
//

#import "AlertViewISNotToken.h"
//#import "ATDLViewController.h"
//#import "NewLoginViewController.h"
//#import "ATNavigationController.h"

@implementation AlertViewISNotToken
//-(id)initWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate OKlButtonTitle:(NSString *)OkButtonTitle CancelButtonTitle:(NSString *)CancelButtonTitle theNavigationController:(UINavigationController *)navigationController
//{
//    self=[self initWithTitle:title message:message delegate:self cancelButtonTitle:OkButtonTitle otherButtonTitles:CancelButtonTitle, nil];
//    if (self) {
//        self.navigationController=navigationController;
//    }
//    return self;
//}

-(id)initWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate OKlButtonTitle:(NSString *)OkButtonTitle theNavigationController:(UINavigationController *)navigationController
{
    self=[self initWithTitle:title message:message delegate:self cancelButtonTitle:OkButtonTitle otherButtonTitles:nil, nil];
    if (self) {
        self.navigationController=navigationController;
    }
    return self;
}

-(void)ExitLogin
{
    
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    [userDefaults removeObjectForKey:@"isLogin"];
    [userDefaults removeObjectForKey:@"userId"];
    [userDefaults removeObjectForKey:@"userType"];
    [userDefaults synchronize];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    switch (buttonIndex) {
        case 0:
        {
            NSLog(@"提示框");
//            UIButton *button=(UIButton *)[alertView viewWithTag:buttonIndex];
//            NSLog(@"%@",[button titleLabel].text);
  
            //原先的代码
//                ATDLViewController *login =  [[ATDLViewController alloc]init];
//                [self.navigationController pushViewController:login animated:YES];
            //现在隐藏的代码
//            NewLoginViewController *login =  [[NewLoginViewController alloc]init];
//            [self.navigationController pushViewController:login animated:YES];
          
        }
            break;
        case 1:
            
        {
            UIButton *button=(UIButton *)[alertView viewWithTag:buttonIndex];
            NSLog(@"%@",[button titleLabel].text);
            
        }
            break;
        default:
            break;
    }
}

+(BOOL)isContainsPanGesture:(UINavigationController *)nav
{
//    unsigned int propertyCount = 0;
//    UINavigationController *currentViewController=(ATNavigationController *)nav;
//    objc_property_t *propertyList=class_copyPropertyList([currentViewController class], &propertyCount);
//    
//    for (unsigned int i = 0; i < propertyCount; ++i) {
//        objc_property_t property = propertyList[i];
//        const char * name = property_getName(property);//获取属性名字
//        NSString *name2= [NSString stringWithCString:name encoding:NSUTF8StringEncoding];
//        if ([name2 isEqualToString:@"panGesture"]) {
//            return true;
//        }
//    }
    return false;
}
@end
