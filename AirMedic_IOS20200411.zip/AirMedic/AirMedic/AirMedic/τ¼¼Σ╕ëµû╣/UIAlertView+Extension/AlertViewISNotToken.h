//
//  AlertViewISNotToken.h
//  ATNet3.0
//
//  Created by atbjb20 on 15/9/3.
//  Copyright (c) 2015年 ATBJB10. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlertViewISNotToken : UIAlertView

@property(nonatomic,strong)UINavigationController *navigationController;

//-(id)initWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate OKlButtonTitle:(NSString *)OkButtonTitle CancelButtonTitle:(NSString *)CancelButtonTitle theNavigationController:(UINavigationController *)navigationController;


-(id)initWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate OKlButtonTitle:(NSString *)OkButtonTitle theNavigationController:(UINavigationController *)navigationController;
-(void)ExitLogin;

+(BOOL)isContainsPanGesture:(UINavigationController *)nav;

@end
