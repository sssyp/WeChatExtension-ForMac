//
//  xiaoyan.h
//  ATJDTProject
//
//  Created by auto on 15/10/9.
//  Copyright (c) 2015年 AT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface xiaoyan : NSObject

//身份证号码效验
+ (BOOL)validateIdentityCard:(NSString *)identityCard;

//汉字效验
+ (BOOL)userName:(NSString *)userName;
+ (BOOL)userName1:(NSString *)userName1;

//判断是否为整形：
+(BOOL)isPureInt:(NSString*)string;

+(BOOL)isPureFloat:(NSString*)string;

//邮箱验证
+(BOOL)isValidateEmail:(NSString *)email;

+(BOOL)isEnglish:(NSString *)English;//英文匹配
+(BOOL)isNumber:(NSString *)Number;//阿拉伯数字匹配
+(BOOL)userPasswordVarify:(NSString *)userPassword;//只能是数字、字母或数字和字母组合
//手机号码
+(BOOL)validateMobile:(NSString *)mobileNum;

+(BOOL) isBlankString:(NSString *)string;//判断为nil、null等

//银行卡号
+ (BOOL) checkCardNo:(NSString*) cardNo;
@end
