//
//  EngineTools.h
//  通泰贷
//
//  Created by ATBJB10 on 14/12/16.
//  Copyright (c) 2014年 xibenye. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "MJRefresh.h"
//#import "TZFileList.h"
//#import "UIViewController+ENPopUp.h"
//#import "LoginViewController.h"
//#import "MBProgressHUD+MJ.h"
//#import "MDRadialProgressView.h"
//#import "MDRadialProgressTheme.h"
//#import "MDRadialProgressLabel.h"
//#import "Uploadpicture.h"

#define SHOW_ALERT(_message_) UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:_message_ delegate:nil cancelButtonTitle:@"我知道啦！" otherButtonTitles: nil]; \
[alert show]; \


//注册
#define NAME @"name"
#define PSW @"password"
#define iPhone @"iPhone"

//登录
#define Login_name @"Login_name"
#define Login_pwd @"Login_pwd"
#define Login_Phone @"Login_Phone"

@interface EngineTools : UIViewController

//十六进制转化为颜色
+ (UIColor *) colorWithHexString: (NSString *) stringToConvert;

+ (void)time: (UIButton *)btn;//时间倒计时

+(BOOL) isBlankString:(NSString *)string;//判断为nil、null等

//判断邮箱
+ (BOOL) validateEmail:(NSString *)email;

//身份证
+ (BOOL)validateIDCardNumber:(NSString *)value;

+(BOOL)isChinese:(NSString *)Chinese;//中文匹配


//手机验证码倒计时60S
+ (void)timeWithButton: (UIButton *)btn;//时间倒计时

@end
