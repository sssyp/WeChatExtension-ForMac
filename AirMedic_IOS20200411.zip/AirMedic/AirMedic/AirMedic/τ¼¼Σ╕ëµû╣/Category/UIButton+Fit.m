//
//  UIButton+Fit.m
//  ATSilverySwallow
//
//  Created by ATBJB15 on 15/4/21.
//  Copyright (c) 2015年 AT. All rights reserved.
//

#import "UIButton+Fit.h"

@implementation UIButton (Fit)

+ (UIButton *)initWithRefreshViewButton:(UIView *)view target:(id)target action:(SEL)action
{
     UIButton *button = [[UIButton alloc] init];
     button.frame = CGRectMake(view.size.width/2-80, view.size.height/2-50,150,60);
     [button setTitle:@"暂无数据,点击刷新" forState:UIControlStateNormal];
     button.titleLabel.font = [UIFont systemFontOfSize:15];
     [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
     [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
     return button;
}

+ (UIButton *)initWithRefreshControllerButton:(UIViewController *)view target:(id)target action:(SEL)action
{
    UIButton *button = [[UIButton alloc] init];
    button.frame = CGRectMake(view.view.frame.size.width/2-80, view.view.frame.size.height/2-50,150,60);
    [button setTitle:@"暂无数据,点击刷新" forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:15];
    [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return button;

}

@end
