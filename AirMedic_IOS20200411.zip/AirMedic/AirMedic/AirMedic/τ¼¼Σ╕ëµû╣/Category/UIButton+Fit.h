//
//  UIButton+Fit.h
//  ATSilverySwallow
//
//  Created by ATBJB15 on 15/4/21.
//  Copyright (c) 2015年 AT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Fit)

/**
 *  传入一个UITableView可以快速集成一个‘点击刷新’的按钮在控件中部
 *  @param view   UITableView
 *  @param target 事件对象
 *  @param action 响应事件
 *  @return 返回按钮对象
 */
+ (UIButton *)initWithRefreshViewButton:(UIView *)view target:(id)target action:(SEL)action;

/**
 *  传入一个UITableViewController可以快速集成一个‘点击刷新’的按钮在控件中部
 *  @param view   UITableView
 *  @param target 事件对象
 *  @param action 响应事件
 *  @return 返回按钮对象
 */
+ (UIButton *)initWithRefreshControllerButton:(UIViewController *)view target:(id)target action:(SEL)action;

@end
