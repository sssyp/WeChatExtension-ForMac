//
//  DivEncode.m
//  ATDRTXProject
//
//  Created by ATBJB-26 on 2017/2/10.
//  Copyright © 2017年 atbjb20. All rights reserved.
//

#import "DivEncode.h"

@interface DivEncode ()<NSXMLParserDelegate>
{
    NSMutableString* _bufferStr;
    NSString* backString;
    
    NSString* signedStrings;
   
}

@end

@implementation DivEncode

+(instancetype)sharePruManerge{
    static DivEncode* pruManeger=nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        pruManeger=[[DivEncode alloc]init];
    });
    return pruManeger;
    
}
-(NSString*)md5Codesign:(NSDictionary*)dict
{
      NSArray*allKeyArray = [dict allKeys];
      NSArray*afterSortKeyArray = [allKeyArray sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1,id  _Nonnull obj2) {
        NSComparisonResult resuest = [obj1 compare:obj2];
        return resuest;
        
          }];
      NSLog(@"afterSortKeyArray:%@",afterSortKeyArray);
    //通过排列的key值获取value
      NSMutableArray *valueArray = [NSMutableArray array];
    for(NSString*sortsing in afterSortKeyArray)
    {
        NSString*valueString = [dict objectForKey:sortsing];
            [valueArray addObject:valueString];
        
          }
    NSMutableString *signString = [NSMutableString string];
      for(int i =0; i < afterSortKeyArray.count; i++) {
//              NSString*keyValue = [NSString stringWithFormat:@"%@",valueArray[i]];
        //            [signString appendString:keyValue];
        
        [signString appendFormat:@"%@&", [NSString stringWithFormat:@"%@=%@",afterSortKeyArray[i],valueArray[i]]];
        
          }
      //signString用于签名的原始参数集合//
    signString = [signString stringByAppendingString:@"interlnx&aY4N!bAAds"];
      NSLog(@"%@",signString);//
    //    NSLog(@"%@",[signString md5Str]);
    return [self md5Str:signString];
    
}
-(NSString*)md5Str:(NSMutableString *)signString
{
      const char* myPasswordd = [signString UTF8String];
    unsigned char md5c[16];
    CC_MD5(myPasswordd, (CC_LONG)strlen(myPasswordd), md5c);
      NSMutableString *md5Str = [NSMutableString string];
      for(int i =0; i<16; i++) {
          [md5Str appendFormat:@"%02x",md5c[i]];
        
          }
    return md5Str;
    
}
-(NSString*)getPrukeyMD5:(NSString*)string
{
    const char * str = [string UTF8String];
    //开辟一个16字节（128位：md5加密出来就是128位/bit）的空间（一个字节=8字位=8个二进制数）
    unsigned char md[CC_MD5_DIGEST_LENGTH];
    /*
     extern unsigned char * CC_MD5(const void *data, CC_LONG len, unsigned char *md)官方封装好的加密方法
     把str字符串转换成了32位的16进制数列（这个过程不可逆转） 存储到了md这个空间中
     */
    CC_MD5(str, (int)strlen(str), md);
    //创建一个可变字符串收集结果
    NSMutableString * ret = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH];
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
        /**
         X 表示以十六进制形式输入/输出
         02 表示不足两位，前面补0输出；出过两位不影响
         printf("%02X", 0x123); //打印出：123
         printf("%02X", 0x1); //打印出：01
         */
        [ret appendFormat:@"%02X",md[i]];
    }
    //返回一个长度为32的字符串
    return ret;
}
-(NSString*)getPrukey:(NSDictionary*)dic{
    
    NSString* stre=[self dictionaryToJson:dic];
    //传入参数,转化成char
    const char * str = [stre UTF8String];
    //开辟一个16字节（128位：md5加密出来就是128位/bit）的空间（一个字节=8字位=8个二进制数）
    unsigned char md[CC_MD5_DIGEST_LENGTH];
    /*
     extern unsigned char * CC_MD5(const void *data, CC_LONG len, unsigned char *md)官方封装好的加密方法
     把str字符串转换成了32位的16进制数列（这个过程不可逆转） 存储到了md这个空间中
     */
    CC_MD5(str, (int)strlen(str), md);
    //创建一个可变字符串收集结果
    NSMutableString * ret = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH];
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
        /**
         X 表示以十六进制形式输入/输出
         02 表示不足两位，前面补0输出；出过两位不影响
         printf("%02X", 0x123); //打印出：123
         printf("%02X", 0x1); //打印出：01
         */
        [ret appendFormat:@"%02X",md[i]];
    }
    //返回一个长度为32的字符串
    return ret;

//    ATLog(@"%lu",(unsigned long)str.length);
    
//    if (str.length>39) {
//        signedStrings=@"";
//        for (int i=0; i<str.length/39; i++) {
//
//            NSString* string=[str substringWithRange:NSMakeRange(39*i, 39)];
//
//
//            NSString*string0=[str substringFromIndex:39*(i+1)];
//
//            NSString*signedString0=[RSA encryptString:string publicKey:@"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCY6qVctIzU6GDUGpVodY3LVjFmqOjvd/HAMCPzHYeFmUR9+Fw/u5J5+Ib/9Yk2ZDk5lXqIGHUR8Un/cQ5X50ymGGe0s9Ha4tprCAWo8O0D6t+sPFCDIMR65HK2j/q/V085v9G3XUSZJmxcLRGTkj/nk/1AtRyzTOIW4rj4rR6JNwIDAQAB"];
//            backString=[NSString stringWithFormat:@"%@",signedString0];
//            backString=[NSString stringWithFormat:@"%@%@",signedStrings,signedString0];
//            signedStrings=backString;
//            if (string0.length<39) {
//                // NSString*string0=[str substringFromIndex:35*i];
//                NSString*signedString1=[RSA encryptString:string0 publicKey:@"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCY6qVctIzU6GDUGpVodY3LVjFmqOjvd/HAMCPzHYeFmUR9+Fw/u5J5+Ib/9Yk2ZDk5lXqIGHUR8Un/cQ5X50ymGGe0s9Ha4tprCAWo8O0D6t+sPFCDIMR65HK2j/q/V085v9G3XUSZJmxcLRGTkj/nk/1AtRyzTOIW4rj4rR6JNwIDAQAB"];
//                backString=[NSString stringWithFormat:@"%@%@",signedStrings,signedString1];
//
//                break;
//            }
//
//
//        }
//
//        // ATLog(@"backString======%@",backString);
//        return backString;
//
//    }else{
//        NSString* signedString=[RSA encryptString:str publicKey:@"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCY6qVctIzU6GDUGpVodY3LVjFmqOjvd/HAMCPzHYeFmUR9+Fw/u5J5+Ib/9Yk2ZDk5lXqIGHUR8Un/cQ5X50ymGGe0s9Ha4tprCAWo8O0D6t+sPFCDIMR65HK2j/q/V085v9G3XUSZJmxcLRGTkj/nk/1AtRyzTOIW4rj4rR6JNwIDAQAB"];
//        return signedString;
//        //ATLog(@"signedString======%@",signedString);
//
//    }
    
}


- (NSString*)dictionaryToJson:(NSDictionary *)dic//字典转json格式字符串
{
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
}


- (NSString *)divEncode:(NSDictionary *)params
{
    NSError *parseError = nil;
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:&parseError];
    
    NSString *jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    
//    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
//    
//    NSData *newData = [RSA encryptData:data publicKey:@"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCpUFaTRXXLb0ErLlZ1eYS0BgkYENOL/pVnHJNQF2LPvC1MfXVODIFl92pn5Vx/OafehUklL0pvgj+J3JYAiu7mGPmIR2J4BrZYUrtdViEInNrAYzSSfefQ24a7aGm72Bq6a5WpmjNNi2OLHzuexn/Gt1cdcetZAsre+SEKmB2sSQIDAQAB"];
//    
//    NSString *signature = [newData base64EncodedString];
    
    NSString *signature = [RSA encryptString:jsonString publicKey:@"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCY6qVctIzU6GDUGpVodY3LVjFmqOjvd/HAMCPzHYeFmUR9+Fw/u5J5+Ib/9Yk2ZDk5lXqIGHUR8Un/cQ5X50ymGGe0s9Ha4tprCAWo8O0D6t+sPFCDIMR65HK2j/q/V085v9G3XUSZJmxcLRGTkj/nk/1AtRyzTOIW4rj4rR6JNwIDAQAB"];
    
    return signature;
}

@end
