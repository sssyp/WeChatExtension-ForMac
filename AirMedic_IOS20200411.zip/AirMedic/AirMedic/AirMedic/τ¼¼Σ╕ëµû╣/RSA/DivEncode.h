//
//  DivEncode.h
//  ATDRTXProject
//
//  Created by ATBJB-26 on 2017/2/10.
//  Copyright © 2017年 atbjb20. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DivEncode : NSObject
+(instancetype)sharePruManerge;

-(NSString*)getPrukey:(NSDictionary*)dic;
-(NSString*)getPrukeyMD5:(NSString*)string;
-(NSString*)md5Codesign:(NSDictionary*)dict;

//- (NSString *)divEncode:(NSDictionary *)params;

@end
