//
//  UIImage+fixOrientation.h
//  天天练琴(学生)
//
//  Created by kaka on 2019/6/10.
//  Copyright © 2019 kaka. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (fixOrientation)
+ (UIImage*)fixOrientation:(UIImage*)image;

@end

NS_ASSUME_NONNULL_END
