//
//  GSJMaintenanceViewController.m
//  AirMedic
//
//  Created by gsj on 2019/8/10.
//  Copyright © 2019年 gsj. All rights reserved.
//
#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define Margin 10
#define itemWH  (ScreenWidth - 4 * Margin-100)/3
static NSString *ID = @"cell";

#import "GSJMaintenanceViewController.h"
#import "TTPhotosCollectionViewCell.h"

@interface GSJMaintenanceViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UITextFieldDelegate>
@property (nonatomic,strong) UITextField *nameField;
@property (nonatomic,strong) UITextField *phoneField;
@property (nonatomic,strong) UITextField *decField;
@property (nonatomic,strong) UITextField *codeField;
@property (nonatomic,strong) UITextField *addressField;

@property (nonatomic,strong) UIView *headView;

@property (nonatomic,strong) NSMutableArray *photoArray;
@property (nonatomic,strong) UICollectionView *collectionView;
@property (nonatomic,strong) NSMutableArray *mainArray;

@property (nonatomic,strong) NSMutableArray *pathArray;
@property (nonatomic,assign) NSInteger pathNum;
@property (nonatomic,strong) UIImageView *bigImage;
@property (nonatomic,strong) UIView *bgView;

@end

@implementation GSJMaintenanceViewController
-(UIView *)bgView
{
    if (!_bgView) {
        
        _bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, ATGetDeviceHeight)];
        [self.view addSubview:_bgView];
        _bgView.hidden = YES;
        _bgView.backgroundColor = [UIColor blackColor];
//        _bgView.alpha = 0.9;

        _bigImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight/4, ATGetDeviceWidth, ATGetDeviceHeight/2)];
        [_bgView addSubview:_bigImage];
        _bigImage.userInteractionEnabled = YES;
        _bigImage.image = [UIImage imageNamed:@"123"];
        
        UITapGestureRecognizer *ges = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didHiddenView)];
        [_bgView addGestureRecognizer:ges];
    }
    return _bgView;
}
-(NSMutableArray *)mainArray
{
    if (!_mainArray) {
        _mainArray = [NSMutableArray array];
    }
    return _mainArray;
}
- (NSMutableArray *)photoArray
{
    if (!_photoArray) {
        _photoArray = [NSMutableArray array];
    }
    return _photoArray;
}
- (NSMutableArray *)pathArray
{
    if (!_pathArray) {
        _pathArray = [NSMutableArray array];
    }
    return _pathArray;
}
-(UIView *)headView
{
    if (!_headView) {
        _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, 44+22+iPhoneX_SPACE_TOP)];
        [self.view addSubview:_headView];
        _headView.backgroundColor = [UIColor whiteColor];
    }
    return _headView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
#pragma mark -初始化-
-(void)initUI
{
    self.view.backgroundColor =[UIColor colorWithRed:249/255.0 green:247/255.0 blue:245/255.0 alpha:1.0];
    
    UILabel *headLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,15+22+iPhoneX_SPACE_TOP,ATGetDeviceWidth,19)];
    [self.headView addSubview:headLabel];
    NSMutableAttributedString *headString = [[NSMutableAttributedString alloc] initWithString:@"售后维修" attributes:@{NSFontAttributeName: [UIFont fontWithName:@"PingFang-SC-Medium" size: 16],NSForegroundColorAttributeName: [UIColor blackColor]}];
    headLabel.attributedText = headString;
    headLabel.textAlignment = NSTextAlignmentCenter;
    
   
    
    UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(6,34+iPhoneX_SPACE_TOP,23,23)];
    [self.view addSubview:leftBtn];
    [leftBtn setImage:[UIImage imageNamed:@"icon-back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(didBack) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIView *middleView = [[UIView alloc]initWithFrame:CGRectMake(0, 66+iPhoneX_SPACE_TOP+10, ATGetDeviceWidth, ATGetDeviceHeight)];
    [self.view addSubview:middleView];
    middleView.backgroundColor = [UIColor whiteColor];
    
    NSArray *titleArray = @[@"报修人",@"联系方式",@"故障描述",@"机身序列号",@"回寄地址"];
    NSArray *placeArray = @[@"请输入姓名",@"请输入联系方式",@"请输入故障描述",@"请输入机身序列号",@"请输入售后完成回寄地址"];

    for (int i =0; i<5; i++) {
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 50*i, 100, 50)];
        label.text =titleArray[i];
        [middleView addSubview:label];
        label.font = [UIFont systemFontOfSize:14];
        label.textColor = RGB(0x90e1f4);
        
        UITextField *field = [[UITextField alloc]initWithFrame:CGRectMake(110, 50*i, ATGetDeviceWidth-120, 50)];
        field.placeholder =placeArray[i];
        [middleView addSubview:field];
        field.font = [UIFont systemFontOfSize:14];
        field.delegate = self;
        
        UIView *line = [[UIView alloc]initWithFrame:CGRectMake(10, 49+50*i, ATGetDeviceWidth-20, 1)];
        [middleView addSubview:line];
        line.backgroundColor = rgba(203, 203, 200, 1);
        
        if (i ==0) {
            self.nameField = field;
        }
        if (i ==1) {
            self.phoneField = field;
        }
        if (i ==2) {
            self.decField = field;
        }
        if (i==3) {
            field.frame= CGRectMake(110, 50*i, ATGetDeviceWidth-120-50, 50);

            
            self.codeField = field;
            
            UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-40, field.y+15, 20, 20)];
            [btn addTarget:self action:@selector(didShow) forControlEvents:UIControlEventTouchUpInside];
            [middleView addSubview:btn];
            [btn setTitle:@"?" forState:UIControlStateNormal];
            btn.layer.borderColor =RGB(0x90e1f4).CGColor;
            btn.layer.borderWidth = 1;
            btn.layer.cornerRadius =10;
            btn.layer.masksToBounds = YES;
            [btn setTitleColor:RGB(0x90e1f4) forState:UIControlStateNormal];
        }
        if (i ==4) {
            self.addressField = field;
        }
    }
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 270, ATGetDeviceWidth, 20)];
    label.text =@"请上传机器故障图片";
    [middleView addSubview:label];
    label.font = [UIFont systemFontOfSize:14];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = RGB(0x90e1f4);
    
    //流水布局
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.itemSize = CGSizeMake(itemWH, itemWH);
    layout.minimumLineSpacing = Margin;
    layout.minimumInteritemSpacing = Margin;
    
    //创建collectionView
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(20, 320, ATGetDeviceWidth-40, 100) collectionViewLayout:layout];
    _collectionView.backgroundColor = [UIColor whiteColor];
    [middleView addSubview:_collectionView];
    
    //设置数据源
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[TTPhotosCollectionViewCell class] forCellWithReuseIdentifier:ID];
    
//    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(20, 320, 100, 100)];
//    [btn addTarget:self action:@selector(didAddPicture) forControlEvents:UIControlEventTouchUpInside];
//    [middleView addSubview:btn];
//    [btn setTitle:@"添加" forState:UIControlStateNormal];
//    btn.backgroundColor =[UIColor redColor];
    
    
    UIButton *finshBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-50, ATGetDeviceWidth, 50)];
    [self.view addSubview:finshBtn];
//    finshBtn.backgroundColor =  [UIColor colorWithRed:152/255.0 green:203/255.0 blue:214/255.0 alpha:1.0];
    [finshBtn addTarget:self action:@selector(didAction) forControlEvents:UIControlEventTouchUpInside];
    [finshBtn setTitle:@"提交" forState:UIControlStateNormal];
    [finshBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    finshBtn.titleLabel.font = [UIFont systemFontOfSize:18];
    finshBtn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];

}
#pragma mark -点击事件-
-(void)didHiddenView
{
    self.bgView.hidden = YES;
}
-(void)didShow
{
    self.bgView.hidden = NO;

}
-(void)didAddAction
{
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    //按钮：从相册选择，类型：UIAlertActionStyleDefault
    
        //按钮：拍照，类型：UIAlertActionStyleDefault
        [alert addAction:[UIAlertAction actionWithTitle:@"拍照上传" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
            /**
             其实和从相册选择一样，只是获取方式不同，前面是通过相册，而现在，我们要通过相机的方式
             */
            UIImagePickerController *PickerImage = [[UIImagePickerController alloc]init];
            //获取方式:通过相机
            PickerImage.navigationBar.translucent = NO; //去除毛玻璃效果
            
            PickerImage.sourceType = UIImagePickerControllerSourceTypeCamera;
            //        PickerImage.allowsEditing = YES;
            PickerImage.delegate = self;
            [self presentViewController:PickerImage animated:YES completion:nil];
        }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        //        //MaxImagesCount  可以选着的最大条目数
        //        TZImagePickerController *imagePicker = [[TZImagePickerController alloc] initWithMaxImagesCount:6 delegate:self];
        //
        //        // 是否显示可选原图按钮
        //        imagePicker.allowPickingOriginalPhoto = NO;
        //        // 是否允许显示视频
        //        imagePicker.allowPickingVideo = NO;
        //        // 是否允许显示图片
        //        imagePicker.allowPickingImage = YES;
        //
        //        [imagePicker setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
        //
        //            NSLog(@"选中的图片");
        //            for (int i = 0; i<photos.count; i++) {
        //
        //                NSData *imageData = UIImageJPEGRepresentation(photos[i],1.0f);//第二个参数为压缩倍数
        //                [self.photoArray addObject:imageData];
        //            }
        //            [self saveMusic];
        //
        //        }];
        //        // 这是一个navigation 只能present
        //        [self presentViewController:imagePicker animated:YES completion:nil];
        
        //初始化UIImagePickerController
        UIImagePickerController *PickerImage = [[UIImagePickerController alloc]init];
        //获取方式1：通过相册（呈现全部相册），UIImagePickerControllerSourceTypePhotoLibrary
        //获取方式2，通过相机，UIImagePickerControllerSourceTypeCamera
        //获取方法3，通过相册（呈现全部图片），UIImagePickerControllerSourceTypeSavedPhotosAlbum
        PickerImage.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        //允许编辑，即放大裁剪
        PickerImage.navigationBar.translucent = NO; //去除毛玻璃效果
        
        //        PickerImage.allowsEditing = YES;
        //自代理
        PickerImage.delegate = self;
        //页面跳转
        [self presentViewController:PickerImage animated:YES completion:nil];
    }]];
    //按钮：取消，类型：UIAlertActionStyleCancel
    [alert addAction:[UIAlertAction actionWithTitle:@"取消上传" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
    
}
-(void)didBack
{
    [self dismissViewControllerAnimated:YES completion:nil];

}
-(void)didAction
{
    

    if ([self.nameField.text isEqualToString:@""]) {
        [MBProgressHUD showMessage:@"请输入姓名"];
        return;
    }
    if ([self.phoneField.text isEqualToString:@""]) {
        [MBProgressHUD showMessage:@"请输入电话号码"];
        return;
    }
    if ([self.decField.text isEqualToString:@""]) {
        [MBProgressHUD showMessage:@"请输入故障描述"];
        return;
    }
    if ([self.codeField.text isEqualToString:@""]) {
        [MBProgressHUD showMessage:@"请输入机身序列号"];
        return;
    }
    if ([self.addressField.text isEqualToString:@""]) {
        [MBProgressHUD showMessage:@"请输入售后完成回寄地址"];
        return;
    }
    [self uploadImage];

    
//    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)didAddPicture
{
    NSLog(@"点击了添加图片");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -上传图片接口-
-(void)uploadImage
{
    
    if (self.photoArray.count!=0) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];

//    NSString *userId = [[NSUserDefaults standardUserDefaults]valueForKey:@"id"];
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],[token getValue],@"4028358a658eb24f01658eb8a9c40001"];
//    NSString *parameter =[NSString stringWithFormat:@"pictype=fix&token=%@&timestamp=%@&sign=%@",[token getValue],[[PruManerge sharePruManerge]getTime],[[[DivEncode sharePruManerge]getPrukeyMD5:md5] lowercaseString]];
    NSDictionary *dic=@{
                         @"appid":@"1288",
                         @"motime":[[PruManerge sharePruManerge]getTime],
                         @"pictype":@"fix",
                         @"token":[token getValue]
                         };
    
        NSString *parameter =[NSString stringWithFormat:@"pictype=fix&token=%@&appid=1288&motime=%@&sign=%@",[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];

    
//    NSString *text = [self dictionaryToJson:dic];
//    NSString *base = BASE64(text);
//    NSString *mainUrl = [NSString stringWithFormat:@"%@?data=%@&%@",TTSaveMusicByStu,base,parameter];
    
    NSString *mainUrl =[NSString stringWithFormat:@"http://smart.airmedic.cn:9088/arm/api/sso/upload?%@",parameter] ;
    //    NSData *imageData = UIImagePNGRepresentation(_headImage.image);
    [self.pathArray removeAllObjects];
    _pathNum = 0;
    for (int i = 0; i<self.photoArray.count; i++) {
        NSData *data = self.photoArray[i];
        [XDNetworking uploadFileWithUrl:mainUrl fileData:data type:@"png" name:@"uploadData" mimeType:@"image/jpeg" progressBlock:^(int64_t bytesWritten, int64_t totalBytes) {
            
        } successBlock:^(id response) {
            NSLog(@"----------------%@",response);
            
            if ([response[@"code"] isEqualToString:@"10000"])
            {
             
               [self.pathArray addObject:response[@"data"][@"path"]];
                if (self.pathNum == self.photoArray.count-1) {
                    [self sendfix];
                    [MBProgressHUD hideHUDForView:self.view animated:YES];

                }
                   self.pathNum++;
            }else
            {
                [MBProgressHUD showMessage:@"提交失败"];
                [MBProgressHUD hideHUDForView:self.view animated:YES];

            }
        } failBlock:^(NSError *error) {
            NSLog(@"%@",error);
            [MBProgressHUD hideHUDForView:self.view animated:YES];

        }];
    }
   
    }else
    {
        [self sendfix];
    
    }
    
}
#pragma mark -提交售后-
-(void)sendfix
{
    
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
//    NSDictionary *dic = @{
////                          num:[NSNumber numberWithInteger:[level integerValue]]
//                          };
    NSMutableArray *array = [NSMutableArray array];
    for (int i = 0; i<self.pathArray.count; i++) {
        NSMutableDictionary *muDic=  [NSMutableDictionary dictionary];
        [muDic addEntriesFromDictionary:@{@"pic":self.pathArray[i]}];
        [array addObject:muDic];
    }
    NSString *path = [self objectToJson:array];

    NSDictionary *dic=@{
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"rptman":self.nameField.text,
                        @"phone":self.phoneField.text,
                        @"addr":self.addressField.text,
                        @"sn":self.codeField.text,
                        @"errdes":self.decField.text,
                        @"pics":path,
                        @"token":[token getValue]
                        };

    NSString *parameter =[NSString stringWithFormat:@"rptman=%@&phone=%@&addr=%@&sn=%@&errdes=%@&pics=%@&token=%@&appid=1288&motime=%@&sign=%@",self.nameField.text,self.phoneField.text,self.addressField.text,self.codeField.text,self.decField.text,path,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/svc/sendfix";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            [self dismissViewControllerAnimated:YES completion:nil];

        }
        
    } failBlock:^(NSError *error) {
        
    }];
    
}
-(NSString *)objectToJson:(id)obj{
    if (obj == nil) {
        return nil;
    }
    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:obj
                                                       options:0
                                                         error:&error];
    
    if ([jsonData length] && error == nil){
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }else{
        return nil;
    }
}

-(NSString*)dictionaryToJson:(NSDictionary *)dic
{
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}
#pragma mark -- UICollectionViewDataSource
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{

        if (self.photoArray.count<3) {
            return self.photoArray.count+1;
        }else
        {
            return self.photoArray.count;
        }
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{

        if (self.photoArray.count<3) {
            
            UIImage *imageString;
            if (indexPath.row == self.mainArray.count) {
                imageString = nil;
            }else
            {
                imageString  = self.mainArray[indexPath.row];
                
            }
            
            __weak typeof(self)weakSelf = self;
            TTPhotosCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
            //    cell.tailLabel.text = [NSString stringWithFormat:@"我是第%ld个",(long)indexPath.row];
            if (imageString == nil) {
                cell.addBtn.hidden = NO;
                cell.deleteBtn.hidden = YES;
                [cell setAddBlcok:^{
                    [weakSelf didAddAction];
                }];
            }else
            {
                cell.addBtn.hidden = YES;
                cell.deleteBtn.hidden = NO;
                cell.headImage.image = imageString;
                
            }
            cell.cellTag = indexPath.row;
            [cell setDeleteBlcok:^(NSInteger tag) {
                NSLog(@"点击了%d",tag);
                [self.photoArray removeObjectAtIndex:tag];
                [self.mainArray removeObjectAtIndex:tag];
                
                [self.collectionView reloadData];
            }];
            return cell;
        }else
        {
            UIImage *imageString = self.mainArray[indexPath.row];
            TTPhotosCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
            cell.headImage.image = imageString;
            //    cell.tailLabel.text = [NSString stringWithFormat:@"我是第%ld个",(long)indexPath.row];
            //        [cell.headImage sd_setImageWithURL:[NSURL URLWithString:imageString] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            //            NSLog(@"完成");
            //        }];
            cell.cellTag = indexPath.row;
            cell.addBtn.hidden = YES;
            cell.deleteBtn.hidden = NO;
            [cell setDeleteBlcok:^(NSInteger tag) {
                NSLog(@"点击了%d",tag);
                [self.photoArray removeObjectAtIndex:tag];
                [self.mainArray removeObjectAtIndex:tag];
                
                [self.collectionView reloadData];
            }];
            return cell;
        }
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    //    定义一个newPhoto，用来存放我们选择的图片。
    UIImage *newPhoto =[UIImage fixOrientation:[info objectForKey:@"UIImagePickerControllerOriginalImage"]] ;
    //        _headImage.image = newPhoto;
    NSData *imageData = UIImageJPEGRepresentation(newPhoto,0.1f);//第二个参数为压缩倍数
    //    [self saveMusic:imageData];
    [self.photoArray addObject:imageData];
    [self.mainArray addObject:newPhoto];
    [self.collectionView reloadData];
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    return YES;
}
@end
