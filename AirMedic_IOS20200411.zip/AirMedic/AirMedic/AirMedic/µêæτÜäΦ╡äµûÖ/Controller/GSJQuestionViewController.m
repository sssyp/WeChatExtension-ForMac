//
//  GSJQuestionViewController.m
//  AirMedic
//
//  Created by kaka on 2019/9/3.
//  Copyright © 2019 gsj. All rights reserved.
//

#import "GSJQuestionViewController.h"
#import <WebKit/WebKit.h>
@interface GSJQuestionViewController ()
@property (nonatomic,strong) WKWebView *webView;
@property (nonatomic,strong) UIView *headView;
@end

@implementation GSJQuestionViewController
-(UIView *)headView
{
    if (!_headView) {
        _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, 44+22+iPhoneX_SPACE_TOP)];
        [self.view addSubview:_headView];
        _headView.backgroundColor = [UIColor whiteColor];
        
    }
    return _headView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.view.backgroundColor =[UIColor colorWithRed:249/255.0 green:247/255.0 blue:245/255.0 alpha:1.0];
    
    UILabel *headLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,15+22+iPhoneX_SPACE_TOP,ATGetDeviceWidth,19)];
    [self.headView addSubview:headLabel];
    NSMutableAttributedString *headString = [[NSMutableAttributedString alloc] initWithString:self.nameLabel attributes:@{NSFontAttributeName: [UIFont fontWithName:@"PingFang-SC-Medium" size: 16],NSForegroundColorAttributeName: [UIColor blackColor]}];
    headLabel.attributedText = headString;
    headLabel.textAlignment = NSTextAlignmentCenter;
    
    UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(6,34+iPhoneX_SPACE_TOP,23,23)];
    [self.view addSubview:leftBtn];
    [leftBtn setImage:[UIImage imageNamed:@"icon-back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(didMy) forControlEvents:UIControlEventTouchUpInside];
    //
    
    
    
    // Do any additional setup after loading the view.
    self.webView = [[WKWebView alloc]initWithFrame:CGRectMake(0, 66+iPhoneX_SPACE_TOP, ATGetDeviceWidth, ATGetDeviceHeight-66)];
    [self.view addSubview:self.webView];
    
    NSString *imgHtml = [self htmlForJPGImage:[UIImage imageNamed:self.name]];
    [self.webView loadHTMLString:imgHtml baseURL:nil];
}
/// 将 image 包装为 HTML 代码
- (NSString *)htmlForJPGImage:(UIImage *)image {
    NSData *imageData = UIImageJPEGRepresentation(image,1.0f);
    NSString *imageBase64 = [imageData base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    return [NSString stringWithFormat:@"<html><body><div align=center><img src='data:image/jpg;base64,%@'/></div></body></html>",imageBase64];
}
-(void)didMy
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
