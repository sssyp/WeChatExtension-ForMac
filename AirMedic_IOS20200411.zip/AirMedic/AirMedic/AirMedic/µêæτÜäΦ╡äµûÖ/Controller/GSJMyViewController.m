//
//  TTMyViewController.m
//  天天练琴(学生)
//
//  Created by kaka on 2019/3/5.
//  Copyright © 2019年 kaka. All rights reserved.
//

#import "GSJMyViewController.h"
#import "GSJChangeDeviceNameViewController.h"
#import "GSJMaintenanceViewController.h"
#import "GSJMaintenListViewController.h"
#import "GSJChangePassWordViewController.h"
#import "GSJDeviceListViewController.h"
#import "TTLoginViewController.h"
#import "GSJQuestionViewController.h"

@interface GSJMyViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *mainTableView;
@property (nonatomic,strong) UIScrollView *mainScrollView;//主要滑动界面
@property (nonatomic,strong) UIView *alertView;//弹框
@property (nonatomic,strong) UIView *bgView;
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UIImageView *imageView;
@property (nonatomic,strong) UILabel *decLabel;
@property (nonatomic,strong) UIButton *alertBtn;
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,strong) UILabel *alredyLabel;
@property (nonatomic,strong) UILabel *timeLabel;
@property (nonatomic,strong) UILabel *surplusLabel;
@property (nonatomic,strong) UIImageView *headImage;
@property (nonatomic,strong) UILabel *ceshiLabel;
@property (nonatomic,copy) NSString *salary;

@end

@implementation GSJMyViewController
-(UIScrollView *)mainScrollView
{
    if (!_mainScrollView) {
        _mainScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, ATGetDeviceHeight-50)];
        [self.view addSubview:_mainScrollView];
        _mainScrollView.showsVerticalScrollIndicator = FALSE;
        _mainScrollView.showsHorizontalScrollIndicator = FALSE;
        if (@available(iOS 11.0, *)) {
            _mainScrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
            NSLog(@"11.0f");
        } else {
            self.automaticallyAdjustsScrollViewInsets = NO;
            NSLog(@"10f");
        }
    }
    return _mainScrollView;
}
-(UIView *)alertView
{
    
    if (!_alertView) {
        // 遮盖视图
        CGRect frame = [UIScreen mainScreen].bounds;
        _bgView = [[UIView alloc] initWithFrame:frame];
        _bgView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.7f];
        [_bgView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didHidden)]];
        [[UIApplication sharedApplication].keyWindow addSubview:_bgView];
        _bgView.hidden = YES;
        
        _alertView = [[UIView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/2-128, 220, 256, 283)];
        [_bgView addSubview:_alertView];
        _alertView.layer.cornerRadius = 10;
        _alertView.layer.masksToBounds = YES;
        _alertView.backgroundColor = [UIColor whiteColor];
    }
    return _alertView;
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    
//    [self getTeacherHome];
}

//- (void)viewWillDisappear:(BOOL)animated {
//    [super viewWillDisappear:animated];
//
////    [self.navigationController setNavigationBarHidden:NO animated:animated];
//}
-(UITableView *)mainTableView
{
    if (!_mainTableView) {
        _mainTableView = [[UITableView alloc]initWithFrame:CGRectMake(0,0,0,0)];
        [self.view addSubview:_mainTableView];
        if (@available(iOS 11.0, *)) {
            _mainTableView.estimatedRowHeight = 0;
            _mainTableView.estimatedSectionFooterHeight = 0;
            _mainTableView.estimatedSectionHeaderHeight = 0;
            _mainTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        } else {
            self.automaticallyAdjustsScrollViewInsets = NO;
            NSLog(@"10f");
        }
        [_mainTableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.view).offset(0);
            make.right.equalTo(self.view).offset(0);
            make.top.equalTo(self.view).offset(0);
            make.bottom.equalTo(self.view).offset(0);
        }];
        _mainTableView.delegate = self;
        _mainTableView.dataSource = self;
        _mainTableView.tableFooterView = [[UIView alloc]init];
    }
    return _mainTableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //    self.mainTableView.userInteractionEnabled = YES;
    self.mainScrollView.userInteractionEnabled = YES;
    [self initUI];
    //    [self getTeacherHome];
//    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(receiveNotification:) name:@"changeImage" object:nil];
}

-(void)receiveNotification:(NSNotification *)infoNotification {
    NSDictionary *dic = [infoNotification userInfo];
    UIImage *str = [dic objectForKey:@"info"];
    self.headImage.image = str;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)initUI
{
    UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, 170+iPhoneX_SPACE_TOP)];
    [self.mainScrollView addSubview:headView];
//    if (iPhoneX_SPACE_TOP == 24) {
//
//        headView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg-header-wode-1"]];
//
//    }else
//    {
//        headView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg-header-wode"]];
//
//    }
    headView.backgroundColor = [UIColor whiteColor];

    _headImage= [[UIImageView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/2-50, 40+iPhoneX_SPACE_TOP, 100, 100)];
    [headView addSubview:_headImage];
    //    headImage.backgroundColor = [UIColor redColor];
//    [_headImage sd_setImageWithURL:[NSURL URLWithString:@""]];
    _headImage.image = [UIImage imageNamed:@"图标"];
//    _headImage.layer.masksToBounds = YES;
//    _headImage.layer.cornerRadius= 50;
    
//    UIButton *peopleBtn  = [[UIButton alloc]initWithFrame:CGRectMake(14, 67+iPhoneX_SPACE_TOP, 200, 60)];
//    [headView addSubview:peopleBtn];
//    [peopleBtn addTarget:self action:@selector(didPeopleBtn) forControlEvents:UIControlEventTouchUpInside];
    
 NSString  *name =   [[NSUserDefaults standardUserDefaults]valueForKey:@"name"];

    
    _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 140+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 20)];
    [headView addSubview:_nameLabel];
    _nameLabel.text = name;
    _nameLabel.textColor = [UIColor blackColor];
    _nameLabel.font = [UIFont systemFontOfSize:17];
    _nameLabel.textAlignment = NSTextAlignmentCenter;
    
    
    UIView *middleFirstView = [[UIView alloc]initWithFrame:CGRectMake(0, 180+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 250)];
    middleFirstView.backgroundColor = [UIColor whiteColor];
    [self.mainScrollView addSubview:middleFirstView];

        NSArray *firstArray = @[@"矢量智能对象",@"圆角矩形 15",@"图层 5",@"问号",@"圆角矩形 13"];
    //    NSArray *firstArray = @[@"icon-xinzi",@"icon-jianli"];
//    NSArray *firstArray = @[@"icon-jianli"];
        NSArray *firstTitleArray = @[@"更改设备名称",@"售后维修",@"更改密码",@"常见问题",@"日常维护手册"];
//    NSArray *firstTitleArray = @[@"简历"];
    
    for (int i = 0; i<firstArray.count; i++) {
        UIImageView *headImage = [[UIImageView alloc]initWithFrame:CGRectMake(17, 15+50*i, 20, 20)];
        [middleFirstView addSubview:headImage];
        headImage.image = [UIImage imageNamed:firstArray[i]];

        UILabel *title = [[UILabel alloc]initWithFrame:CGRectMake(43 ,50*i, 150, 50)];
        [middleFirstView addSubview:title];
        title.text =firstTitleArray[i];
        title.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1.0];
        title.font= [UIFont systemFontOfSize:14];
        
        UIImageView *rightImage = [[UIImageView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-24-13-12, 20+50*i, 13, 13)];
        [middleFirstView addSubview:rightImage];
        rightImage.image = [UIImage imageNamed:@"icon-jiantou"];
        
        UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(0,50*i,ATGetDeviceWidth-24,50)];
        [middleFirstView addSubview:leftBtn];
        leftBtn.tag = 1000+i;
        [leftBtn addTarget:self action:@selector(didGoTo:) forControlEvents:UIControlEventTouchUpInside];
        
//        if (i!=3) {
            UIView *line = [[UIView alloc]initWithFrame:CGRectMake(21, 50*(i+1), ATGetDeviceWidth-42, 1)];
            [middleFirstView addSubview:line];
            line.backgroundColor = [UIColor colorWithRed:218/255.0 green:218/255.0 blue:218/255.0 alpha:1.0];
//        }
        
    }
    
    self.mainScrollView.contentSize = CGSizeMake(0, middleFirstView.height+middleFirstView.y+iPhoneX_SPACE_TOP);
    
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/2, ATGetDeviceHeight-50, ATGetDeviceWidth/2, 50)];
    [self.view addSubview:btn];
    btn.backgroundColor =  RGB(0x90e1f4);
    [btn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [btn setTitle:@"退出登录" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    btn.tag = 0;
    
    UIButton *registerBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-50, ATGetDeviceWidth/2, 50)];
    [self.view addSubview:registerBtn];
    registerBtn.backgroundColor = RGB(0x0088c7);
    [registerBtn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];
    [registerBtn setTitle:@"首页" forState:UIControlStateNormal];
    [registerBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    registerBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    registerBtn.tag = 1;
}
#pragma mark -点击事件-
-(void)didAction:(UIButton *)btn
{
    if (btn.tag == 1) {
//        TTRegisterViewController *vc = [[TTRegisterViewController alloc]init];
//        [self presentViewController:vc animated:YES completion:nil];
       
            [UIApplication sharedApplication].delegate.window.rootViewController = [GSJDeviceListViewController new];

        
    }else
    {
//        TTPassLoginViewController *vc = [[TTPassLoginViewController alloc]init];
//        [self presentViewController:vc animated:YES completion:nil];
        [UIApplication sharedApplication].delegate.window.rootViewController = [TTLoginViewController new];

        [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"userPhoneName"];
        [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"userPhonePassWord"];
    }
    
}

-(void)didPeopleBtn
{
//    TTMyEditViewController *vc = [[TTMyEditViewController alloc]init];
//    [self.navigationController pushViewController:vc animated:YES];
}
- (void) clearCabage
{
    [MBProgressHUD showMessage:@"正在清除缓存..."];
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
                   , ^{
                       NSString *cachPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory,NSUserDomainMask, YES) objectAtIndex:0];
                       NSArray *files = [[NSFileManager defaultManager] subpathsAtPath:cachPath];
                       for (NSString *p in files) {
                           NSError *error;
                           NSString *path = [cachPath stringByAppendingPathComponent:p];
                           if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
                               [[NSFileManager defaultManager] removeItemAtPath:path error:&error];
                           }
                       }
                       [self performSelectorOnMainThread:@selector(clearCacheSuccess) withObject:nil waitUntilDone:YES];
                   });
}

- (void)clearCacheSuccess
{
    [MBProgressHUD hideHUD];
    [MBProgressHUD animateWithDuration:0.8 animations:^{
        [MBProgressHUD showSuccess:@"清除缓存成功！"  ToView:self.view];
    }];
    
}
-(void)didGoTo:(UIButton *)btn
{
    NSLog(@"%@",btn.titleLabel.text);
    if (btn.tag == 1000) {
        GSJChangeDeviceNameViewController *vc = [[GSJChangeDeviceNameViewController alloc]init];
        [self presentViewController:vc animated:YES completion:nil];
    }
    if (btn.tag == 1001) {
        GSJMaintenListViewController *vc = [[GSJMaintenListViewController alloc]init];
        [self presentViewController:vc animated:YES completion:nil];
    }
    if (btn.tag == 1002) {
        GSJChangePassWordViewController *vc = [[GSJChangePassWordViewController alloc]init];
        [self presentViewController:vc animated:YES completion:nil];
    }
    if (btn.tag == 1003) {
        GSJQuestionViewController *vc = [[GSJQuestionViewController alloc]init];
        vc.name = @"常见问题";
        vc.nameLabel = @"常见问题";
        [self presentViewController:vc animated:YES completion:nil];
        
    }
    if (btn.tag == 1004) {
        GSJQuestionViewController *vc = [[GSJQuestionViewController alloc]init];
        vc.name = @"日常维护";
        vc.nameLabel = @"日常维护手册";
        [self presentViewController:vc animated:YES completion:nil];
    }
    
}

-(void)didHidden
{
    self.bgView.hidden = YES;
}
-(void)didSetAction
{
//    TTSetViewController *vc = [[TTSetViewController alloc]init];
//    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark -获取我的接口-
-(void)getTeacherHome
{

}




@end
