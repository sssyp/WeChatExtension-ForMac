//
//  TTCompanionViewController.m
//  天天练琴(学生)
//
//  Created by kaka on 2019/3/14.
//  Copyright © 2019年 kaka. All rights reserved.
//

#import "GSJMaintenListViewController.h"
#import "GSJDeviceListTableViewCell.h"
#import "GSJSearchDeviceViewController.h"
#import "GSJMaintenanceViewController.h"
#import "GSJMaintenDetailViewController.h"
@interface GSJMaintenListViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIView *middleView;

@property (nonatomic,strong) UITableView *mainTableView;
@property (nonatomic,strong) NSMutableArray *mainArray;

@property (nonatomic,strong) UILabel *noData;//没有数据
@end

@implementation GSJMaintenListViewController
-(UILabel *)noData
{
    if (!_noData) {
        _noData = [[UILabel alloc]initWithFrame:CGRectMake(0, 200, ATGetDeviceWidth, 20)];
        _noData.text = @"暂无设备";
        [_mainTableView addSubview:_noData];
        _noData.textAlignment = NSTextAlignmentCenter;
    }
    return _noData;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getMyfriends];
}
-(UITableView *)mainTableView
{
    if (!_mainTableView) {
        _mainTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 66+iPhoneX_SPACE_TOP, ATGetDeviceWidth, ATGetDeviceHeight-66-50-iPhoneX_SPACE_TOP)];
        [self.view addSubview:_mainTableView];
        if (@available(iOS 11.0, *)) {
            _mainTableView.estimatedRowHeight = 0;
            _mainTableView.estimatedSectionFooterHeight = 0;
            _mainTableView.estimatedSectionHeaderHeight = 0;
            _mainTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        } else {
            self.automaticallyAdjustsScrollViewInsets = NO;
            NSLog(@"10f");
        }
        _mainTableView.delegate = self;
        _mainTableView.dataSource = self;
        _mainTableView.tableFooterView = [[UIView alloc]init];
        _mainTableView.backgroundColor =[UIColor whiteColor];
        _mainTableView.separatorStyle = UITableViewCellEditingStyleNone;     //让tableview不显示分割线
        
        
    }
    return _mainTableView;
}
-(UIView *)headView
{
    if (!_headView) {
        _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, 44+22+iPhoneX_SPACE_TOP)];
        [self.view addSubview:_headView];
        _headView.backgroundColor = [UIColor whiteColor];
        
    }
    return _headView;
}
-(NSMutableArray *)mainArray
{
    if (!_mainArray) {
        _mainArray = [NSMutableArray array];
    }
    return _mainArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    self.view.backgroundColor =[UIColor colorWithRed:249/255.0 green:247/255.0 blue:245/255.0 alpha:1.0];
    
    UILabel *headLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,15+22+iPhoneX_SPACE_TOP,ATGetDeviceWidth,19)];
    [self.headView addSubview:headLabel];
    NSMutableAttributedString *headString = [[NSMutableAttributedString alloc] initWithString:@"售后维修列表" attributes:@{NSFontAttributeName: [UIFont fontWithName:@"PingFang-SC-Medium" size: 16],NSForegroundColorAttributeName: [UIColor blackColor]}];
    headLabel.attributedText = headString;
    headLabel.textAlignment = NSTextAlignmentCenter;
    

//    UIButton *addBtn  = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-80,36,70,19)];
//    [self.headView addSubview:addBtn];
//    //    [btn setImage:[UIImage imageNamed:@"icon-kefu"] forState:UIControlStateNormal];
//    [addBtn setTitle:@"添加申请" forState:UIControlStateNormal];
//    [addBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    [addBtn addTarget:self action:@selector(didAddBtn) forControlEvents:UIControlEventTouchUpInside];
//    addBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-50, ATGetDeviceWidth, 50)];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(didAddBtn) forControlEvents:UIControlEventTouchUpInside];
    [btn setTitle:@"添加售后" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:18];
//    btn.backgroundColor = [UIColor colorWithRed:123/255.0 green:183/255.0 blue:191/255.0 alpha:1.0];
    btn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];

    UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(6,34+iPhoneX_SPACE_TOP,23,23)];
    [self.view addSubview:leftBtn];
    [leftBtn setImage:[UIImage imageNamed:@"icon-back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(didMy) forControlEvents:UIControlEventTouchUpInside];
    //
    //    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(42, 14, 70, 14)];
    //    [self.middleView addSubview:label];
    //    label.text = @"综合(默认)";
    //    label.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0];
    //    label.font = [UIFont systemFontOfSize:14];
    //
    //
    //    UIButton *categoryBtn  = [[UIButton alloc]initWithFrame:CGRectMake(161,14,50,13)];
    //    [self.middleView addSubview:categoryBtn];
    //    [categoryBtn setImage:[UIImage imageNamed:@"icon-drop"] forState:UIControlStateNormal];
    //    [categoryBtn addTarget:self action:@selector(didCategory) forControlEvents:UIControlEventTouchUpInside];
    //    [categoryBtn setTitle:@"分类" forState:UIControlStateNormal];
    //    categoryBtn.titleLabel.font = [UIFont systemFontOfSize:13];
    //    [categoryBtn setTitleColor: [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0] forState:UIControlStateNormal];
    //    CGFloat imageWidth = categoryBtn.imageView.bounds.size.width;
    //    CGFloat labelWidth = categoryBtn.titleLabel.bounds.size.width;
    //    categoryBtn.imageEdgeInsets = UIEdgeInsetsMake(0, labelWidth, 0, -labelWidth);
    //    categoryBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -imageWidth, 0, imageWidth);
    //
    //    UILabel *credit = [[UILabel alloc]initWithFrame:CGRectMake(290, 14, 27, 13)];
    //    [self.middleView addSubview:credit];
    //    credit.text = @"学分";
    //    credit.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0];
    //    credit.font = [UIFont systemFontOfSize:13];
    //
    //
    //    UIButton *upBtn  = [[UIButton alloc]initWithFrame:CGRectMake(324,8,13,13)];
    //    [self.middleView addSubview:upBtn];
    //    [upBtn setImage:[UIImage imageNamed:@"icon-down"] forState:UIControlStateNormal];
    //    [upBtn addTarget:self action:@selector(didUp) forControlEvents:UIControlEventTouchUpInside];
    //
    //    UIButton *downBtn  = [[UIButton alloc]initWithFrame:CGRectMake(324,15,13,13)];
    //    [self.middleView addSubview:downBtn];
    //    [downBtn setImage:[UIImage imageNamed:@"icon-droph"] forState:UIControlStateNormal];
    //    [downBtn addTarget:self action:@selector(didDown) forControlEvents:UIControlEventTouchUpInside];
    //
//    [self.mainArray addObject:@"11"];
//    [self.mainArray addObject:@"11"];
//    [self.mainArray addObject:@"11"];
//    [self.mainArray addObject:@"11"];
//    [self.mainArray addObject:@"11"];
//    [self.mainArray addObject:@"11"];
//    self.mainTableView.userInteractionEnabled = YES;

    
    
    
//    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-50-iPhoneX_SPACE_TOP-iPhoneX_SPACE_BUTTOM, ATGetDeviceWidth, 50)];
//    [self.view addSubview:btn];
//    btn.backgroundColor =  [UIColor colorWithRed:152/255.0 green:203/255.0 blue:214/255.0 alpha:1.0];
//    [btn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];
//    [btn setTitle:@"完成" forState:UIControlStateNormal];
//    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    
    
}
-(void)didAction:(UIButton *)btn
{
    [self dismissViewControllerAnimated:YES completion:nil];
    
}



#pragma maek -点击事件-
-(void)didMy
{
    [self dismissViewControllerAnimated:YES completion:nil];
    
    //    NSLog(@"我的资料");
    //    //把最前面的视图控制器dismiss掉
    //    UIViewController *parentVC = self.presentingViewController;
    //    UIViewController *bottomVC;
    //    while (parentVC) {
    //        bottomVC = parentVC;
    //        parentVC = parentVC.presentingViewController;
    //    }
    //    [bottomVC dismissViewControllerAnimated:NO completion:^{
    //        //dismiss后再切换根视图
    //        [UIApplication sharedApplication].delegate.window.rootViewController = [GSJMyViewController new];
    //    }];
}
-(void)didUp
{
    
}
-(void)didCategory
{
    NSLog(@"点击了分类");
}
-(void)didAddBtn
{
    NSLog(@"点击了添加");
    GSJMaintenanceViewController *vc = [[GSJMaintenanceViewController alloc]init];
    [self presentViewController:vc animated:YES completion:nil];
}
-(void)didBackAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark ------加载tableView-------
-(void)loadNewData
{
    //    NSString *url = @"";
    //    url =ATURLNewLoanList;
    //    NSString *IP = [[PruManerge sharePruManerge]deviceWANIPAdress];
    //    [_mainTableView.footer resetNoMoreData];
    //    [MBProgressHUD showMessage:@"正在加载"];
    //    NSString *time = [[PruManerge sharePruManerge]getTime];
    //    NSDictionary *dic = @{
    //                          @"RequestSource":@"5",
    //                          @"IPAddress":IP,
    //                          @"TimeStamp":time,
    //                          @"page":@"1",
    //                          @"PageSize":@"4"
    //                          };
    //    NSDictionary *dict=@{@"RequestSource":@"5",
    //                         @"IPAddress":IP,
    //                         @"TimeStamp":time,
    //                         @"Token":@"",
    //                         @"page":@"1",
    //                         @"PageSize":@"4",
    //                         @"Signature":[[DivEncode sharePruManerge]getPrukey:dic]};
    //    [HttpTool postWithPath:url params:dict success:^(id JSON) {
    //        [MBProgressHUD hideHUD];
    //        NSString *resultCode = [NSString stringWithFormat:@"%@", JSON[@"ReturnCode"]];
    //        NSString *resultMessage = [NSString stringWithFormat:@"%@", JSON[@"Message"]];
    //        if ( [JSON[@"ReturnCode"] integerValue] ==200) {
    //            [self.mainNewArray removeAllObjects];
    //            ZFFiancialListModel *detailModel = [[ZFFiancialListModel alloc]initWithDictionary:JSON[@"ReturnData"] error:nil];
    //            for (ZFFiancialListDetailModel *dicModel in detailModel.LoanAbstracts) {
    //                [_mainNewArray addObject:dicModel];
    //            }
    //            [self.mainTableView.header endRefreshing];
    //
    //            [self.mainTableView reloadData];
    //        }else
    //        {
    //            NSString *code = [[PruManerge sharePruManerge]errorWithCode:resultCode message:resultMessage interfaceName:url];
    //
    //            ATSHOW_ALERT(code);     }
    //
    //    }failure:^(NSError *error) {
    //        [MBProgressHUD hideHUD];
    //
    //        ATHudError;
    //    }];
}
#pragma mark -UITableViewDelegate-
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.mainArray.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    return 10;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *Id =[NSString stringWithFormat:@"cellId%ld",(long)indexPath.section];
    
    
    GSJDeviceListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Id];
    //    ZFFiancialListDetailModel *model = self.mainNewArray[indexPath.section];
    NSDictionary *dic = self.mainArray[indexPath.section];
    if (!cell) {
        cell = [[GSJDeviceListTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Id];
    }
    cell.backgroundColor= rgba(244, 242, 239, 1);
    
    cell.topImage.hidden = YES;
    cell.middleImage.hidden = YES;
    cell.downImage.hidden = YES;
    cell.topLabel.hidden = YES;
    cell.middleLabel.hidden = YES;
    cell.downLabel.hidden = YES;
    cell.nameField.hidden = YES;
    cell.nameLabel.hidden = YES;
    cell.decLable.hidden = NO;
    cell.decLable.text = [NSString stringWithFormat:@"售后机器序列号\n%@\n创建日期:%@",dic[@"sn"],dic[@"applydate"]];
    cell.decLable.textAlignment = NSTextAlignmentLeft;
//    cell.decLable.text = @"机身序列号\n128941824912491248";
    cell.jianView.hidden = NO;

    
    //    cell.backgroundColor = [UIColor whiteColor];
    //    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    //    [cell.headImage sd_setImageWithURL:[NSURL URLWithString:dic[@"picpath"]]];
    //    cell.nameLabel.text = dic[@"name"];
    //    cell.timeLabel.text = @"购买时间：2019-03-13 17:30";
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic = self.mainArray[indexPath.section];

    GSJMaintenDetailViewController *vc = [[GSJMaintenDetailViewController alloc]init];
    vc.deviceID = dic[@"id"];
    [self presentViewController:vc animated:YES completion:nil];
    //    [self.navigationController pushViewController:[TTOpenDetailViewController alloc] animated:YES];
    //    NSString *loginStr=[[NSUserDefaults standardUserDefaults] objectForKey:@"isLogin"];
    //    if ([loginStr isEqualToString:@"YES"]) {
    //
    //        ZFFiancialListDetailModel *model = self.mainNewArray[indexPath.section];
    //
    //        ZFFinancialNewDetailViewController *vc = [[ZFFinancialNewDetailViewController alloc]init];
    //
    //        [self.navigationController pushViewController:vc animated:YES];
    
    //    }else
    //    {
    //        ZFLoginViewController *DL = [[ZFLoginViewController alloc]init];
    //        [self.navigationController pushViewController:DL animated:YES];
    //    }
}
#pragma mark -获取设备列表-
-(void)getMyfriends
{
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    
    NSDictionary *dic=@{
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"token":[token getValue]
                        };
    NSString *parameter =[NSString stringWithFormat:@"token=%@&appid=1288&motime=%@&sign=%@",[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/svc/fixlist";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        [self.mainArray removeAllObjects];
        if ([response[@"code"] isEqualToString:@"10000"]) {
            [self.mainArray addObjectsFromArray:response[@"data"]];
        }

        [self.mainTableView reloadData];
        if (self.mainArray.count ==0) {
            self.noData.hidden  =NO;
        }else
        {
            self.noData.hidden =YES;
        }
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        self.noData.hidden  =NO;
    }];
    
}

@end
