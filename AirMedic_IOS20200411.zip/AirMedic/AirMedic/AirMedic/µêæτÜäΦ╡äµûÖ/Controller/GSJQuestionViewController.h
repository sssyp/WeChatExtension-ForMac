//
//  GSJQuestionViewController.h
//  AirMedic
//
//  Created by kaka on 2019/9/3.
//  Copyright © 2019 gsj. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GSJQuestionViewController : BaseViewController
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *nameLabel;
@end

NS_ASSUME_NONNULL_END
