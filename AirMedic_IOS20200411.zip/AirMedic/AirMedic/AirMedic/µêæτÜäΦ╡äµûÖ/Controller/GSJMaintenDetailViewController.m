//
//  GSJMaintenanceViewController.m
//  AirMedic
//
//  Created by gsj on 2019/8/10.
//  Copyright © 2019年 gsj. All rights reserved.
//

#import "GSJMaintenDetailViewController.h"

@interface GSJMaintenDetailViewController ()<UITextFieldDelegate>
@property (nonatomic,strong) UITextField *nameField;
@property (nonatomic,strong) UITextField *phoneField;
@property (nonatomic,strong) UITextField *decField;
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIButton *finshBtn;
@property (nonatomic,strong) UIButton *submitBtn;
@property (nonatomic,strong) UITextField *codeField;
@property (nonatomic,assign) NSInteger numTag;

@end

@implementation GSJMaintenDetailViewController
-(UIView *)headView
{
    if (!_headView) {
        _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, 44+22+iPhoneX_SPACE_TOP)];
        [self.view addSubview:_headView];
        _headView.backgroundColor = [UIColor whiteColor];
    }
    return _headView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self getFixdetail];
//    [self initUI:4];
}
#pragma mark -初始化-
-(void)initUI:(NSInteger )num dic:(NSDictionary *)dic
{
    
    if ([dic[@"sts"] integerValue]==5 && [dic[@"step"] integerValue]==1) {
        num =1;
    }
    
    if ([dic[@"sts"] integerValue]==5 && [dic[@"step"] integerValue]==2&&[dic[@"reviewsts"] integerValue]==2) {
        num =2;
    }
    
    if ([dic[@"sts"] integerValue]==5 && [dic[@"step"] integerValue]==2 && [dic[@"reviewsts"] integerValue]==1) {
        num =3;
    }
    
    if ([dic[@"sts"] integerValue]==3&&[dic[@"reviewsts"] integerValue]!=2) {
        num =4;
    }
    
    if ([dic[@"sts"] integerValue]==4) {
        num =5;
    }
    
    self.view.backgroundColor =[UIColor whiteColor];
    
    UILabel *headLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,15+22+iPhoneX_SPACE_TOP,ATGetDeviceWidth,19)];
    [self.headView addSubview:headLabel];
    NSMutableAttributedString *headString = [[NSMutableAttributedString alloc] initWithString:@"售后维修" attributes:@{NSFontAttributeName: [UIFont fontWithName:@"PingFang-SC-Medium" size: 16],NSForegroundColorAttributeName: [UIColor blackColor]}];
    headLabel.attributedText = headString;
    headLabel.textAlignment = NSTextAlignmentCenter;
    
    
    
    UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(6,34+iPhoneX_SPACE_TOP,23,23)];
    [self.view addSubview:leftBtn];
    [leftBtn setImage:[UIImage imageNamed:@"icon-back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(didBack) forControlEvents:UIControlEventTouchUpInside];
    
    
//    UIView *middleView = [[UIView alloc]initWithFrame:CGRectMake(0, 66+iPhoneX_SPACE_TOP+10, ATGetDeviceWidth, ATGetDeviceHeight-iPhoneX_SPACE_TOP-iPhoneX_SPACE_BUTTOM)];
//    [self.view addSubview:middleView];
//    middleView.backgroundColor = [UIColor whiteColor];
    
    NSArray *array = @[@"1",@"2",@"3",@"4",@"5"];
    NSArray *labelArray = @[@"售后申请",@"售后审核",@"售后返厂",@"厂商寄出",@"售后完成"];

    if([dic[@"reviewsts"] integerValue] ==1 &&  [dic[@"sts"] integerValue] ==2)
    {
        num =3;
    }
    
    for (int i = 0; i<5; i++) {
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(20+((ATGetDeviceWidth-140)/4+20)*i, 80+iPhoneX_SPACE_TOP, 20,20 )];
        label.text =array[i];
        [self.view addSubview:label];
        label.font = [UIFont systemFontOfSize:14];
        label.backgroundColor = [UIColor lightGrayColor];
        label.layer.masksToBounds = YES;
        label.layer.cornerRadius = 10;
        label.textAlignment = NSTextAlignmentCenter;
        label.textColor =[UIColor whiteColor];
        
        UILabel *label1 = [[UILabel alloc]initWithFrame:CGRectMake(label.x+label.width, 75+iPhoneX_SPACE_TOP, (ATGetDeviceWidth-140)/4,20 )];
        label1.text =@".........";
        [self.view addSubview:label1];
        label1.textAlignment = NSTextAlignmentCenter;
        label1.textColor = RGB(0x90e1f4);
        if (i==4) {
            label1.hidden = YES;
        }
        
        UILabel *labelt = [[UILabel alloc]initWithFrame:CGRectMake(label.x-20, 100+iPhoneX_SPACE_TOP, 60,20 )];
        labelt.text =labelArray[i];
        [self.view addSubview:labelt];
        labelt.font = [UIFont systemFontOfSize:11];
        labelt.textAlignment = NSTextAlignmentCenter;
        labelt.textColor =[UIColor lightGrayColor];


        if (i<num) {
            label.backgroundColor =  RGB(0x90e1f4);
            labelt.textColor = RGB(0x90e1f4);

        }

        
    }
    
    
    
//    NSArray *titleArray = @[@"报修人",@"联系方式",@"故障描述",@"机身序列号"];
    NSString *two =@"审核完成，请将机器寄回";
    if ([dic[@"reviewsts"] integerValue] ==2) {
        two =@"审核完成，经沟通已解决";
    }
    NSArray *placeArray = @[@"提交售后申请",two,@"请将机器寄送至厂家",@"维修完成。厂商寄回单号：",@"售后完成"];

    
    if ([dic[@"sts"] integerValue]>5) {
        num = 5;
    }
    for (int i =0; i<num; i++) {
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(30, 30*i+150+iPhoneX_SPACE_TOP, 20, 20)];
        label.text =array[i];
        [self.view addSubview:label];
        label.font = [UIFont systemFontOfSize:14];
        label.backgroundColor =  RGB(0x90e1f4);
        label.layer.masksToBounds = YES;
        label.layer.cornerRadius = 10;
        label.textColor =[UIColor whiteColor];
        label.textAlignment = NSTextAlignmentCenter;

        UILabel *labelt = [[UILabel alloc]initWithFrame:CGRectMake(label.x+label.width+20, 30*i+150+iPhoneX_SPACE_TOP, 250,20 )];
        labelt.text =placeArray[i];
        [self.view addSubview:labelt];
        labelt.font = [UIFont systemFontOfSize:13];
        labelt.textColor=  RGB(0x90e1f4);
        
        if (i ==2) {
            UILabel *label2 = [[UILabel alloc]initWithFrame:CGRectMake(label.x+label.width+20, 30*i+150+20+iPhoneX_SPACE_TOP, 250,50 )];
            label2.text =[NSString stringWithFormat:@"快递地址:%@\n联系人:%@\n联系电话:%@",dic[@"svcaddr"][@"addr"],dic[@"svcaddr"][@"linkman"],dic[@"svcaddr"][@"tel"]];
            label2.numberOfLines = 0;
            [self.view addSubview:label2];
            label2.font = [UIFont systemFontOfSize:11];
            label2.textColor =[UIColor lightGrayColor];
            
            self.nameField = [[UITextField alloc]initWithFrame:CGRectMake(label.x+label.width+20, 30*i+150+70+iPhoneX_SPACE_TOP, 250,30 )];
            self.nameField.placeholder =@"请输入寄回快递单号";
            [self.view addSubview:self.nameField];
            self.nameField.font = [UIFont systemFontOfSize:14];
            self.nameField.delegate =self;

            UIView *line = [[UIView alloc]initWithFrame:CGRectMake(label.x+label.width+20, 30*i+150+99+iPhoneX_SPACE_TOP, 250,1 )];
            [self.view addSubview:line];
            line.backgroundColor = [UIColor colorWithRed:218/255.0 green:218/255.0 blue:218/255.0 alpha:1.0];
            
            if ([[dic allKeys]containsObject:@"expno"])
            {
                self.nameField.text = dic[@"expno"];
//                self.nameField.userInteractionEnabled =NO;
            }

        }
        
        if (i ==3) {
            label.frame = CGRectMake(30, 30*i+150+100+iPhoneX_SPACE_TOP, 20, 20);
            labelt.frame = CGRectMake(label.x+label.width+20, 30*i+150+100+iPhoneX_SPACE_TOP, 250,20 );
            
            UILabel *label2 = [[UILabel alloc]initWithFrame:CGRectMake(label.x+label.width+20, 30*i+150+100+20+iPhoneX_SPACE_TOP, 250,20 )];
//            label2.text =@"75166074665225";
            label2.numberOfLines = 0;
            [self.view addSubview:label2];
            label2.font = [UIFont systemFontOfSize:11];
            label2.textColor =[UIColor lightGrayColor];

            
            label2.text =dic[@"fixexpno"];
//            self.nameField.text  = @"4234342342";
            if ([dic[@"sts"] integerValue] ==3) {
                label.hidden = YES;
                labelt.hidden = YES;
                label2.hidden = YES;
            }
            
        }
        if (i==4) {
            label.frame = CGRectMake(30, 30*i+150+100+20+iPhoneX_SPACE_TOP, 20, 20);
            labelt.frame = CGRectMake(label.x+label.width+20, 30*i+150+100+20+iPhoneX_SPACE_TOP, 250,20 );

        }
        
//        UITextField *field = [[UITextField alloc]initWithFrame:CGRectMake(110, 50*i, ATGetDeviceWidth-120, 50)];
//        field.placeholder =placeArray[i];
//        [self.view addSubview:field];
//        field.font = [UIFont systemFontOfSize:14];
//
//        if (i ==0) {
//            self.nameField = field;
//        }
//        if (i ==1) {
//            self.phoneField = field;
//        }
//        if (i ==2) {
//            self.decField = field;
//        }

    }
//
//    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 220, ATGetDeviceWidth, 20)];
//    label.text =@"请上传机器故障图片";
//    [middleView addSubview:label];
//    label.font = [UIFont systemFontOfSize:14];
//    label.textAlignment = NSTextAlignmentCenter;
//
//
//    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(20, 270, 100, 100)];
//    [btn addTarget:self action:@selector(didAddPicture) forControlEvents:UIControlEventTouchUpInside];
//    [middleView addSubview:btn];
//    [btn setTitle:@"添加" forState:UIControlStateNormal];
//    btn.backgroundColor =[UIColor redColor];
    
    
    _finshBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-50, ATGetDeviceWidth, 50)];
    [self.view addSubview:_finshBtn];
//    finshBtn.backgroundColor =  [UIColor colorWithRed:152/255.0 green:203/255.0 blue:214/255.0 alpha:1.0];
    [_finshBtn addTarget:self action:@selector(didDown) forControlEvents:UIControlEventTouchUpInside];
    [_finshBtn setTitle:@"售后结束" forState:UIControlStateNormal];
    [_finshBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _finshBtn.titleLabel.font = [UIFont systemFontOfSize:18];
//    _finshBtn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];
    _finshBtn.backgroundColor = [UIColor redColor];

    _submitBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-50, ATGetDeviceWidth/2, 50)];
    [self.view addSubview:_submitBtn];
    //    finshBtn.backgroundColor =  [UIColor colorWithRed:152/255.0 green:203/255.0 blue:214/255.0 alpha:1.0];
    [_submitBtn addTarget:self action:@selector(didSubmit) forControlEvents:UIControlEventTouchUpInside];
    [_submitBtn setTitle:@"提交" forState:UIControlStateNormal];
    [_submitBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _submitBtn.titleLabel.font = [UIFont systemFontOfSize:18];
    _submitBtn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];
    _submitBtn.hidden = YES;

    if (num ==3 && [dic[@"reviewsts"] integerValue] ==1) {
        [_finshBtn setTitle:@"售后结束" forState:UIControlStateNormal];
        _finshBtn.backgroundColor = [UIColor redColor];
        _finshBtn.frame = CGRectMake(ATGetDeviceWidth/2, ATGetDeviceHeight-50, ATGetDeviceWidth/2, 50);
        _submitBtn.hidden = NO;
    }
    if ([dic[@"reviewsts"] integerValue] ==2) {
        [_finshBtn setTitle:@"售后结束" forState:UIControlStateNormal];
    }
    
    if ([dic[@"step"] integerValue]==2&&[dic[@"reviewsts"] integerValue]==2) {
        [_finshBtn setTitle:@"用户已取消售后" forState:UIControlStateNormal];
        _finshBtn.userInteractionEnabled = NO;
    }
    
    if ([dic[@"step"] integerValue]==2 &&[dic[@"reviewsts"] integerValue]==1) {
        [_finshBtn setTitle:@"用户已取消售后" forState:UIControlStateNormal];
        _finshBtn.userInteractionEnabled = NO;
        _finshBtn.frame = CGRectMake(0, ATGetDeviceHeight-50, ATGetDeviceWidth, 50);
        _submitBtn.hidden = YES;
        _nameField.userInteractionEnabled = NO;

    }
    
    if ([dic[@"step"] integerValue]==1) {
        [_finshBtn setTitle:@"用户已取消售后" forState:UIControlStateNormal];
        _finshBtn.userInteractionEnabled = NO;
    }
    if ([dic[@"sts"] integerValue]==3 &&( ![[dic allKeys] containsObject:@"step"]||[dic[@"step"] isEqualToString:@""])) {
        _finshBtn.hidden = YES;
        _submitBtn.hidden = YES;
        _nameField.userInteractionEnabled = NO;
    }
    
    if (num==4 || num==5) {
        _finshBtn.hidden = YES;
        _submitBtn.hidden = YES;
        _nameField.userInteractionEnabled = NO;
        
    }
//    if (num ==3) {
//        _numTag = 3;
//        [_finshBtn setTitle:@"提交单号" forState:UIControlStateNormal];
//    }
    
//    if (num>=3) {
//        _finshBtn.hidden = NO;
//    }else
//    {
//        _finshBtn.hidden = YES;
//    }

}
#pragma mark -点击事件-
-(void)didSubmit
{
     [self setFixNo];
}
-(void)didDown
{
    UIAlertView *updataAlert = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"是否售后结束? " delegate:self cancelButtonTitle:@"结束" otherButtonTitles:@"不是", nil];
    [updataAlert show];
}
-(void)didAction
{
    if (_numTag ==3) {
       
    }else   if (_numTag ==2) {
    }else
    {
    [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}
-(void)didBack
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -获取售后详情-
-(void)getFixdetail
{
    
//    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    
    NSDictionary *dic=@{
                        @"id":self.deviceID,
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"token":[token getValue]
                        };
    NSString *parameter =[NSString stringWithFormat:@"id=%@&token=%@&appid=1288&motime=%@&sign=%@",self.deviceID,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];

    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/svc/fixdetail";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
//        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            [self initUI:[response[@"data"][@"sts"]integerValue] dic:response[@"data"]];
        }
        
    } failBlock:^(NSError *error) {
//        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
    
}
#pragma mark -提交单号-
-(void)setFixNo
{
    
//    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
    //    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    
    if ([self.nameField.text isEqualToString:@""]) {
        [MBProgressHUD showMessage:@"请输入寄回快递单号"];
        return;
    }
    
    NSDictionary *dic=@{
                        @"id":self.deviceID,
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"token":[token getValue],
                        @"expcorp":@"",
                        @"expno":self.nameField.text
                        };
    NSString *parameter =[NSString stringWithFormat:@"expno=%@&expcorp=%@&id=%@&token=%@&appid=1288&motime=%@&sign=%@",self.nameField.text,@"",self.deviceID,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/svc/fixexpno";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
//        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            [MBProgressHUD showMessage:@"提交完成"];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        
    } failBlock:^(NSError *error) {
//        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
    
}
#pragma mark -完成单号-
-(void)finishFix
{
    
    //    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
    //    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];

    
    NSDictionary *dic=@{
                        @"id":self.deviceID,
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"token":[token getValue]
                        };
    NSString *parameter =[NSString stringWithFormat:@"id=%@&token=%@&appid=1288&motime=%@&sign=%@",self.deviceID,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/svc/fixfinish";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        //        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        
    } failBlock:^(NSError *error) {
        //        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    return YES;
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex ==0) {
            [self finishFix];
    }
}
@end
