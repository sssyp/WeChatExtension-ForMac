//
//  GSJMaintenanceViewController.h
//  AirMedic
//
//  Created by gsj on 2019/8/10.
//  Copyright © 2019年 gsj. All rights reserved.
//

#import "BaseViewController.h"

@interface GSJMaintenanceViewController : BaseViewController

@end
