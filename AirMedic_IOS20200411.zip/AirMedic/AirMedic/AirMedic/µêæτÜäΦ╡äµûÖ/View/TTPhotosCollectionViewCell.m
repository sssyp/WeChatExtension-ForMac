//
//  TTPhotosCollectionViewCell.m
//  天天练琴(学生)
//
//  Created by kaka on 2019/5/28.
//  Copyright © 2019 kaka. All rights reserved.
//
#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define Margin 10
#define itemWH  (ScreenWidth - 4 * Margin-100)/3

#define random(r, g, b, a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)/255.0]
#define randomColor random(arc4random_uniform(256), arc4random_uniform(256), arc4random_uniform(256), arc4random_uniform(256))

#import "TTPhotosCollectionViewCell.h"

@implementation TTPhotosCollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self creatView];
    }
    return self;
}

-(void)creatView{
    _headImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, itemWH, itemWH)];
//    _headImage.backgroundColor = randomColor;
    [self addSubview:_headImage];
    
    _deleteBtn = [[UIButton alloc]initWithFrame:CGRectMake(itemWH-20, 0, 20, 20)];
    [self addSubview:_deleteBtn];
    [_deleteBtn addTarget:self action:@selector(didAction) forControlEvents:UIControlEventTouchUpInside];
    [_deleteBtn setImage:[UIImage imageNamed:@"icon-sahnchu"] forState:UIControlStateNormal];
//    _deleteBtn.backgroundColor = [UIColor redColor];
    
    _addBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, itemWH, itemWH)];
    [self addSubview:_addBtn];
    [_addBtn addTarget:self action:@selector(addAction) forControlEvents:UIControlEventTouchUpInside];
    _addBtn.backgroundColor = [UIColor lightGrayColor];
    [_addBtn setImage:[UIImage imageNamed:@"icon-xiangji 拷贝"] forState:UIControlStateNormal];

    
//    UILabel *tailLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, itemWH - 15, itemWH, 15)];
//    tailLabel.textAlignment = NSTextAlignmentCenter;
//    _tailLabel = tailLabel;
//    [self addSubview:_tailLabel];
}

-(void)setCellTag:(NSInteger)cellTag
{
    _cellTag = cellTag;
}
-(void)didAction
{
    if (self.deleteBlcok) {
        self.deleteBlcok(_cellTag);
    }
}
-(void)addAction
{
    if (self.addBlcok) {
        self.addBlcok();
    }
}
@end
