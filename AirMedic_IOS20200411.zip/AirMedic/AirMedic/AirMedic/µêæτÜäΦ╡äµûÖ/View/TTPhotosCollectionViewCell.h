//
//  TTPhotosCollectionViewCell.h
//  天天练琴(学生)
//
//  Created by kaka on 2019/5/28.
//  Copyright © 2019 kaka. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TTPhotosCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *headImage;
@property (nonatomic,strong) UIButton *deleteBtn;
@property (nonatomic,strong) UIButton *addBtn;
@property (nonatomic,assign) NSInteger cellTag;
@property (nonatomic,copy) void(^deleteBlcok)(NSInteger tag);
@property (nonatomic,copy) void(^addBlcok)(void);

@end

NS_ASSUME_NONNULL_END
