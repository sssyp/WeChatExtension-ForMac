//
//  AppDelegate.m
//  AirMedic
//
//  Created by kaka on 2019/8/8.
//  Copyright © 2019 gsj. All rights reserved.
//

#import "AppDelegate.h"
#import "TTLoginViewController.h"
#import "GSJAddEquipmentViewController.h"
#import "SSKeychain.h"
#import <CoreLocation/CoreLocation.h>
#import <UMCommonLog/UMCommonLogHeaders.h>
#import <UMCommon/UMCommon.h>

#define BOOLFORKEY @"dhGuidePage"
typedef enum {
    
    tagSystemUpdateNoUpdate = 30000,
    tagSystemUpdateNoForce, //非强制更新
    tagSystemUpdateForce,   //强制更新
    
} tagSystemUpdate;

@interface AppDelegate ()<UIAlertViewDelegate,CLLocationManagerDelegate>
{
    NSString *_trackViewUrl;
}
@property (nonatomic,strong ) CLLocationManager *locationManager;//定位服务
@property (nonatomic,copy)    NSString *currentCity;//城市
@property (nonatomic,copy)    NSString *strLatitude;//经度
@property (nonatomic,copy)    NSString *strLongitude;//维度
@end

@implementation AppDelegate
- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
    if (self.allowRotation) {
        return  UIInterfaceOrientationMaskAllButUpsideDown;
    }
    return UIInterfaceOrientationMaskPortrait;
}
// 获取设备uuid
-(NSString *)deviceUUID
{
    return [[[UIDevice currentDevice] identifierForVendor] UUIDString];
}
// 保存uuid到keychain中
-(void)saveUUID
{
    [SSKeychain setPassword:[self deviceUUID] forService:@"1" account:@"1"];
}
// 读取保存在keychain中的uuid
-(NSString *)readUUID
{
    NSString *UUID = [SSKeychain passwordForService:@"1" account:@"1"];
    // 不存在则获取uuid保存到keychain中
    if (!UUID || UUID.length == 0) {
        [self saveUUID];
        UUID = [self deviceUUID];
    }
    return UUID;
}
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [UMCommonLogManager setUpUMCommonLogManager];
    [UMConfigure initWithAppkey:@"5df0f7080cafb2bab1000a1e" channel:@"App Store"];
    [UMConfigure setLogEnabled:YES];

    [NSThread sleepForTimeInterval:0.5];

    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    
    [self systemUpdate];

    if ([CLLocationManager locationServicesEnabled]) {
        _locationManager = [[CLLocationManager alloc]init];
        _locationManager.delegate = self;
        [_locationManager requestAlwaysAuthorization];
        _currentCity = [[NSString alloc]init];
        [_locationManager requestWhenInUseAuthorization];
        _locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        _locationManager.distanceFilter = 5.0;
        [_locationManager startUpdatingLocation];
    }
    
     if (![[NSUserDefaults standardUserDefaults] boolForKey:BOOLFORKEY])
     {
         [[NSUserDefaults standardUserDefaults] setBool:YES forKey:BOOLFORKEY];
         [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"userPhoneName"];
         [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"userPhonePassWord"];
         [[NSUserDefaults standardUserDefaults]setObject:@{} forKey:@"location"];
         [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"name"];
         NSString *uuid =    [self readUUID];
         [[NSUserDefaults standardUserDefaults]setValue:uuid forKey:@"uuid"];
         [[NSUserDefaults standardUserDefaults]synchronize];
         self.window.rootViewController = [[TTLoginViewController alloc]init];
         [self.window makeKeyAndVisible];

     }else
     {
         
//         [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"userPhoneName"];
//         [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"userPhonePassWord"];
         NSString *userName =[[NSUserDefaults standardUserDefaults]valueForKey:@"userPhoneName"];
         if ([userName isEqualToString:@""]) {
             self.window.rootViewController = [[TTLoginViewController alloc]init];
             [self.window makeKeyAndVisible];
         }else
         {
             GSJAddEquipmentViewController *vc = [[GSJAddEquipmentViewController alloc]init];
             vc.login = @"2";
             self.window.rootViewController = vc;
             [self.window makeKeyAndVisible];
         }

     }
    


    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark -- 检查更新
- (void) systemUpdate{
    NSString *currentAppVersion = [self getCurrentLocalVersion];
    NSLog(@"%@",currentAppVersion);
    
    NSDictionary *dic=@{
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"systype":@"2"
                        };
    NSString *parameter =[NSString stringWithFormat:@"systype=%@&appid=1288&motime=%@&sign=%@",@"2",[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/common/getAppVersion";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            self->_trackViewUrl = response[@"data"][@"dwnlnk"];
            int  lastVersionCode = [response[@"data"][@"verno"] intValue];
            if (lastVersionCode >[currentAppVersion intValue]) {
                if ([response[@"data"][@"forcible"] intValue] ==1) {
                    UIAlertView *updataAlert = [[UIAlertView alloc] initWithTitle:@"版本更新" message:@"您需要更新到最新版本才可使用。" delegate:self cancelButtonTitle:@"是否现在更新？" otherButtonTitles:@"退出程序", nil];
                    updataAlert.tag = tagSystemUpdateForce;
                    [updataAlert show];
                }else
                {
                    UIAlertView *updataAlert = [[UIAlertView alloc] initWithTitle:@"版本更新" message:@"发现新版本，您是否现在更新? " delegate:self cancelButtonTitle:@"现在更新" otherButtonTitles:@"以后再说", nil];
                    updataAlert.tag = tagSystemUpdateNoForce;
                    [updataAlert show];

                }
            }
        }
        
    } failBlock:^(NSError *error) {
        
    }];

    
    
    
    
    
    
    
    //    NSString *sysCheckOutUrl = [NSString stringWithFormat:@"%@/sc/version/getNewestVersionByVersionCode/%@?sysType=%@",MAIN_URL,currentAppVersion,@"IOS"];
//    NSString *sysCheckOutUrl = [NSString stringWithFormat:@"%@/version/getNewestVersionByVersionCode/%@?sysType=%@",MAIN_URL,currentAppVersion,@"IOS"];
//    AFHTTPSessionManager *sessionManager = [AFHTTPSessionManager manager];
//    [sessionManager GET:sysCheckOutUrl parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
//    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        NSLog(@"检测更新responseObject %@",responseObject);
//        if (responseObject[@"status"] && responseObject[@"versionCode"]) {
//            int updataTag = [responseObject[@"status"] intValue] + 30000;
//            _trackViewUrl = responseObject[@"newestUrl"];
//            int  lastVersionCode = [responseObject[@"versionCode"] intValue];
//            if (lastVersionCode > [currentAppVersion intValue]) {
//                switch (updataTag) {
//                    case tagSystemUpdateNoUpdate:
//
//                        break;
//                    case tagSystemUpdateNoForce:{
//                        UIAlertView *updataAlert = [[UIAlertView alloc] initWithTitle:@"版本更新" message:@"发现新版本，您是否现在更新? " delegate:self cancelButtonTitle:@"现在更新" otherButtonTitles:@"以后再说", nil];
//                        updataAlert.tag = tagSystemUpdateNoForce;
//                        [updataAlert show];
//                    }
//                        break;
//                    case tagSystemUpdateForce:{
//                        UIAlertView *updataAlert = [[UIAlertView alloc] initWithTitle:@"版本更新" message:@"您需要更新到最新版本才可使用。" delegate:self cancelButtonTitle:@"是否现在更新？" otherButtonTitles:@"退出程序", nil];
//                        updataAlert.tag = tagSystemUpdateForce;
//                        [updataAlert show];
//                    }
//                        break;
//                    default:
//                        break;
//                }
//            }
//        }
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        NSLog(@"检测更新 error %@",error);
//
//    }];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (alertView.tag) {
        case tagSystemUpdateForce:
        {
            /* 更新按钮 */
            if (buttonIndex == 0) {
                NSURL *url = [NSURL URLWithString:_trackViewUrl];
                [[UIApplication sharedApplication]openURL:url];
            }
            /* 未更新，强制退出 */
            else {
            }
            [self exitApplication];
        }
            break;
        case tagSystemUpdateNoForce:
        {
            /* 以后再说 */
            if (buttonIndex == 1) {
                
                //                [self exitApplication];
            }
            /* 现在更新 */
            else {
                NSURL *url = [NSURL URLWithString:_trackViewUrl];
                [[UIApplication sharedApplication]openURL:url];
            }
        }
            break;
        default:
            break;
    }
}
#pragma mark -- 获取当前版本号
- (NSString *)getCurrentLocalVersion {
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    NSString *appVersion = [infoDic objectForKey:@"CFBundleVersion"];
    return appVersion;
}
#pragma mark - 退出app
- (void)exitApplication {
    exit(0);
}



//定位失败
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSDictionary *dic = @{
                          @"city":@"",
                          @"location":@""
                          };
    [[NSUserDefaults standardUserDefaults]setObject:dic forKey:@"location"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    //    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请在设置中打开定位" preferredStyle:UIAlertControllerStyleAlert];
    //    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"打开定位" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    //        NSURL *settingURL = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
    //        [[UIApplication sharedApplication]openURL:settingURL];
    //    }];
    //    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    //
    //    }];
    //    [alert addAction:cancel];
    //    [alert addAction:ok];
    //    [self presentViewController:alert animated:YES completion:nil];
}
//定位成功
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{
    
    [_locationManager stopUpdatingLocation];
    CLLocation *currentLocation = [locations lastObject];
    CLGeocoder *geoCoder = [[CLGeocoder alloc]init];
    //当前的经纬度
    NSLog(@"当前的经纬度 %f,%f",currentLocation.coordinate.latitude,currentLocation.coordinate.longitude);
    
    
    
    //地理反编码 可以根据坐标(经纬度)确定位置信息(街道 门牌等)
    [geoCoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (placemarks.count >0) {
            CLPlacemark *placeMark = placemarks[0];
            _currentCity = placeMark.locality;
            if (!_currentCity) {
                _currentCity = @"无法定位当前城市";
            }
            //看需求定义一个全局变量来接收赋值
            NSLog(@"当前国家 - %@",placeMark.country);//当前国家
            NSLog(@"当前城市 - %@",_currentCity);//当前城市
            NSLog(@"当前位置 - %@",placeMark.subLocality);//当前位置
            NSLog(@"当前街道 - %@",placeMark.thoroughfare);//当前街道
            NSLog(@"具体地址 - %@",placeMark.name);//具体地址
            //            NSString *message = [NSString stringWithFormat:@"%@,%@,%@,%@,%@",placeMark.country,_currentCity,placeMark.subLocality,placeMark.thoroughfare,placeMark.name];
            if ([_currentCity isKindOfClass:[NSNull class]]||(_currentCity==nil)||(self->_currentCity ==NULL)) {
                return ;
            }
            if ([placeMark.subLocality isKindOfClass:[NSNull class]]||(placeMark.subLocality==nil)||(placeMark.subLocality ==NULL)) {
                return ;
            }
            if ([placeMark.subLocality isKindOfClass:[NSNull class]]||(placeMark.subLocality==nil)||(placeMark.subLocality ==NULL)) {
                return ;
            }
            
            NSString *location = [NSString stringWithFormat:@"%@%@",self->_currentCity,placeMark.subLocality];
            //            [[NSUserDefaults standardUserDefaults]setValue:location forKey:@"location"];
            NSDictionary *dic = @{
                                  @"city":location,
                                  @"location":placeMark.subLocality
                                  };
            [[NSUserDefaults standardUserDefaults]setObject:dic forKey:@"location"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            //            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:message delegate:self cancelButtonTitle:nil otherButtonTitles:@"好", nil];
            //            [alert show];
        }else if (error == nil && placemarks.count){
            
            NSLog(@"NO location and error return");
        }else if (error){
            
            NSLog(@"loction error:%@",error);
        }
    }];
    
    //这里的代码是为了判断didUpdateLocations调用了几次 有可能会出现多次调用 为了避免不必要的麻烦 在这里加个if判断 如果大于1.0就return
    NSTimeInterval locationAge = -[currentLocation.timestamp timeIntervalSinceNow];
    if (locationAge > 1.0){//如果调用已经一次，不再执行
        return;
    }
}
@end
