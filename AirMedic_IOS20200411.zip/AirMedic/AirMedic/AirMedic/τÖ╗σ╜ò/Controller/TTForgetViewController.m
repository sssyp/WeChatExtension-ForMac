//
//  TTForgetViewController.m
//  天天练琴(学生)
//
//  Created by kaka on 2019/3/14.
//  Copyright © 2019年 kaka. All rights reserved.
//

#import "TTForgetViewController.h"

@interface TTForgetViewController ()<UITextFieldDelegate>
@property (nonatomic,strong) UITextField *phoneField;
@property (nonatomic,strong) UITextField *codeField;
@property (nonatomic,strong) UITextField *passField;
@property (nonatomic,strong) UIButton *codeBtn;
@end

@implementation TTForgetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.userInteractionEnabled = YES;
    [self initUI];
}
-(void)initUI
{
    UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(14,30+iPhoneX_SPACE_TOP,23,23)];
    [self.view addSubview:leftBtn];
    [leftBtn setImage:[UIImage imageNamed:@"icon-back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(didBackAction) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *title = [[UILabel alloc]initWithFrame:CGRectMake(0, 34+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 17)];
    [self.view addSubview:title];
    title.textAlignment = NSTextAlignmentCenter;
    title.font = [UIFont systemFontOfSize:17];
    title.text = @"找回密码";

//    UILabel *phoneField = [[UILabel alloc]initWithFrame:CGRectMake(20, 101+iPhoneX_SPACE_TOP, 60, 50)];
//    [self.view addSubview:phoneField];
//    phoneField.font = [UIFont systemFontOfSize:14];
//    phoneField.text = @"手机号";
    
    _phoneField = [[UITextField alloc]initWithFrame:CGRectMake(15, 101+iPhoneX_SPACE_TOP, ATGetDeviceWidth-30, 50)];
    [self.view addSubview:_phoneField];
    _phoneField.placeholder = @"请输入手机号";
    _phoneField.font = [UIFont systemFontOfSize:14];
    _phoneField.delegate = self;
    _phoneField.returnKeyType  =UIReturnKeyDone;
    
    
    UIView *phoneLine = [[UIView alloc]initWithFrame:CGRectMake(12,151+iPhoneX_SPACE_TOP,ATGetDeviceWidth-24,1)];
    phoneLine.backgroundColor = [UIColor colorWithRed:204/255.0 green:204/255.0 blue:204/255.0 alpha:1.0];
    [self.view addSubview:phoneLine];
    
//    UILabel *codeField = [[UILabel alloc]initWithFrame:CGRectMake(20, 151+iPhoneX_SPACE_TOP, 60, 50)];
//    [self.view addSubview:codeField];
//    codeField.font = [UIFont systemFontOfSize:14];
//    codeField.text = @"验证码";
    
    _codeField = [[UITextField alloc]initWithFrame:CGRectMake(15, 151+iPhoneX_SPACE_TOP, ATGetDeviceWidth-16-95-30, 50)];
    [self.view addSubview:_codeField];
    _codeField.placeholder = @"请输入验证码";
    _codeField.font = [UIFont systemFontOfSize:14];
    _codeField.delegate = self;
    _codeField.returnKeyType  =UIReturnKeyDone;
    
    
//    _codeBtn  = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-16-95,164+iPhoneX_SPACE_TOP,95,30)];
    _codeBtn  = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-16-95,151+14+iPhoneX_SPACE_TOP,95,30)];
    [self.view addSubview:_codeBtn];
    [_codeBtn addTarget:self action:@selector(didCodeAction) forControlEvents:UIControlEventTouchUpInside];
    [_codeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    _codeBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    //    _codeBtn.layer.borderWidth =1;
    //    _codeBtn.layer.borderColor = RGB(0xF25251).CGColor;
    //    _codeBtn.hidden = YES;
    _codeBtn.layer.cornerRadius = 15;
    _codeBtn.layer.masksToBounds = YES;
    _codeBtn.backgroundColor=RGB(0x90e1f4);
    
    UIView *codeLine = [[UIView alloc]initWithFrame:CGRectMake(15,201+iPhoneX_SPACE_TOP,ATGetDeviceWidth-16-95-30,1)];
    codeLine.backgroundColor = [UIColor colorWithRed:204/255.0 green:204/255.0 blue:204/255.0 alpha:1.0];
    [self.view addSubview:codeLine];

    
//    UILabel *passField = [[UILabel alloc]initWithFrame:CGRectMake(20, 201+iPhoneX_SPACE_TOP, 60, 50)];
//    [self.view addSubview:passField];
//    passField.font = [UIFont systemFontOfSize:14];
//    passField.text = @"验证码";
    
    _passField = [[UITextField alloc]initWithFrame:CGRectMake(15, 201+iPhoneX_SPACE_TOP, ATGetDeviceWidth-30, 50)];
    [self.view addSubview:_passField];
    _passField.placeholder = @"请输入密码";
    _passField.font = [UIFont systemFontOfSize:14];
    _passField.delegate = self;
    _passField.returnKeyType  =UIReturnKeyDone;
    _passField.secureTextEntry = YES;
    
    UIView *passLine = [[UIView alloc]initWithFrame:CGRectMake(12,251+iPhoneX_SPACE_TOP,ATGetDeviceWidth-24,1)];
    passLine.backgroundColor = [UIColor colorWithRed:204/255.0 green:204/255.0 blue:204/255.0 alpha:1.0];
    [self.view addSubview:passLine];
    
    UIButton *  loginBtn  = [[UIButton alloc]initWithFrame:CGRectMake(0,ATGetDeviceHeight-50,ATGetDeviceWidth,50)];
    [self.view addSubview:loginBtn];
    [loginBtn addTarget:self action:@selector(didComplete) forControlEvents:UIControlEventTouchUpInside];
    [loginBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [loginBtn setTitle:@"完成" forState:UIControlStateNormal];
    loginBtn.titleLabel.font = [UIFont systemFontOfSize:18];
//    loginBtn.backgroundColor = [UIColor colorWithRed:123/255.0 green:183/255.0 blue:191/255.0 alpha:1.0];
    loginBtn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];

}


#pragma mark -点击事件-
-(void)didBackAction
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)didComplete
{
    
   
    [self.view endEditing:YES];

    if (_phoneField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入手机号码"];
        return;
    }
    if (_passField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入密码"];
        return;
    }
    if (_codeField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入验证码"];
        return;
    }
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    
    NSDictionary *dic=@{
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"phone":_phoneField.text,
                        @"passwd":_passField.text,
                        @"verifycode":_codeField.text
                        };
    
    NSString *parameter =[NSString stringWithFormat:@"passwd=%@&verifycode=%@&phone=%@&appid=1288&motime=%@&sign=%@",_passField.text,_codeField.text,_phoneField.text,[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/sso/forgotpass";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
                        [self dismissViewControllerAnimated:YES completion:nil];
        }
        
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];

}
-(void)didCodeAction
{
    [self.view endEditing:YES];

    if (_phoneField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入手机号"];
        return;
    }
    
    [self.view endEditing:YES];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    
    NSDictionary *dic=@{
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"smstype":@"FGT",
                        @"phone":_phoneField.text
                        };
    
    NSString *parameter =[NSString stringWithFormat:@"smstype=FGT&phone=%@&appid=1288&motime=%@&sign=%@",_phoneField.text,[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/sso/sendcode";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([response[@"code"] isEqualToString:@"10000"]) {
            [EngineTools timeWithButton:self.codeBtn];
            
        }
        NSLog(@"%@",response);
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
    
//    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//    NSDictionary *dic =@{
//                         @"mobileno":_phoneField.text,
//                         @"mobiletype":@"2",
//                         @"smstype":@"2",
//                         @"type":@"1"
//                         };
//
//    [XDNetworking getWithUrl:TTSmverifcode
//              refreshRequest:NO
//                       cache:NO
//                      params:dic
//               progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
//
//               } successBlock:^(id response)
//     {
//         [MBProgressHUD hideHUDForView:self.view animated:YES];
//         NSLog(@"%@",response);
//         if ([response[@"ret"] isEqualToString:@"00000"]) {
//             [EngineTools timeWithButton:self.codeBtn];
//
//         }else
//         {
//             [MBProgressHUD showMessage:response[@"msg"]];
//
//         }
//
//     } failBlock:^(NSError *error) {
//         NSLog(@"%@",error);
//         [MBProgressHUD hideHUDForView:self.view animated:YES];
//     }];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    return YES;
}
@end
