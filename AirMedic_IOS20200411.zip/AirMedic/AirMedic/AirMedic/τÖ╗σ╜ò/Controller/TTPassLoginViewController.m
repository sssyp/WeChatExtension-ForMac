//
//  TTPassLoginViewController.m
//  天天练琴(学生)
//
//  Created by kaka on 2019/3/14.
//  Copyright © 2019年 kaka. All rights reserved.
//

#import "TTPassLoginViewController.h"
//#import "ATTabBarController.h"
#import "TTForgetViewController.h"
#import "DHGuidePageHUD.h"
#import "GSJAddEquipmentViewController.h"
#import "GSJDeviceListViewController.h"
@interface TTPassLoginViewController ()<UITextFieldDelegate>
@property (nonatomic,strong) UITextField *phoneField;
@property (nonatomic,strong) UITextField *passField;
@property (nonatomic,strong) UIView *line;
@property (nonatomic,strong) UIButton *forgetBtn;
@property (nonatomic,strong) UIButton *codeBtn;
@property (nonatomic,strong) UIButton *passBtn;
@property (nonatomic,strong) UIButton *vCodeBtn;
@property (nonatomic,assign) NSInteger selectTag;

@property (nonatomic,assign) NSInteger remeberYes;//1表示点击了记住密码

@end

@implementation TTPassLoginViewController
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.view.hidden = NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _selectTag = 0;
    self.view.userInteractionEnabled = YES;
    [self initUI];
  
    
    // Do any additional setup after loading the view.

}
-(void)initUI
{
    UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(14,30+iPhoneX_SPACE_TOP,23,23)];
    [self.view addSubview:leftBtn];
    [leftBtn setImage:[UIImage imageNamed:@"icon-back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(didBackAction) forControlEvents:UIControlEventTouchUpInside];
    
//    _passBtn  = [[UIButton alloc]initWithFrame:CGRectMake(68,34+iPhoneX_SPACE_TOP,70,17)];
//    [self.view addSubview:_passBtn];
//    [_passBtn addTarget:self action:@selector(didSelectAction:) forControlEvents:UIControlEventTouchUpInside];
//    [_passBtn setTitleColor:[UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0] forState:UIControlStateSelected];
//    [_passBtn setTitleColor:[UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1.0] forState:UIControlStateNormal];
//    [_passBtn setTitle:@"密码登录" forState:UIControlStateNormal];
//    _passBtn.titleLabel.font = [UIFont systemFontOfSize:16];
//    _passBtn.selected = YES;
//    _passBtn.tag = 0;
//
//
//    _vCodeBtn  = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-80-89,34+iPhoneX_SPACE_TOP,89,17)];
//    [self.view addSubview:_vCodeBtn];
//    [_vCodeBtn addTarget:self action:@selector(didSelectAction:) forControlEvents:UIControlEventTouchUpInside];
//    [_vCodeBtn setTitleColor:[UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0] forState:UIControlStateSelected];
//    [_vCodeBtn setTitleColor:[UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1.0] forState:UIControlStateNormal];
//    [_vCodeBtn setTitle:@"验证码登录" forState:UIControlStateNormal];
//    _vCodeBtn.titleLabel.font = [UIFont systemFontOfSize:16];
//    _vCodeBtn.tag = 1;

//
//    _line = [[UIView alloc]initWithFrame:CGRectMake(75,65+iPhoneX_SPACE_TOP,50,2)];
//    _line.backgroundColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0];
//    [self.view addSubview:_line];
//    _line.layer.cornerRadius = 0.5;
//    _line.layer.masksToBounds = YES;
    
    UILabel *title = [[UILabel alloc]initWithFrame:CGRectMake(0, 20+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 50)];
    [self.view addSubview:title];
    title.font = [UIFont systemFontOfSize:14];
    title.text = @"用户登录";
    title.textAlignment = NSTextAlignmentCenter;
    
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 80+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 20)];
    [self.view addSubview:titleLabel];
    titleLabel.font = [UIFont systemFontOfSize:16];
    titleLabel.text = @"登录";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    UILabel *titl = [[UILabel alloc]initWithFrame:CGRectMake(0, 100+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 20)];
    [self.view addSubview:titl];
    titl.font = [UIFont systemFontOfSize:12];
    titl.text = @"关爱宠物健康";
    titl.textAlignment = NSTextAlignmentCenter;
    titl.textColor =  RGB(0x90e1f4);
    
//
//    UILabel *phoneField = [[UILabel alloc]initWithFrame:CGRectMake(15, 101+iPhoneX_SPACE_TOP, 60, 50)];
//    [self.view addSubview:phoneField];
//    phoneField.font = [UIFont systemFontOfSize:14];
//    phoneField.text = @"手机号";
    
    _phoneField = [[UITextField alloc]initWithFrame:CGRectMake(15, 120+iPhoneX_SPACE_TOP, ATGetDeviceWidth-30, 50)];
    [self.view addSubview:_phoneField];
    _phoneField.placeholder = @"请输入手机号码";
    _phoneField.font = [UIFont systemFontOfSize:14];
//    _phoneField.text = @"15155355241";
//    _phoneField.text = @"18061420125";
    _phoneField.delegate = self;
    _phoneField.returnKeyType  =UIReturnKeyDone;
    
    UIView *phoneLine = [[UIView alloc]initWithFrame:CGRectMake(15,170+iPhoneX_SPACE_TOP,ATGetDeviceWidth-30,1)];
    phoneLine.backgroundColor = [UIColor colorWithRed:204/255.0 green:204/255.0 blue:204/255.0 alpha:1.0];
    [self.view addSubview:phoneLine];
    
//    UILabel *passField = [[UILabel alloc]initWithFrame:CGRectMake(15, 151+iPhoneX_SPACE_TOP, 60, 50)];
//    [self.view addSubview:passField];
//    passField.font = [UIFont systemFontOfSize:14];
//    passField.text = @"密  码";
    
    _passField = [[UITextField alloc]initWithFrame:CGRectMake(15, 171+iPhoneX_SPACE_TOP, ATGetDeviceWidth-30, 50)];
    [self.view addSubview:_passField];
    _passField.placeholder = @"请输入密码";
    _passField.font = [UIFont systemFontOfSize:14];
//    _passField.text = @"123456";
//    _passField.text = @"768725";
    _passField.secureTextEntry = YES;
    _passField.delegate = self;
    _passField.returnKeyType  =UIReturnKeyDone;
    
    UIButton *keyBtn =[[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-50, 171+iPhoneX_SPACE_TOP+20, 25, 14)];
    [self.view addSubview:keyBtn];
    [keyBtn addTarget:self action:@selector(didShowAction:) forControlEvents:UIControlEventTouchUpInside];
    [keyBtn setImage:[UIImage imageNamed:@"icon_bukejian"] forState:UIControlStateNormal];
    [keyBtn setImage:[UIImage imageNamed:@"icon_kejian"] forState:UIControlStateSelected];
//    keyBtn.backgroundColor= [UIColor redColor];
    
    
//    UIButton *remeberBtn  = [[UIButton alloc]initWithFrame:CGRectMake(15,221+iPhoneX_SPACE_TOP,30,50)];
//    [self.view addSubview:remeberBtn];
//    [remeberBtn addTarget:self action:@selector(didRemeber:) forControlEvents:UIControlEventTouchUpInside];
//    remeberBtn.titleLabel.font = [UIFont systemFontOfSize:14];
//    remeberBtn.backgroundColor =[UIColor blueColor];
//    [keyBtn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
//    [keyBtn setImage:[UIImage imageNamed:@""] forState:UIControlStateSelected];
//    
//    UILabel *remeber = [[UILabel alloc]initWithFrame:CGRectMake(50, 221+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 50)];
//    [self.view addSubview:remeber];
//    remeber.font = [UIFont systemFontOfSize:12];
//    remeber.text = @"记住密码";

    
    _forgetBtn  = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-16-80,221+iPhoneX_SPACE_TOP,80,50)];
    [self.view addSubview:_forgetBtn];
    [_forgetBtn addTarget:self action:@selector(didForgetAction) forControlEvents:UIControlEventTouchUpInside];
    [_forgetBtn setTitleColor:rgba(153, 153, 153, 1) forState:UIControlStateNormal];
//    [_forgetBtn setImage:[UIImage imageWithColor:[UIColor redColor]] forState:UIControlStateNormal];
    [_forgetBtn setTitle:@"忘记密码" forState:UIControlStateNormal];
    _forgetBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    [_forgetBtn layoutButtonWithEdgeInsetsStyle:MKButtonEdgeInsetsStyleLeft imageTitleSpace:10];
    
    
    UILabel *tip = [[UILabel alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-200, ATGetDeviceWidth, 20)];
//    tip.text = @"登录即代表您已经同意《隐私政策》";
    [self.view addSubview:tip];
//    NSString *str =@"登录即代表您已经同意《隐私政策》";
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:@"登录即代表您已经同意《隐私政策》"];
    NSRange range1 = [[str string] rangeOfString:@"登录即代表您已经同意"];
    [str addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:14] range:range1];
    NSRange range2 = [[str string] rangeOfString:@"《隐私政策》"];
    [str addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:14] range:range2];
    [str addAttribute:NSForegroundColorAttributeName value:RGB(0x90e1f4) range:range2];//颜色

    tip.attributedText = str;
    tip.textAlignment = NSTextAlignmentCenter;
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-200, ATGetDeviceWidth, 20)];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(didGoto) forControlEvents:UIControlEventTouchUpInside];
//
//    _codeBtn  = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-16-95,164+iPhoneX_SPACE_TOP,95,30)];
//    [self.view addSubview:_codeBtn];
//    [_codeBtn addTarget:self action:@selector(didCodeAction) forControlEvents:UIControlEventTouchUpInside];
//    [_codeBtn setTitleColor:[UIColor colorWithRed:242/255.0 green:82/255.0 blue:81/255.0 alpha:1.0] forState:UIControlStateNormal];
//    [_codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
//    _codeBtn.titleLabel.font = [UIFont systemFontOfSize:14];
//    _codeBtn.layer.borderWidth =1;
//    _codeBtn.layer.borderColor = RGB(0xF25251).CGColor;
//    _codeBtn.hidden = YES;
//    _codeBtn.layer.cornerRadius = 5;
//    _codeBtn.layer.masksToBounds = YES;
    
    UIView *passLine = [[UIView alloc]initWithFrame:CGRectMake(15,221+iPhoneX_SPACE_TOP,ATGetDeviceWidth-30,1)];
    passLine.backgroundColor = [UIColor colorWithRed:204/255.0 green:204/255.0 blue:204/255.0 alpha:1.0];
    [self.view addSubview:passLine];
    
    UIButton *  loginBtn  = [[UIButton alloc]initWithFrame:CGRectMake(0,ATGetDeviceHeight-50,ATGetDeviceWidth,50)];
    [self.view addSubview:loginBtn];
    [loginBtn addTarget:self action:@selector(didLoginAction) forControlEvents:UIControlEventTouchUpInside];
    [loginBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    loginBtn.titleLabel.font = [UIFont systemFontOfSize:18];
//    loginBtn.backgroundColor = [UIColor colorWithRed:123/255.0 green:183/255.0 blue:191/255.0 alpha:1.0];
    
    loginBtn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];
//    UIButton *agreeBtn  = [[UIButton alloc]initWithFrame:CGRectMake(88,360,23,23)];
//    [self.view addSubview:agreeBtn];
//    [agreeBtn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];
//    [agreeBtn setImage:[UIImage imageNamed:@"dian-s"] forState:UIControlStateSelected];
//    [agreeBtn setImage:[UIImage imageNamed:@"dian-n"] forState:UIControlStateNormal];
//    
//    UILabel *agree = [[UILabel alloc]initWithFrame:CGRectMake(agreeBtn.x+agreeBtn.width+3, 366, 150, 12)];
//    agree.text = @"同意(天天练琴用户协议)";
//    [self.view addSubview:agree];
//    agree.font = [UIFont systemFontOfSize:12];
    
    NSString *userPhoneName = [[NSUserDefaults standardUserDefaults]valueForKey:@"userPhoneName"];
    NSString *userPhonePassWord = [[NSUserDefaults standardUserDefaults]valueForKey:@"userPhonePassWord"];
    if (![userPhoneName isEqualToString:@""]) {
        self.phoneField.text = userPhoneName;
        self.passField.text = userPhonePassWord;
    }

}

#pragma mark -点击事件-
-(void)didGoto
{
    WebController *web = [[WebController alloc]init];
    web.type = 2;
    web.submitURL = [NSURL URLWithString:@"http://www.interlinx.cn/iosprivacypolicy/"];
    if ([[web.submitURL absoluteString]isEqualToString:@""]) {
        return;
    }
    [self presentViewController:web animated:YES completion:nil];
}
-(void)didRemeber:(UIButton *)btn
{
    btn.selected =!btn.selected;
    if (btn.selected) {
        NSLog(@"记住密码");
        btn.backgroundColor =[UIColor redColor];
        _remeberYes =1;
    }else
    {
        NSLog(@"不记住密码");
        btn.backgroundColor =[UIColor blueColor];
        _remeberYes =-1;

    }
}
-(void)didShowAction:(UIButton *)btn
{
    btn.selected =!btn.selected;
    if (btn.selected) {
        _passField.secureTextEntry = NO;
    }else
    {
        _passField.secureTextEntry = YES;
    }
}

-(void)didAction:(UIButton *)btn
{
    btn.selected = !btn.selected;
    if (btn.selected) {
        _selectTag = 1;
    }else
    {
        _selectTag = 0;
    }
}
-(void)didBackAction
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)didLoginAction
{
//    [UIApplication sharedApplication].keyWindow.rootViewController = [[ATTabBarController alloc] init];
//    if (_passBtn.selected ==YES) {
        [self getLogin];

//    }else
//    {
//        [self getCode];
//    }
}
-(void)didSelectAction:(UIButton *)btn
{
    if (btn.tag == 0) {
        _codeBtn.hidden = YES;
        _forgetBtn.hidden = NO;
        _passBtn.selected = YES;
        _vCodeBtn.selected = NO;
        _line.frame = CGRectMake(75,65+iPhoneX_SPACE_TOP,50,2);

    }else
    {
        _codeBtn.hidden = NO;
        _forgetBtn.hidden = YES;
        _passBtn.selected = NO;
        _vCodeBtn.selected = YES;
        _line.frame = CGRectMake(ATGetDeviceWidth-65-89,65+iPhoneX_SPACE_TOP,50,2);

    }
}

-(void)didForgetAction
{
    TTForgetViewController *vc = [[TTForgetViewController alloc]init];
    [self presentViewController:vc animated:YES completion:nil];
}
#pragma mark -登录-
-(void)getLogin
{
    if (_phoneField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入手机号码"];
        return;
    }
    if (_passField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入密码"];
        return;
    }


    [self.view endEditing:YES];
    NSString *uuid = [[NSUserDefaults standardUserDefaults]valueForKey:@"uuid"];

    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"appid=1288&mac=%@&motime=%@&passwd=%@&phone=%@&%@",uuid,[[PruManerge sharePruManerge]getTime],_passField.text,_phoneField.text,@"interlnx&aY4N!bAAds"];
//    [MBProgressHUD showMessage:@"正在加载": self.view animated:YES];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSDictionary *dic=@{
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"passwd":_passField.text,
                        @"phone":_phoneField.text,
                        @"mac":uuid
                        };

    NSString *parameter =[NSString stringWithFormat:@"passwd=%@&mac=%@&phone=%@&appid=1288&motime=%@&sign=%@",_passField.text,uuid,_phoneField.text,[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];

    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/sso/login";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"])
        {
            [[NSUserDefaults standardUserDefaults]setValue:self.phoneField.text forKey:@"userPhoneName"];
            [[NSUserDefaults standardUserDefaults]setValue:self.passField.text forKey:@"userPhonePassWord"];
            [token whriteValue:response[@"data"][@"token"]];
            [[NSUserDefaults standardUserDefaults]setValue:response[@"data"][@"nickname"] forKey:@"name"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            if ([response[@"data"][@"dvccnt"] integerValue ] ==0) {
                GSJAddEquipmentViewController *vc = [[GSJAddEquipmentViewController alloc]init];
                vc.login = @"2";
                [self presentViewController:vc animated:YES completion:nil];
            }else
            {
                GSJDeviceListViewController *vc = [[GSJDeviceListViewController alloc]init];
                [self presentViewController:vc animated:YES completion:nil];
            }
        }else
        {
            [MBProgressHUD showMessage:response[@"msg"]];
        }
        
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
    
}



   
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    return YES;
}
@end
