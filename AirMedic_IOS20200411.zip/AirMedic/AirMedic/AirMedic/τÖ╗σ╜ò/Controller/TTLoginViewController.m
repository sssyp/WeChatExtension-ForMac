//
//  TTLoginViewController.m
//  天天练琴(学生)
//
//  Created by kaka on 2019/3/14.
//  Copyright © 2019年 kaka. All rights reserved.
//


#import "TTLoginViewController.h"
#import "TTRegisterViewController.h"
#import "TTPassLoginViewController.h"

#import <CoreLocation/CoreLocation.h>

@interface TTLoginViewController ()<CLLocationManagerDelegate>
@property (nonatomic,strong ) CLLocationManager *locationManager;//定位服务
@property (nonatomic,copy)    NSString *currentCity;//城市
@property (nonatomic,copy)    NSString *strLatitude;//经度
@property (nonatomic,copy)    NSString *strLongitude;//维度

@end

@implementation TTLoginViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
//    if ([CLLocationManager locationServicesEnabled]) {
//        _locationManager = [[CLLocationManager alloc]init];
//        _locationManager.delegate = self;
//        [_locationManager requestAlwaysAuthorization];
//        _currentCity = [[NSString alloc]init];
//        [_locationManager requestWhenInUseAuthorization];
//        _locationManager.desiredAccuracy = kCLLocationAccuracyBest;
//        _locationManager.distanceFilter = 5.0;
//        [_locationManager startUpdatingLocation];
//    }
   
}
//定位失败
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSDictionary *dic = @{
                          @"city":@"",
                          @"location":@""
                          };
    [[NSUserDefaults standardUserDefaults]setObject:dic forKey:@"location"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
//    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请在设置中打开定位" preferredStyle:UIAlertControllerStyleAlert];
//    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"打开定位" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//        NSURL *settingURL = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
//        [[UIApplication sharedApplication]openURL:settingURL];
//    }];
//    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
//        
//    }];
//    [alert addAction:cancel];
//    [alert addAction:ok];
//    [self presentViewController:alert animated:YES completion:nil];
}
//定位成功
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{
    
    [_locationManager stopUpdatingLocation];
    CLLocation *currentLocation = [locations lastObject];
    CLGeocoder *geoCoder = [[CLGeocoder alloc]init];
    //当前的经纬度
    NSLog(@"当前的经纬度 %f,%f",currentLocation.coordinate.latitude,currentLocation.coordinate.longitude);
    
    
    
    //地理反编码 可以根据坐标(经纬度)确定位置信息(街道 门牌等)
    [geoCoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (placemarks.count >0) {
            CLPlacemark *placeMark = placemarks[0];
            _currentCity = placeMark.locality;
            if (!_currentCity) {
                _currentCity = @"无法定位当前城市";
            }
            //看需求定义一个全局变量来接收赋值
            NSLog(@"当前国家 - %@",placeMark.country);//当前国家
            NSLog(@"当前城市 - %@",_currentCity);//当前城市
            NSLog(@"当前位置 - %@",placeMark.subLocality);//当前位置
            NSLog(@"当前街道 - %@",placeMark.thoroughfare);//当前街道
            NSLog(@"具体地址 - %@",placeMark.name);//具体地址
//            NSString *message = [NSString stringWithFormat:@"%@,%@,%@,%@,%@",placeMark.country,_currentCity,placeMark.subLocality,placeMark.thoroughfare,placeMark.name];
            if ([_currentCity isKindOfClass:[NSNull class]]||(_currentCity==nil)||(self->_currentCity ==NULL)) {
                return ;
            }
            if ([placeMark.subLocality isKindOfClass:[NSNull class]]||(placeMark.subLocality==nil)||(placeMark.subLocality ==NULL)) {
                return ;
            }
            if ([placeMark.subLocality isKindOfClass:[NSNull class]]||(placeMark.subLocality==nil)||(placeMark.subLocality ==NULL)) {
                return ;
            }
            
            NSString *location = [NSString stringWithFormat:@"%@%@",self->_currentCity,placeMark.subLocality];
//            [[NSUserDefaults standardUserDefaults]setValue:location forKey:@"location"];
            NSDictionary *dic = @{
                                  @"city":location,
                                  @"location":placeMark.subLocality
                                  };
            [[NSUserDefaults standardUserDefaults]setObject:dic forKey:@"location"];
            [[NSUserDefaults standardUserDefaults]synchronize];

//            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:message delegate:self cancelButtonTitle:nil otherButtonTitles:@"好", nil];
//            [alert show];
        }else if (error == nil && placemarks.count){
            
            NSLog(@"NO location and error return");
        }else if (error){
            
            NSLog(@"loction error:%@",error);
        }
    }];
    
    //这里的代码是为了判断didUpdateLocations调用了几次 有可能会出现多次调用 为了避免不必要的麻烦 在这里加个if判断 如果大于1.0就return
    NSTimeInterval locationAge = -[currentLocation.timestamp timeIntervalSinceNow];
    if (locationAge > 1.0){//如果调用已经一次，不再执行
        return;
    }
}


-(void)initUI
{
    self.view.userInteractionEnabled = YES;
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIView *mainView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, ATGetDeviceHeight-50)];
    [self.view addSubview:mainView];
    
    UIImageView *backView = [[UIImageView alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-250)/2, 100, 250, 250)];
    [mainView addSubview:backView];
//    backView.image = [UIImage imageNamed:@"bg"];
    backView.contentMode = UIViewContentModeScaleAspectFill;
    backView.image = [UIImage imageNamed:@"注册界面机器俯瞰图8.210"];
    backView.userInteractionEnabled = YES;
 
    UILabel *title  = [[UILabel alloc]initWithFrame:CGRectMake(0, 400, ATGetDeviceWidth, 20)];
    [mainView addSubview:title];
    title.text = @"欢迎";
    title.textAlignment = NSTextAlignmentCenter;
    title.font = [UIFont systemFontOfSize:16];
    
    UILabel *device  = [[UILabel alloc]initWithFrame:CGRectMake(0, 450, ATGetDeviceWidth, 20)];
    [mainView addSubview:device];
    device.text = @"My AIR MEDIC";
    device.textAlignment = NSTextAlignmentCenter;
    device.font = [UIFont systemFontOfSize:14];
    
    mainView.alpha= 0;
    [UIView animateWithDuration:2 animations:^{
        mainView.alpha = 1;
    }];
    
    
//    UIImageView *logo = [[UIImageView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/2-60, 87, 120, 120)];
//    [backView addSubview:logo];
//    logo.image = [UIImage imageNamed:@"logo"];
//    
//    UIImageView *next = [[UIImageView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/2-58, 209, 116, 26)];
//    [backView addSubview:next];
//    next.image = [UIImage imageNamed:@"矢量智能对象"];
//    
//    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/2-131, 298, 263, 70)];
//    [backView addSubview:image];
//    image.image = [UIImage imageNamed:@"slogan"];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/2, ATGetDeviceHeight-50, ATGetDeviceWidth/2, 50)];
    [self.view addSubview:btn];
    btn.backgroundColor = RGB(0x90e1f4);
    [btn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];

    [btn setTitle:@"登录" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    btn.tag = 0;

    UIButton *registerBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-50, ATGetDeviceWidth/2, 50)];
    [self.view addSubview:registerBtn];
    registerBtn.backgroundColor = RGB(0x0088c7);
    [registerBtn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];
    [registerBtn setTitle:@"新用户" forState:UIControlStateNormal];
    [registerBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    registerBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    registerBtn.tag = 1;
    

    

    
}

-(void)didAction:(UIButton *)btn
{
    if (btn.tag == 1) {
        TTRegisterViewController *vc = [[TTRegisterViewController alloc]init];
        [self presentViewController:vc animated:YES completion:nil];
    }else
    {
        TTPassLoginViewController *vc = [[TTPassLoginViewController alloc]init];
        [self presentViewController:vc animated:YES completion:nil];
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
