//
//  TTRegisterViewController.m
//  天天练琴(学生)
//
//  Created by kaka on 2019/3/14.
//  Copyright © 2019年 kaka. All rights reserved.
//

#import "TTRegisterViewController.h"
//#import "ATTabBarController.h"
#import "HQPickerView.h"
#import "GSJAddEquipmentViewController.h"
#import "GSJDeviceListViewController.h"
@interface TTRegisterViewController ()<HQPickerViewDelegate,UITextFieldDelegate>
@property (nonatomic,strong) UITextField *phoneField;
@property (nonatomic,strong) UITextField *codeField;
@property (nonatomic,strong) UITextField *passField;
@property (nonatomic,strong) UITextField *musicalField;
@property (nonatomic,strong) UIButton *codeBtn;
@property (nonatomic,strong) NSMutableArray *typeArray;
@property (nonatomic,strong) NSMutableArray *typeIdArray;
@property (nonatomic,assign) NSInteger selectTag;
@property (nonatomic,strong) UIImageView *agreeImage;

@property (nonatomic,strong) HQPickerView *picker;
@end

@implementation TTRegisterViewController
-(NSMutableArray *)typeArray
{
    if (!_typeArray) {
        _typeArray = [NSMutableArray array];
        
    }
    return _typeArray;
}
-(NSMutableArray *)typeIdArray
{
    if (!_typeIdArray) {
        _typeIdArray = [NSMutableArray array];
        
    }
    return _typeIdArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.userInteractionEnabled = YES;
    _selectTag = 0;

    [self initUI];
}
-(void)initUI
{
    UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(14,30+iPhoneX_SPACE_TOP,23,23)];
    [self.view addSubview:leftBtn];
    [leftBtn setImage:[UIImage imageNamed:@"icon-back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(didBackAction) forControlEvents:UIControlEventTouchUpInside];
//    leftBtn.backgroundColor = [UIColor redColor];
    
    UILabel *title = [[UILabel alloc]initWithFrame:CGRectMake(0, 34+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 17)];
    [self.view addSubview:title];
    title.textAlignment = NSTextAlignmentCenter;
    title.font = [UIFont systemFontOfSize:15];
    title.text = @"新用户";
    
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 80+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 17)];
    [self.view addSubview:titleLabel];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.font = [UIFont systemFontOfSize:17];
    titleLabel.text = @"新用户注册";
    
//    UILabel *phoneField = [[UILabel alloc]initWithFrame:CGRectMake(15, 101+iPhoneX_SPACE_TOP, 60, 50)];
//    [self.view addSubview:phoneField];
//    phoneField.font = [UIFont systemFontOfSize:14];
//    phoneField.text = @"手机号";
    
    _phoneField = [[UITextField alloc]initWithFrame:CGRectMake(15, 101+iPhoneX_SPACE_TOP, ATGetDeviceWidth-16-95-30, 50)];
    [self.view addSubview:_phoneField];
    _phoneField.placeholder = @"请输入手机号码";
    _phoneField.font = [UIFont systemFontOfSize:14];
    _phoneField.delegate = self;
    _phoneField.returnKeyType  =UIReturnKeyDone;
    
    UIView *phoneLine = [[UIView alloc]initWithFrame:CGRectMake(15,151+iPhoneX_SPACE_TOP,ATGetDeviceWidth-30,1)];
    phoneLine.backgroundColor = [UIColor colorWithRed:204/255.0 green:204/255.0 blue:204/255.0 alpha:1.0];
    [self.view addSubview:phoneLine];
    
    _codeField = [[UITextField alloc]initWithFrame:CGRectMake(15, 151+iPhoneX_SPACE_TOP, ATGetDeviceWidth-30-16-95, 50)];
    [self.view addSubview:_codeField];
    _codeField.placeholder = @"请输入验证码";
    _codeField.font = [UIFont systemFontOfSize:14];
    _codeField.delegate = self;
    _codeField.returnKeyType  =UIReturnKeyDone;
    
    
    
    
    _codeBtn  = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-16-95,151+14+iPhoneX_SPACE_TOP,95,30)];
    [self.view addSubview:_codeBtn];
    [_codeBtn addTarget:self action:@selector(didCodeAction) forControlEvents:UIControlEventTouchUpInside];
    [_codeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    _codeBtn.titleLabel.font = [UIFont systemFontOfSize:14];
//    _codeBtn.layer.borderWidth =1;
//    _codeBtn.layer.borderColor = RGB(0xF25251).CGColor;
    //    _codeBtn.hidden = YES;
    _codeBtn.layer.cornerRadius = 15;
    _codeBtn.layer.masksToBounds = YES;
    _codeBtn.backgroundColor=RGB(0x90e1f4);

    UIView *codeLine = [[UIView alloc]initWithFrame:CGRectMake(15,201+iPhoneX_SPACE_TOP,ATGetDeviceWidth-16-95-30,1)];
    codeLine.backgroundColor = [UIColor colorWithRed:204/255.0 green:204/255.0 blue:204/255.0 alpha:1.0];
    [self.view addSubview:codeLine];
    
//    UILabel *passField = [[UILabel alloc]initWithFrame:CGRectMake(15, 151+iPhoneX_SPACE_TOP, 60, 50)];
//    [self.view addSubview:passField];
//    passField.font = [UIFont systemFontOfSize:14];
//    passField.text = @"密  码";
    
    _musicalField = [[UITextField alloc]initWithFrame:CGRectMake(15, 201+iPhoneX_SPACE_TOP, ATGetDeviceWidth-30, 50)];
    [self.view addSubview:_musicalField];
    _musicalField.placeholder = @"请输入用户名称";
    _musicalField.font = [UIFont systemFontOfSize:14];
    
    UIView *musicLine = [[UIView alloc]initWithFrame:CGRectMake(15,251+iPhoneX_SPACE_TOP,ATGetDeviceWidth-30,1)];
    musicLine.backgroundColor = [UIColor colorWithRed:204/255.0 green:204/255.0 blue:204/255.0 alpha:1.0];
    [self.view addSubview:musicLine];
    
    _passField = [[UITextField alloc]initWithFrame:CGRectMake(15, 251+iPhoneX_SPACE_TOP, ATGetDeviceWidth-30, 50)];
    [self.view addSubview:_passField];
    _passField.placeholder = @"请输入密码";
    _passField.font = [UIFont systemFontOfSize:14];
    _passField.delegate = self;
    _passField.returnKeyType  =UIReturnKeyDone;
    _passField.secureTextEntry = YES;
    
    UIView *passLine = [[UIView alloc]initWithFrame:CGRectMake(15,301+iPhoneX_SPACE_TOP,ATGetDeviceWidth-30,1)];
    passLine.backgroundColor = [UIColor colorWithRed:204/255.0 green:204/255.0 blue:204/255.0 alpha:1.0];
    [self.view addSubview:passLine];

    
    UIButton *  loginBtn  = [[UIButton alloc]initWithFrame:CGRectMake(0,ATGetDeviceHeight-50,ATGetDeviceWidth,50)];
    [self.view addSubview:loginBtn];
    [loginBtn addTarget:self action:@selector(didLoginAction) forControlEvents:UIControlEventTouchUpInside];
    [loginBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [loginBtn setTitle:@"继续" forState:UIControlStateNormal];
    loginBtn.titleLabel.font = [UIFont systemFontOfSize:18];
//    loginBtn.layer.cornerRadius =10;
//    loginBtn.layer.masksToBounds = YES;
//    loginBtn.backgroundColor = [UIColor colorWithRed:123/255.0 green:183/255.0 blue:191/255.0 alpha:1.0];
    loginBtn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];

}

#pragma mark -点击事件-
-(void)didRegis
{
    [self getRegistagment];
}
-(void)didLoginAction
{
    [self getSaveRegist];
}
-(void)didAction:(UIButton *)btn
{
    btn.selected = !btn.selected;
    if (btn.selected) {
        _selectTag = 1;
        _agreeImage.image = [UIImage imageNamed:@"dian-s"];
        
    }else
    {
        _selectTag = 0;
        _agreeImage.image = [UIImage imageNamed:@"dian-n"];
        
    }
}
-(void)didBackAction
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)didCodeAction
{
    
    [self.view endEditing:YES];
    [self getRegistagment];
    return;
    
    
    if (_phoneField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入手机号码"];
        return;
    }
    
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSDictionary *dic =@{
                             @"mobileno":_phoneField.text,
                             @"mobiletype":@"2",
                             @"smstype":@"1",
                             @"type":@"1"
                             };
    
        [XDNetworking getWithUrl:TTSmverifcode
                  refreshRequest:NO
                           cache:NO
                          params:dic
                   progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
                       
                   } successBlock:^(id response)
         {
             [MBProgressHUD hideHUDForView:self.view animated:YES];
             NSLog(@"%@",response);
             if ([response[@"ret"] isEqualToString:@"00000"]) {
                 [EngineTools timeWithButton:self.codeBtn];

             }else
             {
                 [MBProgressHUD showMessage:response[@"msg"]];

             }
             
         } failBlock:^(NSError *error) {
             NSLog(@"%@",error);
             [MBProgressHUD hideHUDForView:self.view animated:YES];
         }];
    
}
#pragma mark -注册-
-(void)getSaveRegist
{
    [self.view endEditing:YES];
//
//
//    if (_selectTag == 0) {
//        [MBProgressHUD showMessage:@"请先同意用户协议"];
//        return;
//    }
    if (_phoneField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入手机号"];
        return;
    }
    if (_passField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入密码"];
        return;
    }
    if (_codeField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入验证码"];
        return;
    }
    if (_musicalField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入用户名称"];
        return;
    }
    NSString *uuid = [[NSUserDefaults standardUserDefaults]valueForKey:@"uuid"];

    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];

    NSDictionary *dic=@{
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"appid":@"1288",
                        @"passwd":_passField.text,
                        @"phone":_phoneField.text,
                        @"nicknm":_musicalField.text,
                        @"verifycode":_codeField.text,
                        @"mac":uuid
                        };
    
    NSString *parameter =[NSString stringWithFormat:@"passwd=%@&mac=%@&nicknm=%@&verifycode=%@&phone=%@&appid=1288&motime=%@&sign=%@",_passField.text,uuid,_musicalField.text,_codeField.text,_phoneField.text,[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    

    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/sso/reg";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
                 if ([response[@"code"] isEqualToString:@"10000"]) {
                     [self getLogin];

                 }

        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];

}

-(void)getLogin
{
    [self.view endEditing:YES];
    NSString *uuid = [[NSUserDefaults standardUserDefaults]valueForKey:@"uuid"];

    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    
    NSDictionary *dic=@{
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"passwd":_passField.text,
                        @"phone":_phoneField.text,
                        @"mac":uuid
                        };
    
    NSString *parameter =[NSString stringWithFormat:@"passwd=%@&mac=%@&phone=%@&appid=1288&motime=%@&sign=%@",_passField.text,uuid,_phoneField.text,[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/sso/login";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"])
        {
            
            [token whriteValue:response[@"data"][@"token"]];
            [[NSUserDefaults standardUserDefaults]setValue:response[@"data"][@"nickname"] forKey:@"name"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            if ([response[@"data"][@"dvccnt"] integerValue ] ==0) {
                GSJAddEquipmentViewController *vc = [[GSJAddEquipmentViewController alloc]init];
                vc.login = @"2";
                [self presentViewController:vc animated:YES completion:nil];
            }else
            {
                GSJDeviceListViewController *vc = [[GSJDeviceListViewController alloc]init];
                [self presentViewController:vc animated:YES completion:nil];
            }
        }
        
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
}

#pragma mark -获取验证码-
-(void)getRegistagment
{
    [self.view endEditing:YES];
    if (_phoneField.text.length == 0) {
        [MBProgressHUD showMessage:@"请输入手机号"];
        return;
    }
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//    NSString *md5 = @"interlnx&aY4N!bAAds";
//        NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];

    NSDictionary *dic=@{
                        @"smstype":@"REG",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"appid":@"1288",
                        @"phone":_phoneField.text,
                        };
    
    NSString *parameter =[NSString stringWithFormat:@"smstype=REG&phone=%@&appid=1288&motime=%@&sign=%@",_phoneField.text,[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];


    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/sso/sendcode";

    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([response[@"code"] isEqualToString:@"10000"]) {
            [EngineTools timeWithButton:self.codeBtn];

        }
        NSLog(@"%@",response);
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];

    }];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    return YES;
}
@end
