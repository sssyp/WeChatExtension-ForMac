//
//  AppDelegate.h
//  AirMedic
//
//  Created by kaka on 2019/8/8.
//  Copyright © 2019 gsj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic,assign)BOOL allowRotation;


@end

