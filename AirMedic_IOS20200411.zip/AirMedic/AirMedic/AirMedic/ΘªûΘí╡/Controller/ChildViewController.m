//
//  ChildViewController.m
//  FSScrollContentViewDemo
//
//  Created by 冯顺 on 2017/5/3.
//  Copyright © 2017年 fengshun. All rights reserved.
//

#import "ChildViewController.h"
#import "GSJMyViewController.h"
#import "WTProgressView.h"
#import "GSJDeviceListViewController.h"

static NSDateFormatter *cachedDateFormatter = nil;

@interface ChildViewController ()<TimePickerViewDelegate>
@property (nonatomic,strong) UIView *headView;

#pragma mark-定时-
@property (nonatomic,strong) UIView *middleView;
@property (nonatomic,strong) UIView *downView;
@property (nonatomic,strong) UIButton *starTime;
@property (nonatomic,strong) UIButton *endTime;
@property (nonatomic,assign) NSInteger btnTag;//1表示开始 2表示结束
@property (nonatomic,copy) NSString *stringFirst;
@property (nonatomic,copy) NSString *stringFirstOpen;//表示开关的连续运行和间歇运行
@property (nonatomic,copy) NSString *stringTwo;
@property (nonatomic,strong) UIButton *leftBtn;
@property (nonatomic,strong) UIButton *leftDBtn;
@property (nonatomic,strong) UIButton *rightBtn;
@property (nonatomic,strong) UIButton *rightDBtn;

@property (nonatomic,strong) UIView *titleView;//显示最近一条设定
@property (nonatomic,strong) UILabel *timeLabel;



#pragma mark -天气-
@property (nonatomic,strong) UIView *weatherView;//天气控件
@property (nonatomic,strong) UIView *gifView;//机器动态图
@property (nonatomic,strong) UIImageView *itemView;//机器图片
//@property (nonatomic,strong) FLAnimatedImageView *loadingimage;//动态图片
@property (nonatomic,strong) YYAnimatedImageView *loadingimage;//动态图片

@property (nonatomic,copy) NSString *gifa;
@property (nonatomic,copy) NSString *gifb;

#pragma mark -开关-
@property (nonatomic,strong) UIView *openView;//机器动态图
@property (nonatomic,assign) NSInteger openOrClose;//0表示关闭 1表示打开
@property (nonatomic,strong) UILabel *oneLabel;
@property (nonatomic,strong) UILabel *twoLabel;
@property (nonatomic,strong) UILabel *threeLabel;
@property (nonatomic,strong) UILabel *fourLabel;
@property (nonatomic,strong) UILabel *fiveLabel;


#pragma mark-风力-
@property (nonatomic,strong) UIView *speedView;//风力控件
//@property (nonatomic,strong) UIView *progressView;//进度控件
@property (nonatomic,strong) WTProgressView *progressView;//进度控件
@property (nonatomic,assign) NSInteger  currentFL;//风力当前进度



#pragma mark-氛围灯-
@property (nonatomic,strong) UIView *speed1View;//氛围灯控件
//@property (nonatomic,strong) UIView *progress1View;//进度控件
@property (nonatomic,strong) WTProgressView *progress1View;//进度控件
@property (nonatomic,assign) NSInteger  currentF;//氛围灯当前进度

#pragma mark -液量-

@property (nonatomic,strong) UILabel *surplus;//液量


//@property (nonatomic,strong) UIScrollView *
@end

@implementation ChildViewController
//-(NSDateFormatter *)cachedDateFormatter {
//
//    if (!cachedDateFormatter) {
//
//        cachedDateFormatter = [[NSDateFormatter alloc] init];
//
//
//        [cachedDateFormatter setDateFormat: @"HH:mm"];
//
//    }
//
//    return cachedDateFormatter;
//
//}
-(YYAnimatedImageView *)loadingimage
{
    if (!_loadingimage) {
        _loadingimage = [[YYAnimatedImageView alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-410)/2, 0, 400, 280)];
        [self.gifView addSubview:_loadingimage];
    }
    return _loadingimage;
}
//-(FLAnimatedImageView *)loadingimage
//{
//    if (!_loadingimage) {
//        _loadingimage = [[FLAnimatedImageView alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-410)/2, 0, 400, 280)];
//        [self.gifView addSubview:_loadingimage];
//    }
//    return _loadingimage;
//}
-(UIView *)headView
{
    if (!_headView) {
        _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, 44+22+iPhoneX_SPACE_TOP)];
        [self.view addSubview:_headView];
        _headView.backgroundColor = [UIColor whiteColor];
    }
    return _headView;
}
-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self.view removeFromSuperview];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSLog(@"titleStr---%@   ======%@======%@",self.titleStr,self.dic,self.fenString);
    if ([self.titleStr isEqualToString:@"开/关"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"didClose1" object:nil];
    }
    if ([self.titleStr isEqualToString:@"风力"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"didClose2" object:nil];
    }
    if ([self.titleStr isEqualToString:@"氛围灯"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"didClose3" object:nil];
    }

//    UIViewController *parentVC = self.presentingViewController;
//    NSLog(@"%@",parentVC.childViewControllers);
//        UIViewController *bottomVC;
//        while (parentVC) {
//            bottomVC = parentVC;
//            parentVC = parentVC.presentingViewController;
//        }
    //    [bottomVC dismissViewControllerAnimated:NO completion:^{
    //        //dismiss后再切换根视图
    //        [UIApplication sharedApplication].delegate.window.rootViewController = [GSJDeviceListViewController new];
    //    }];
//    if ([self.titleStr isEqualToString:@"定时"]) {
//        [self getTiming:@"0"];
//    }
    
    if ([self.titleStr isEqualToString:@"液量"]||[self.titleStr isEqualToString:@"定时"]) {
        return;
    }

//    NSString *filepath = [[NSBundle bundleWithPath:[[NSBundle mainBundle] bundlePath]] pathForResource:self.dic[@"gifb"] ofType:nil];
//    self.loadingimage.animatedImage = [FLAnimatedImage animatedImageWithGIFData:[NSData dataWithContentsOfFile:filepath]];
    
    self.loadingimage.image = [YYImage imageNamed:self.dic[@"gifb"]];
    
    if (![self.fenString isEqualToString:@""]&&![self.fenString isKindOfClass:[NSNull class]]&&self.fenString != nil) {
        _itemView.image = [UIImage imageNamed:self.fenString];
        if ([self.fenString isEqualToString:@"关机"]) {
            self.loadingimage.hidden = YES;
        }else
        {
            self.loadingimage.hidden = NO;
        }
    }
    
    if ([self.titleStr isEqualToString:@"开/关"]) {
        [self getTiming:@"1"];
    }

    
}
- (void)dealloc
{
    //移除当前对象监听的事件
    
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    
}
#pragma mark -设备收到的消息-
- (void)receiveNotification:(NSNotification *)noti
{
    NSLog(@" 设备操作，app收到的消息=== %@", noti.userInfo);
    NSDictionary *dic = noti.userInfo;
    if ([dic[@"0"] integerValue] ==0 ) {
        NSLog(@"关闭设备");
    }else{
        NSLog(@"打开设备");
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"didOpen" object:dic[@"0"]];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"notiDic" object:dic];
    _openOrClose = [dic[@"0"] integerValue];

    
    if ([dic[@"1"] integerValue] ==0 ) {
        NSLog(@"连续运转");
    }else{
        NSLog(@"智能模式");
    }
    
    if ([dic[@"2"] integerValue] ==0 ) {
        NSLog(@"键盘解锁");
    }else{
        NSLog(@"键盘上锁");
    }
//    if ([self.titleStr isEqualToString:@"风力"]) {
        if ([dic[@"3"] integerValue] ==1 ) {
        NSLog(@"最弱风力");
        [self changeFengLi:nil num:1];
        
    }else if([dic[@"3"] integerValue]==2){
        NSLog(@"中等风力");
        [self changeFengLi:nil num:2];
        
    }else
    {
        NSLog(@"最强风力");
        [self changeFengLi:nil num:3];
    }
    _currentFL =[dic[@"3"] integerValue];
//    }
   
    
//    if ([self.titleStr isEqualToString:@"氛围灯"]) {

    if ([dic[@"4"] integerValue] ==0 ) {
        NSLog(@"关闭氛围灯");
        [self changeFenWeiDeng:nil num:0];

    }else if([dic[@"4"] integerValue]==1){
        NSLog(@"最弱氛围灯");
        [self changeFenWeiDeng:nil num:1];

    }else if([dic[@"4"] integerValue]==2){
        NSLog(@"中等氛围灯");
        [self changeFenWeiDeng:nil num:2];

    }else
    {
    NSLog(@"最强氛围灯");
        [self changeFenWeiDeng:nil num:3];
    }
    _currentF =[dic[@"4"] integerValue];
//    }
    
    
    if ([dic[@"5"] integerValue] ==0 ) {
        NSLog(@"无定时");
    }else if([dic[@"5"] integerValue]==1){
        NSLog(@"3小时");
    }else if([dic[@"5"] integerValue]==2){
        NSLog(@"6小时");
    }else
    {
        NSLog(@"12小时");
    }
    
    if ([dic[@"6"] integerValue]) {
        NSLog(@"水位====%@",dic[@"6"]);
    }
    
    
    
//    NSString *four = @"间歇运行";
//    if ([dic[@"1"] integerValue] ==0 ) {
//        NSLog(@"连续运转");
//        four=@"连续运行";
//    }
    NSString *water = @"0%";
    NSInteger num = [dic[@"6"] integerValue];
    if (num>=40&&num<97) {
        water = @"100%";
    }
    if (num>=97&&num<119) {
        water = @"80%";
    }
    if (num>=119&&num<141) {
        water = @"60%";
    }
    if (num>=141&&num<164) {
        water = @"40%";
    }
    if (num>=164&&num<=191) {
        water = @"20%";
    }
    NSString *five = [NSString stringWithFormat:@"液体剩余量%@",water];
    _surplus.text = water;
    _fiveLabel.text = five;

    NSString *one = @"低风挡";
    NSInteger num3 = [dic[@"3"] integerValue];
    if (num3 ==2) {
        one = @"中风挡";
    }else if(num3 ==3)
    {

        one = @"高风挡";
    }
    _oneLabel.text = one;
    
    NSString *three = @"未开灯";
    if ([dic[@"4"] integerValue] ==0 ) {
        NSLog(@"关闭氛围灯");
        
    }else if([dic[@"4"] integerValue]==1){
        NSLog(@"最弱氛围灯");
        three = @"低亮度";
    }else if([dic[@"4"] integerValue]==2){
        NSLog(@"中等氛围灯");
        three = @"中亮度";
    }else
    {
        NSLog(@"最强氛围灯");
        three = @"高亮度";
        
    }
    _threeLabel.text = three;
    if ([self.titleStr isEqualToString:@"开/关"]) {
        if ([dic[@"1"] integerValue] ==0) {
            self.leftBtn.backgroundColor  =RGB(0x90e1f4);
            self.rightBtn.backgroundColor  =rgba(217, 215, 217, 1);
            self.stringFirstOpen = @"连续运行";
        }else
        {
            self.rightBtn.backgroundColor  =RGB(0x90e1f4);
            self.leftBtn.backgroundColor  =rgba(217, 215, 217, 1);
            self.stringFirstOpen = @"间歇运行";
        }
    }
   
    self.fourLabel.text = self.stringFirstOpen;
    
//    NSString *two =@"无定时";
//    if ([dic[@"5"] integerValue] ==0 ) {
//        NSLog(@"无定时");
//    }else if([dic[@"5"] integerValue]==1){
//        two = @"3小时";
//        NSLog(@"3小时");
//    }else if([dic[@"5"] integerValue]==2){
//        NSLog(@"6小时");
//        two = @"6小时";
//
//    }else
//    {
//        two = @"12小时";
//        NSLog(@"12小时");
//    }
//
//    for (UIView *view in self.openView.subviews) {
//        [view removeFromSuperview];
//    }
//    NSArray *array = @[one,two,three,four,five];
//    NSArray *arrayImage = @[@"测试风车图",@"测试闹钟",@"测试灯泡图",@"模式",@"水滴"];
//    for (int i = 0; i<5; i++) {
//        UIImageView *down = [[UIImageView alloc]initWithFrame:CGRectMake(30, 50*i+10, 33, 33)];
//        [self.openView addSubview:down];
//        //            down.backgroundColor = [UIColor blueColor];
//        down.image = [UIImage imageNamed:arrayImage[i]];
//
//        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(80, 50*i, 200, 50)];
//        [self.openView addSubview:label];
//        label.text = array[i];
//    }

    
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    self.view.backgroundColor = [ChildViewController randomColor];
//    [[NSNotificationCenter defaultCenter]postNotificationName:@"receiveMessage" object:jsonDic];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(receiveNotification:) name:@"receiveMessage" object:nil];
    NSLog(@"设备状态==========%@",self.deviceDic);
    self.view.backgroundColor =[UIColor whiteColor];
    
    UILabel *headLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,15+22+iPhoneX_SPACE_TOP,ATGetDeviceWidth,19)];
    [self.headView addSubview:headLabel];
    NSMutableAttributedString *headString = [[NSMutableAttributedString alloc] initWithString:self.controlDic[@"dvcnm"] attributes:@{NSFontAttributeName: [UIFont fontWithName:@"PingFang-SC-Medium" size: 16],NSForegroundColorAttributeName: [UIColor blackColor]}];
    headLabel.attributedText = headString;
    headLabel.textAlignment = NSTextAlignmentCenter;
    
    
    
    UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(6,34+iPhoneX_SPACE_TOP,23,23)];
    [self.view addSubview:leftBtn];
    [leftBtn setImage:[UIImage imageNamed:@"icon-back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(didAction) forControlEvents:UIControlEventTouchUpInside];
    
    
    _weatherView = [[UIView alloc]initWithFrame:CGRectMake(0, 80, ATGetDeviceWidth, 60)];
    [self.view addSubview:_weatherView];
    
    if (![self.weatherDic isKindOfClass:[NSNull class]] && ![self.weatherDic isEqual:[NSNull null]]&&(self.weatherDic.allKeys.count!=0)) {

    
    UIImageView *wImage = [[UIImageView alloc]initWithFrame:CGRectMake((ATGetDeviceWidth/3-40)/2, 0, 40, 40)];
//    wImage.image= [UIImage imageNamed:@""];
//    [wImage sd_setImageWithURL:[NSURL URLWithString:self.weatherDic[@"weathicon"]]];
//    [wImage sizeToFit];
//    wImage.backgroundColor = [UIColor redColor];
    [self.weatherView addSubview:wImage];
    if ([self.weatherDic[@"iconum"] isKindOfClass:[NSNull class]] || [self.weatherDic[@"iconum"] isEqual:[NSNull null]] || self.weatherDic[@"iconum"] == nil) {
    }else{
    switch ([self.weatherDic[@"iconum"] integerValue]) {
        case 1:
            wImage.image = [UIImage imageNamed:@"晴天"];
            break;
        case 3:
            wImage.image = [UIImage imageNamed:@"阴天"];
            break;
        case 5:
            wImage.image = [UIImage imageNamed:@"多云"];
            break;
        case 8:
            wImage.image = [UIImage imageNamed:@"小雨"];
            break;
        case 9:
            wImage.image = [UIImage imageNamed:@"中雨"];
            break;
        case 10:
            wImage.image = [UIImage imageNamed:@"大雨"];
            break;
        case 17:
            wImage.image = [UIImage imageNamed:@"小雪"];
            break;
        case 18:
            wImage.image = [UIImage imageNamed:@"中雪"];
            break;
        case 19:
            wImage.image = [UIImage imageNamed:@"大雪"];
            break;
        case 30:
            wImage.image = [UIImage imageNamed:@"雷阵雨"];
            break;
        default:
            break;
    }
    }
    
    UIView *lineO = [[UIView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/3-1, 0, 1, 60)];
    [self.weatherView addSubview:lineO];
    lineO.backgroundColor =rgba(153, 153, 153, 1);
    
    UIView *lineS = [[UIView alloc]initWithFrame:CGRectMake(ATGetDeviceWidth*2/3-1, 0, 1, 60)];
    [self.weatherView addSubview:lineS];
    lineS.backgroundColor =rgba(153, 153, 153, 1);
    
    
    UILabel *address = [[UILabel alloc]initWithFrame:CGRectMake(0, 40, ATGetDeviceWidth/3, 20)];
    [self.weatherView addSubview:address];
    address.textAlignment = NSTextAlignmentCenter;
    address.font = [UIFont systemFontOfSize:13];
        if ([self.weatherDic[@"areanm"] isKindOfClass:[NSNull class]] || [self.weatherDic[@"areanm"] isEqual:[NSNull null]] || self.weatherDic[@"areanm"] == nil) {
        }else{
            address.text= self.weatherDic[@"areanm"];
        }
    
    UILabel *degrees = [[UILabel alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/3, 0, ATGetDeviceWidth/3, 30)];
    [self.weatherView addSubview:degrees];
    degrees.textAlignment = NSTextAlignmentCenter;
    degrees.font = [UIFont systemFontOfSize:30];
        if ([self.weatherDic[@"temp"] isKindOfClass:[NSNull class]] || [self.weatherDic[@"temp"] isEqual:[NSNull null]] || self.weatherDic[@"temp"] == nil) {
        }else{
            degrees.text= [NSString stringWithFormat:@"%@°",self.weatherDic[@"temp"]];
        }
    
    UILabel *weaLabel = [[UILabel alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/3, 30, ATGetDeviceWidth/3, 30)];
//    @"多云转晴\n20°/35°";
    weaLabel.numberOfLines = 0;
    [self.weatherView addSubview:weaLabel];
    weaLabel.textAlignment = NSTextAlignmentCenter;
    weaLabel.font = [UIFont systemFontOfSize:12];
        if ([self.weatherDic[@"weath"] isKindOfClass:[NSNull class]]||
            [self.weatherDic[@"temp2"] isKindOfClass:[NSNull class]]||
            [self.weatherDic[@"weath"] isEqual:[NSNull null]] || self.weatherDic[@"weath"] == nil||
            [self.weatherDic[@"temp2"] isEqual:[NSNull null]] || self.weatherDic[@"temp2"] == nil) {
        }else{
            weaLabel.text=[NSString stringWithFormat:@"%@\n%@",self.weatherDic[@"weath"],self.weatherDic[@"temp2"]];
        }
    
        if ([self.weatherDic[@"humidity"] isKindOfClass:[NSNull class]]||
            [self.weatherDic[@"wind"] isKindOfClass:[NSNull class]]||
            [self.weatherDic[@"humidity"] isEqual:[NSNull null]] || self.weatherDic[@"humidity"] == nil||
            [self.weatherDic[@"wind"] isEqual:[NSNull null]] || self.weatherDic[@"wind"] == nil) {
        }else{
            NSString *str = [NSString stringWithFormat:@"湿度  %@%%\n%@",self.weatherDic[@"humidity"],self.weatherDic[@"wind"]];

    UILabel *other = [[UILabel alloc]initWithFrame:CGRectMake(ATGetDeviceWidth*2/3, 10, ATGetDeviceWidth/3, 40)];
        
//    @"湿度 60%\n东风 二级";
    other.numberOfLines = 0;
    [self.weatherView addSubview:other];
    other.textAlignment = NSTextAlignmentCenter;
    other.font = [UIFont systemFontOfSize:12];
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:str];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 10; // 调整行间距
    NSRange range = NSMakeRange(0, [str length]);
    paragraphStyle.alignment = NSTextAlignmentCenter; //设置两端对齐显示
    
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:range];
    other.attributedText = attributedString;
        }
        
    }else
    {
        UILabel *label =[[UILabel alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, 60)];
        [self.weatherView addSubview:label];
        label.text = @"请在设置中打开定位";
        label.textAlignment  =NSTextAlignmentCenter;
        
        
        
    }
    
    
    _gifView = [[UIView alloc]initWithFrame:CGRectMake(0, 140, ATGetDeviceWidth, 450)];
    [self.view addSubview:_gifView];
    _gifView.backgroundColor = [UIColor whiteColor];
    
    _itemView= [[UIImageView alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-260)/2,240, 260, 200)];
    [self.gifView addSubview:_itemView];
    
    

    
    self.loadingimage.image = [YYImage imageNamed:self.dic[@"gifb"]];

//    NSString *filepath = [[NSBundle bundleWithPath:[[NSBundle mainBundle] bundlePath]] pathForResource:self.dic[@"gifb"] ofType:nil];
//    self.loadingimage.animatedImage = [FLAnimatedImage animatedImageWithGIFData:[NSData dataWithContentsOfFile:filepath]];

    

    
    if ([self.titleStr isEqualToString:@"液量"]) {
        
        [self.weatherView removeFromSuperview];
        [self.gifView removeFromSuperview];
        
        UIImageView *headView = [[UIImageView alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-350)/2, 80, 350, 280)];
        [self.view addSubview:headView];
        headView.image = [UIImage imageNamed:@"液位机器透视图8.218"];
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-70)/2, 380, 70, 20)];
        label.text = @"液体剩余量";
        [self.view addSubview:label];
        label.font = [UIFont systemFontOfSize:12];
        label.layer.masksToBounds = YES;
        label.layer.cornerRadius = 10;
        label.textColor = [UIColor whiteColor];
        label.backgroundColor = RGB(0x90e1f4);;
        label.textAlignment = NSTextAlignmentCenter;

        
        UIImageView *down = [[UIImageView alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-100)/2, 430, 100, 100)];
        [self.view addSubview:down];
        down.backgroundColor = RGB(0x90e1f4);;
        down.layer.masksToBounds = YES;
        down.layer.cornerRadius = 50;
        down.image = [UIImage imageNamed:@"液位圆圈"];
//        down.layer.borderWidth = 1;
//        down.layer.borderColor = rgba(149, 173, 196, 1).CGColor;
        
//        UIImageView *downUp = [[UIImageView alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-100)/2, 330, 100, 50)];
//        [self.view addSubview:downUp];
//        downUp.image = [UIImage imageNamed:@"液位 太极图图层 13"];
//        downUp.layer.masksToBounds = YES;
//        downUp.layer.cornerRadius = 50;
        
        
        _surplus = [[UILabel alloc]initWithFrame:CGRectMake(0, 430+60, ATGetDeviceWidth, 20)];
        [self.view addSubview:_surplus];
        _surplus.font = [UIFont systemFontOfSize:14];
        _surplus.textAlignment = NSTextAlignmentCenter;
        _surplus.textColor = [UIColor whiteColor];

        NSString *water = @"0%";
        
        if ([self.deviceDic[@"6"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"6"] isEqual:[NSNull null]] || self.deviceDic[@"6"] == nil) {
        }else{
        NSInteger num = [self.deviceDic[@"6"] integerValue];
        if (num>=40&&num<97) {
            water = @"100%";
        }
        if (num>=97&&num<119) {
            water = @"80%";
        }
        if (num>=119&&num<141) {
            water = @"60%";
        }
        if (num>=141&&num<164) {
            water = @"40%";
        }
        if (num>=164&&num<=191) {
            water = @"20%";
        }
        _surplus.text = water;
        }

    }
    if ([self.titleStr isEqualToString:@"风力"]) {
        
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didClose) name:@"didClose1" object:nil];
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didClose) name:@"didClose2" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didClose) name:@"didClose3" object:nil];
        
        _speedView = [[UIView alloc]initWithFrame:CGRectMake(0, 150, ATGetDeviceWidth, 40)];
        [self.view addSubview:_speedView];

        UIImageView *down = [[UIImageView alloc]initWithFrame:CGRectMake(20, 0, 40, 40)];
        [self.speedView addSubview:down];
//        down.backgroundColor = [UIColor blueColor];
        down.image = [UIImage imageNamed:@"风力调节界面 风车小图标 形状 13 拷贝 3"];
        down.userInteractionEnabled = YES;
        UITapGestureRecognizer *ges = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didPAction:)];
        [down addGestureRecognizer:ges];
        
//        _progressView  = [[UIView alloc]initWithFrame:CGRectMake(50, 10, ATGetDeviceWidth-70, 10)];
//        [self.speedView addSubview:_progressView];
//        _progressView.backgroundColor =rgba(217, 215, 217, 1);
//        _progressView.layer.cornerRadius = 5;
//        _progressView.layer.masksToBounds = YES;

//        _progressView  = [[MQGradientProgressView alloc]initWithFrame:CGRectMake(50, 10, ATGetDeviceWidth-70, 10)];
//        [self.speedView addSubview:_progressView];
//        _progressView.backgroundColor =rgba(217, 215, 217, 1);
//        _progressView.colorArr = @[RGB(0x98DCD2),RGB(0x00A0F0)];
//        _progressView.colorArr = @[[UIColor redColor],[UIColor blackColor]];
//        _progressView.progress = 1;
//        _progressView.bgProgressColor=rgba(217, 215, 217, 1);
//        _progressView.layer.cornerRadius = 5;
//        _progressView.layer.masksToBounds = YES;
        
        _progressView = [[WTProgressView alloc] initWithFrame:CGRectMake(70, 15, ATGetDeviceWidth-90, 10)];
        [self.speedView addSubview:_progressView];
        _progressView.gradientColors = @[RGB(0x98DCD2),RGB(0x00A0F0)];
//        _progressView.progress = 0.33;
        _progressView.layer.cornerRadius = 5;
        _progressView.layer.masksToBounds = YES;
        _progressView.backgroundColor = rgba(217, 215, 217, 1);

//        UISlider *slider = [[UISlider alloc]initWithFrame:CGRectMake(50, 10, ATGetDeviceWidth-70, 10)];
//        [self.speedView addSubview:slider];
//        slider.minimumTrackTintColor = RGB(0x98DCD2);
//        slider.maximumTrackTintColor = RGB(0x00A0F0);
//        slider.backgroundColor =rgba(217, 215, 217, 1);
        
//        UIButton *leftBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, (ATGetDeviceWidth-70)/3, 30)];
//        [_progressView addSubview:leftBtn];
////        [leftBtn addTarget:self action:@selector(didPAction:) forControlEvents:UIControlEventTouchUpInside];
////        leftBtn.backgroundColor  =rgba(217, 215, 217, 1);
//        leftBtn.tag = 100;
//
//        UIButton *middleBtn = [[UIButton alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-70)/3, 0, (ATGetDeviceWidth-70)/3, 30)];
//        [_progressView addSubview:middleBtn];
////        [middleBtn addTarget:self action:@selector(didPAction:) forControlEvents:UIControlEventTouchUpInside];
////        middleBtn.backgroundColor  =rgba(217, 215, 217, 1);
//        middleBtn.tag = 101;
//
//        UIButton *rightBtn = [[UIButton alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-70)/3*2,0, (ATGetDeviceWidth-70)/3, 30)];
//        [_progressView addSubview:rightBtn];
////        [rightBtn addTarget:self action:@selector(didPAction:) forControlEvents:UIControlEventTouchUpInside];
////        rightBtn.backgroundColor  =rgba(217, 215, 217, 1);
//        rightBtn.tag = 102;
        
        if ([self.deviceDic[@"3"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"3"] isEqual:[NSNull null]] || self.deviceDic[@"3"] == nil) {
        }else{
        NSInteger num = [self.deviceDic[@"3"] integerValue];
        _currentFL =[self.deviceDic[@"3"] integerValue];

        [self changeFengLi:nil num:num];
        }
        
    }
    if ([self.titleStr isEqualToString:@"开/关"]) {
//        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(didChange:) name:@"didChange" object:nil];

        
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didClose) name:@"didClose1" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didClose) name:@"didClose2" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didClose) name:@"didClose3" object:nil];
        
        
        
       
        
        
        _openView =[[UIView alloc]initWithFrame:CGRectMake(0, 200, ATGetDeviceWidth, 300)];
        [self.view addSubview:_openView];
        _openView.hidden = YES;
        
        NSString *four = @"间歇运行";
        if ([self.deviceDic[@"1"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"1"] isEqual:[NSNull null]] || self.deviceDic[@"1"] == nil) {
        }else{
        if ([self.deviceDic[@"1"] integerValue] ==0 ) {
            four = @"连续运行";
            NSLog(@"连续运转");
        }
            
        }
        NSString *water = @"0%";
        if ([self.deviceDic[@"6"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"6"] isEqual:[NSNull null]] || self.deviceDic[@"6"] == nil) {
        }else{
            
        NSInteger num = [self.deviceDic[@"6"] integerValue];
      
        if (num>=40&&num<97) {
            water = @"100%";
        }
        if (num>=97&&num<119) {
            water = @"80%";
        }
        if (num>=119&&num<141) {
            water = @"60%";
        }
        if (num>=141&&num<164) {
            water = @"40%";
        }
        if (num>=164&&num<=191) {
            water = @"20%";
        }
        }
        NSString *five = [NSString stringWithFormat:@"液体剩余量%@",water];
        
//        NSInteger num2= [self.deviceDic[@"0"] integerValue];
//        NSLog(@"%ld======0等于关  1等于开",num2);
        if ([self.deviceDic[@"0"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"0"] isEqual:[NSNull null]] || self.deviceDic[@"0"] == nil) {
        }else{
        [[NSNotificationCenter defaultCenter] postNotificationName:@"didOpen" object:self.deviceDic[@"0"]];

        _openOrClose = [self.deviceDic[@"0"] integerValue];
        
        if (_openOrClose==0) {
            self.loadingimage.hidden = YES;
        }else
        {
            self.loadingimage.hidden = NO;
        }
        }
            
        NSString *gifb = @"";
        NSString *gifa = @"";
        NSString *one = @"";
        if ([self.deviceDic[@"3"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"3"] isEqual:[NSNull null]] || self.deviceDic[@"3"] == nil) {
        }
        else
        {
        NSInteger num3 = [self.deviceDic[@"3"] integerValue];
        if (num3 ==1) {
            gifb = @"0.7x_b.gif";
            gifa = @"0.7x_a.gif";
            one = @"低风挡";
        }
        if (num3 ==2) {
            gifb = @"1.3x_b.gif";
            gifa = @"1.3x_a.gif";
            one = @"中风挡";
            
        }else if(num3 ==3)
        {
            gifb = @"2x_b.gif";
            gifa = @"2x_a.gif";
            one = @"高风挡";
        }
        }
        NSDictionary *dic = @{
                              @"gifa":gifa,
                              @"gifb":gifb
                              };
//        NSString *filepath = [[NSBundle bundleWithPath:[[NSBundle mainBundle] bundlePath]] pathForResource:gifb ofType:nil];
//        self.loadingimage.animatedImage = [FLAnimatedImage animatedImageWithGIFData:[NSData dataWithContentsOfFile:filepath]];
        
        self.loadingimage.image = [YYImage imageNamed:gifb];

        
        self.dic = dic;
        [[NSNotificationCenter defaultCenter] postNotificationName:@"didChange" object:nil userInfo:dic];
        if ([self.deviceDic[@"4"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"4"] isEqual:[NSNull null]] || self.deviceDic[@"4"] == nil) {
        }
        else
        {
        NSInteger num1 = [self.deviceDic[@"4"] integerValue];
        [self changeFenWeiDeng:nil num:num1];
        }
        NSString *three = @"未开灯";
        if ([self.deviceDic[@"4"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"4"] isEqual:[NSNull null]] || self.deviceDic[@"4"] == nil) {
        }
        else
        {
        if ([self.deviceDic[@"4"] integerValue] ==0 ) {
            NSLog(@"关闭氛围灯");
            
        }else if([self.deviceDic[@"4"] integerValue]==1){
            NSLog(@"最弱氛围灯");
            three = @"低亮度";
        }else if([self.deviceDic[@"4"] integerValue]==2){
            NSLog(@"中等氛围灯");
            three = @"中亮度";

        }else
        {
            NSLog(@"最强氛围灯");
            three = @"高亮度";

        }
        }
        NSString *two =@"无定时";
        if ([self.deviceDic[@"5"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"5"] isEqual:[NSNull null]] || self.deviceDic[@"5"] == nil) {
        }
        else
        {
        if ([self.deviceDic[@"5"] integerValue] ==0 ) {
            NSLog(@"无定时");
        }else if([self.deviceDic[@"5"] integerValue]==1){
            two = @"3小时";
            NSLog(@"3小时");
        }else if([self.deviceDic[@"5"] integerValue]==2){
            NSLog(@"6小时");
            two = @"6小时";

        }else
        {
            two = @"12小时";

            NSLog(@"12小时");
        }
        }
        
        NSArray *array = @[one,two,three,four,five];
        NSArray *arrayImage = @[@"测试风车图",@"测试闹钟",@"测试灯泡图",@"模式",@"水滴"];
        for (int i = 0; i<5; i++) {
            UIImageView *down = [[UIImageView alloc]initWithFrame:CGRectMake(30, 70*i+15, 40, 40)];
            [self.openView addSubview:down];
            //            down.backgroundColor = [UIColor blueColor];
            down.image = [UIImage imageNamed:arrayImage[i]];
            
            UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(100, 70*i, 200, 70)];
            [self.openView addSubview:label];
            label.text = array[i];
            label.font = [UIFont systemFontOfSize:15];
            
            switch (i) {
                case 0:
                    _oneLabel = label;
                    break;
                case 1:
                    _twoLabel = label;
                    break;
                case 2:
                    _threeLabel = label;
                    break;
                case 3:
                    _fourLabel = label;
                    break;
                    
                default:
                    _fiveLabel = label;
                    break;
            }
        }
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0,200, ATGetDeviceWidth, 400)];
        [self.view addSubview:btn];
        [btn addTarget:self action:@selector(didChangePic:) forControlEvents:UIControlEventTouchUpInside];
        
        UIView *middleView = [[UIView alloc]initWithFrame:CGRectMake(50, 150, ATGetDeviceWidth-100, 30)];
        [self.view addSubview:middleView];
        _middleView.backgroundColor =rgba(217, 215, 217, 1);
        middleView.layer.cornerRadius = 15;
        middleView.layer.masksToBounds = YES;
        
        _leftBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, (ATGetDeviceWidth-100)/2, 30)];
        [middleView addSubview:_leftBtn];
        [_leftBtn setTitle:@"连续运行" forState:UIControlStateNormal];
        _leftBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [_leftBtn addTarget:self action:@selector(didActionOpen:) forControlEvents:UIControlEventTouchUpInside];
        _leftBtn.backgroundColor  =RGB(0x90e1f4);
        [_leftBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        _rightBtn = [[UIButton alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-100)/2, 0, (ATGetDeviceWidth-100)/2, 30)];
        [middleView addSubview:_rightBtn];
        [_rightBtn setTitle:@"间歇运行" forState:UIControlStateNormal];
        _rightBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [_rightBtn addTarget:self action:@selector(didActionOpen:) forControlEvents:UIControlEventTouchUpInside];
        _rightBtn.backgroundColor  =rgba(217, 215, 217, 1);
        [_rightBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        
        if ([self.deviceDic[@"1"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"1"] isEqual:[NSNull null]] || self.deviceDic[@"1"] == nil) {
        }
        else
        {
        if ([self.deviceDic[@"1"] integerValue] ==0) {
            self.leftBtn.backgroundColor  =RGB(0x90e1f4);
            self.rightBtn.backgroundColor  =rgba(217, 215, 217, 1);
            self.stringFirstOpen = @"连续运行";
        }else
        {
            self.rightBtn.backgroundColor  =RGB(0x90e1f4);
            self.leftBtn.backgroundColor  =rgba(217, 215, 217, 1);
            self.stringFirstOpen = @"间歇运行";
        }
        self.fourLabel.text = self.stringFirstOpen;

        
        [self getTiming:@"1"];
        }
        
    }
    
    if ([self.titleStr isEqualToString:@"氛围灯"])
    {
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didClose) name:@"didClose1" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didClose) name:@"didClose2" object:nil];
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didClose) name:@"didClose3" object:nil];
//        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(didChange:) name:@"didChange" object:nil];

        _speed1View = [[UIView alloc]initWithFrame:CGRectMake(0, 150, ATGetDeviceWidth, 40)];
        [self.view addSubview:_speed1View];
        
        UIImageView *down = [[UIImageView alloc]initWithFrame:CGRectMake(20, 0, 40, 40)];
        [self.speed1View addSubview:down];
//        down.backgroundColor = [UIColor blueColor];
        down.image = [UIImage imageNamed:@"氛围灯调节假面 灯泡小图标 矢量智能对象"];
        down.userInteractionEnabled = YES;
        UITapGestureRecognizer *ges = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didfAction:)];
        [down addGestureRecognizer:ges];
        
//        _progress1View  = [[UIView alloc]initWithFrame:CGRectMake(50, 10, ATGetDeviceWidth-70, 10)];
//        [self.speed1View addSubview:_progress1View];
//        _progress1View.backgroundColor =rgba(217, 215, 217, 1);
//        _progress1View.layer.cornerRadius = 5;
//        _progress1View.layer.masksToBounds = YES;
        
        _progress1View = [[WTProgressView alloc] initWithFrame:CGRectMake(70, 15, ATGetDeviceWidth-90, 10)];
        [self.speed1View addSubview:_progress1View];
        _progress1View.gradientColors = @[RGB(0x98DCD2),RGB(0x00A0F0)];
        _progress1View.progress = 0;
        _progress1View.layer.cornerRadius = 5.0;
        _progress1View.layer.masksToBounds = YES;
        _progress1View.backgroundColor = rgba(217, 215, 217, 1);
        
        
//        UIButton *leftBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, (ATGetDeviceWidth-70)/4, 30)];
//        [_progress1View addSubview:leftBtn];
////        [leftBtn addTarget:self action:@selector(didfAction:) forControlEvents:UIControlEventTouchUpInside];
////        leftBtn.backgroundColor  =rgba(217, 215, 217, 1);
//        leftBtn.tag = 10;
//
//        UIButton *middleBtn = [[UIButton alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-70)/4, 0, (ATGetDeviceWidth-70)/4, 30)];
//        [_progress1View addSubview:middleBtn];
////        [middleBtn addTarget:self action:@selector(didfAction:) forControlEvents:UIControlEventTouchUpInside];
////        middleBtn.backgroundColor  =rgba(217, 215, 217, 1);
//        middleBtn.tag = 11;
//
//        UIButton *rightBtn = [[UIButton alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-70)/4*2,0, (ATGetDeviceWidth-70)/4, 30)];
//        [_progress1View addSubview:rightBtn];
////        [rightBtn addTarget:self action:@selector(didfAction:) forControlEvents:UIControlEventTouchUpInside];
////        rightBtn.backgroundColor  =rgba(217, 215, 217, 1);
//        rightBtn.tag = 12;
//
//        UIButton *fourBtn = [[UIButton alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-70)/4*3,0, (ATGetDeviceWidth-70)/4, 30)];
//        [_progress1View addSubview:fourBtn];
////        [fourBtn addTarget:self action:@selector(didfAction:) forControlEvents:UIControlEventTouchUpInside];
////        fourBtn.backgroundColor  =rgba(217, 215, 217, 1);
//        fourBtn.tag = 13;

        if ([self.notiDic[@"4"] isKindOfClass:[NSNull class]] || [self.notiDic[@"4"] isEqual:[NSNull null]] || self.notiDic[@"4"] == nil||[self.notiDic[@"0"] isKindOfClass:[NSNull class]] || [self.notiDic[@"0"] isEqual:[NSNull null]] || self.notiDic[@"0"] == nil||[self.deviceDic[@"4"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"4"] isEqual:[NSNull null]] || self.deviceDic[@"4"] == nil||[self.deviceDic[@"0"] isKindOfClass:[NSNull class]] || [self.deviceDic[@"0"] isEqual:[NSNull null]] || self.deviceDic[@"0"] == nil) {
        }
        else
        {
            
        _currentF =[self.notiDic[@"4"] integerValue];
        if ([[self.notiDic allKeys]count]!=0 && ![self.notiDic isKindOfClass:[NSNull class]])
        {
            _openOrClose = [self.notiDic[@"0"] integerValue];
            NSInteger num1 = [self.notiDic[@"4"] integerValue];
            [self changeFenWeiDeng:nil num:num1];
        }else
        {
        
            
        _openOrClose = [self.deviceDic[@"0"] integerValue];

        NSInteger num1 = [self.deviceDic[@"4"] integerValue];
        [self changeFenWeiDeng:nil num:num1];
        }
        }
        
    }
    
    
    if ([self.titleStr isEqualToString:@"定时"]) {
        
        [self.weatherView removeFromSuperview];
        [self.gifView removeFromSuperview];

        
        _middleView = [[UIView alloc]initWithFrame:CGRectMake(50, 80, ATGetDeviceWidth-100, 30)];
        [self.view addSubview:_middleView];
        _middleView.backgroundColor =rgba(217, 215, 217, 1);
        _middleView.layer.cornerRadius = 15;
        _middleView.layer.masksToBounds = YES;
        
        _leftBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, (ATGetDeviceWidth-100)/2, 30)];
        [_middleView addSubview:_leftBtn];
        [_leftBtn setTitle:@"连续运行" forState:UIControlStateNormal];
        _leftBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [_leftBtn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];
        _leftBtn.backgroundColor  =RGB(0x90e1f4);;
        [_leftBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        _rightBtn = [[UIButton alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-100)/2, 0, (ATGetDeviceWidth-100)/2, 30)];
        [_middleView addSubview:_rightBtn];
        [_rightBtn setTitle:@"间歇运行" forState:UIControlStateNormal];
        _rightBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [_rightBtn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];
        _rightBtn.backgroundColor  =rgba(217, 215, 217, 1);
        [_rightBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        _downView = [[UIView alloc]initWithFrame:CGRectMake(50, 120, ATGetDeviceWidth-100, 30)];
        [self.view addSubview:_downView];
        _downView.backgroundColor =rgba(217, 215, 217, 1);
        _downView.layer.cornerRadius = 15;
        _downView.layer.masksToBounds = YES;
        
        _leftDBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, (ATGetDeviceWidth-100)/2, 30)];
        [_downView addSubview:_leftDBtn];
        [_leftDBtn setTitle:@"一次" forState:UIControlStateNormal];
        _leftDBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [_leftDBtn addTarget:self action:@selector(didDAction:) forControlEvents:UIControlEventTouchUpInside];
        _leftDBtn.backgroundColor  =RGB(0x90e1f4);;
        [_leftDBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        _rightDBtn = [[UIButton alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-100)/2, 0, (ATGetDeviceWidth-100)/2, 30)];
        [_downView addSubview:_rightDBtn];
        [_rightDBtn setTitle:@"每天" forState:UIControlStateNormal];
        _rightDBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [_rightDBtn addTarget:self action:@selector(didDAction:) forControlEvents:UIControlEventTouchUpInside];
        _rightDBtn.backgroundColor  =rgba(217, 215, 217, 1);
        [_rightDBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        
        
        
        UILabel *leftLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 200, ATGetDeviceWidth/2, 20)];
        leftLabel.text = @"启动时间";
        [self.view addSubview:leftLabel];
        leftLabel.textAlignment = NSTextAlignmentCenter;
        
        _starTime = [[UIButton alloc]initWithFrame:CGRectMake(10, 230, (ATGetDeviceWidth-40)/2, 50)];
        [self.view addSubview:_starTime];
        [_starTime setTitle:@"06:00" forState:UIControlStateNormal];
        _starTime.titleLabel.font = [UIFont systemFontOfSize:20];
        [_starTime addTarget:self action:@selector(didStar:) forControlEvents:UIControlEventTouchUpInside];
        _starTime.backgroundColor  =RGB(0x90e1f4);;
        [_starTime setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _starTime.layer.cornerRadius = 5;
        _starTime.layer.masksToBounds = YES;
        _starTime.tag = 1;
        
        
        UILabel *rightLabel = [[UILabel alloc]initWithFrame:CGRectMake( ATGetDeviceWidth/2, 200, ATGetDeviceWidth/2, 20)];
        rightLabel.text = @"关闭时间";
        [self.view addSubview:rightLabel];
        rightLabel.textAlignment = NSTextAlignmentCenter;
        
        _endTime = [[UIButton alloc]initWithFrame:CGRectMake(10+(ATGetDeviceWidth-40)/2+10, 230, (ATGetDeviceWidth-40)/2, 50)];
        [self.view addSubview:_endTime];
        [_endTime setTitle:@"12:00" forState:UIControlStateNormal];
        _endTime.titleLabel.font = [UIFont systemFontOfSize:20];
        [_endTime addTarget:self action:@selector(didStar:) forControlEvents:UIControlEventTouchUpInside];
        _endTime.backgroundColor  =RGB(0x90e1f4);;
        [_endTime setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _endTime.layer.cornerRadius = 5;
        _endTime.layer.masksToBounds = YES;
        _endTime.tag = 2;

        
        self.stringFirst = @"连续运行";
        self.stringTwo = @"一次";


        
        UIButton *setBtn = [[UIButton alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-60)/2, ATGetDeviceHeight-100-80, 60, 60)];
        [self.view addSubview:setBtn];
        [setBtn setTitle:@"添加\n设定" forState:UIControlStateNormal];
        setBtn.titleLabel.numberOfLines = 0;
        setBtn.titleLabel.font = [UIFont systemFontOfSize:12];
        [setBtn addTarget:self action:@selector(didSetTime) forControlEvents:UIControlEventTouchUpInside];
        setBtn.backgroundColor  =RGB(0x90e1f4);;
        [setBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        setBtn.layer.cornerRadius = 30;
        setBtn.layer.masksToBounds = YES;
        
        _titleView = [[UIView alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-100-80-50, ATGetDeviceWidth, 30)];
        [self.view addSubview:_titleView];
//        _titleView.backgroundColor = rgba(217, 215, 217, 1);
        UITapGestureRecognizer *did = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didDelete)];
        [_titleView addGestureRecognizer:did];
        _titleView.hidden= YES;
        _titleView.userInteractionEnabled = YES;
        
        _timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(40, 0, ATGetDeviceWidth-80, 30)];
        [self.titleView addSubview:_timeLabel];
        _timeLabel.font = [UIFont systemFontOfSize:14];
        _timeLabel.textColor = RGB(0x90e1f4);;
        _timeLabel.layer.masksToBounds = YES;
        _timeLabel.layer.cornerRadius = 15;
//        _timeLabel.textColor = [UIColor whiteColor];
        _timeLabel.backgroundColor = rgba(235, 235, 235, 1);
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        

        
        
        [self getTiming:@"0"];
        
    }

    
    
}

#pragma mark -点击事件-
-(void)didClose
{
//    [self.loadingimage removeFromSuperview];
//    NSString *filepath = [[NSBundle bundleWithPath:[[NSBundle mainBundle] bundlePath]] pathForResource:self.dic[@"gifb"] ofType:nil];
//    self.loadingimage.animatedImage = nil;
    self.loadingimage.image =nil;

//    NSLog(@"%@删除了gif=================",self.titleStr);
}
-(void)didDelete
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"是否需要删除设定" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self cancleTiming];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }]];
    // 弹出对话框
    [self presentViewController:alert animated:true completion:nil];
    
    
}
-(void)didSetTime
{
    [self getControl:@"0" num:@"5" btn:nil];
//    [self setTiming];
}
-(void)didChangePic:(UIButton *)btn
{
    btn.selected = !btn.selected;
    if (btn.selected) {
        _gifView.hidden = YES;
        _openView.hidden = NO;

    }else
    {
        _gifView.hidden = NO;
        _openView.hidden = YES;
    }
}
-(void)didAction
{
    [self dismissViewControllerAnimated:NO completion:nil];
    
//    UIViewController *parentVC = self.presentingViewController;
//    UIViewController *bottomVC;
//    while (parentVC) {
//        bottomVC = parentVC;
//        parentVC = parentVC.presentingViewController;
//    }
//    [bottomVC dismissViewControllerAnimated:NO completion:^{
//        //dismiss后再切换根视图
//        [UIApplication sharedApplication].delegate.window.rootViewController = [GSJDeviceListViewController new];
//    }];
}
-(void)didChange:(NSNotification *)noti
{
    NSDictionary  *dic = [noti userInfo];

    NSLog(@"接收 object传递的消息：%@",dic);
    

    
}
#pragma mark 字典转化字符串
-(NSString*)dictionaryToJson:(NSDictionary *)dic
{
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}
#pragma mark-调节所有设置-
//level
//对应value

//num 对应控制类型
//0 开关 bool 上报/控制 0：关 1：开 打开电源 {"0",1} 关闭电源 {"0",0}
//1 智能模式 bool 上报/控制 0：连续运转模式 1：智能模式 连续运转模式 {"1",0} 智能模式 {"1",1}
//2 键盘锁 bool 上报/控制 0：解锁 1：上锁 解锁 {"2",0} 上锁 {"2",1}
//3 风力强度 u8 上报/控制 01最弱,02中,03最强
//4 氛围灯 u8 上报/控制 0关闭，01最弱,02中,03最强
//5 定时设置 u8 上报/控制 0/无定时，01/3小时,02/6小时,03/12小时
//6 水位值 U16 上报 0-1000
-(void)getControl:(NSString *)level num:(NSString *)num btn:(UIButton *)btn
{
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    NSDictionary *dic = @{
                          num:[NSNumber numberWithInteger:[level integerValue]]
                          };
    NSString *cmd = [self dictionaryToJson:dic];
    

    NSDictionary *dicc=@{
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"did":self.controlDic[@"did"],
                        @"cmd":cmd,
                        @"token":[token getValue]
                        };

    NSString *parameter =[NSString stringWithFormat:@"did=%@&cmd=%@&token=%@&appid=1288&motime=%@&sign=%@",self.controlDic[@"did"],cmd,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dicc]];

    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/cmd/control";
    if ([self.oneKey isEqualToString:@"2"]) {
        url = @"http://smart.airmedic.cn:9088/arm/api/cmd/onekey";
        NSDictionary *diccc=@{
                             @"appid":@"1288",
                             @"motime":[[PruManerge sharePruManerge]getTime],
                             @"cmd":cmd,
                             @"token":[token getValue]
                             };
        
        parameter =[NSString stringWithFormat:@"cmd=%@&token=%@&appid=1288&motime=%@&sign=%@",cmd,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:diccc]];
    }
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:@{} parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            if ([num isEqualToString:@"4"]) {
                
                [self changeFenWeiDeng:btn num:self.currentF];
            }
            if ([num isEqualToString:@"3"]) {
                [self changeFengLi:btn num:self.currentFL];
            }
            if ([num isEqualToString:@"5"]) {
                [self setTiming];
            }
        }else
        {
            if ([num isEqualToString:@"3"]) {

            if (self->_currentFL ==1) {
                self->_currentFL =3;
            }else
            {
                self->_currentFL--;
            }
            }
            
            if ([num isEqualToString:@"4"]) {

            if (self->_currentF ==0) {
                self->_currentF =3;
            }else
            {
                self->_currentF--;
            }
            }
            [MBProgressHUD showMessage:response[@"msg"]];
        }
        
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([num isEqualToString:@"4"]) {

        if (self->_currentF ==0) {
            self->_currentF =3;
        }else
        {
            self->_currentF--;
        }
        }
        
        if ([num isEqualToString:@"3"]) {
            
            if (self->_currentFL ==1) {
                self->_currentFL =3;
            }else
            {
                self->_currentFL--;
            }
        }
        
        
    }];
}
#pragma mark -查询定时-open=1为开关不需要模式
-(void)getTiming:(NSString *)open
{
    
//    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
//    NSDictionary *dic = @{
////                          num:[NSNumber numberWithInteger:[level integerValue]]
//                          };
//    NSString *cmd = [self dictionaryToJson:dic];

    NSDictionary *dic=@{
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"did":self.controlDic[@"did"],
                        @"appid":@"1288",
                        @"token":[token getValue]
                        };
    
    NSString *parameter =[NSString stringWithFormat:@"did=%@&token=%@&appid=1288&motime=%@&sign=%@",self.controlDic[@"did"],[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    //    NSDictionary *dic =@{
    //                         //                         @"smstype":@"REG",
    //                         //                         @"phone":_phoneField.text
    //                         };
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/dvc/getTiming";
    
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
//        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            if([response[@"data"] count] ==0)
            {
                _twoLabel.text = @"无定时";
                return ;
            }
            NSDictionary *dic = response[@"data"][0];
            if ([dic[@"isloop"] integerValue] ==1) {
                self.stringTwo = @"每天";
//                _leftDBtn.selected = NO;
//                _rightDBtn.selected = YES;
                self->_rightDBtn.backgroundColor  =RGB(0x90e1f4);;
                self->_leftDBtn.backgroundColor  =rgba(217, 215, 217, 1);
            }else
            {
                self.stringTwo = @"一次";
//                _rightDBtn.selected = NO;
//                _leftDBtn.selected = YES;
                self->_leftDBtn.backgroundColor  =RGB(0x90e1f4);;
                self->_rightDBtn.backgroundColor  =rgba(217, 215, 217, 1);
            }
            
            
            
           
                if ([dic[@"mode"] integerValue] ==0) {
                    //                _leftBtn.selected = YES;
                    //                _rightBtn.selected = NO;
                            self.stringFirst = @"连续运行";
                     if ([open isEqualToString:@"0"]) {
                         
              

                    self->_leftBtn.backgroundColor  =RGB(0x90e1f4);
                    self->_rightBtn.backgroundColor  =rgba(217, 215, 217, 1);
                     }
                }else
                {
                    //                _leftBtn.selected = NO;
                    //                _rightBtn.selected = YES;
                    self.stringFirst = @"间歇运行";

                    if ([open isEqualToString:@"0"]) {

                    self->_rightBtn.backgroundColor  =RGB(0x90e1f4);
                    self->_leftBtn.backgroundColor  =rgba(217, 215, 217, 1);
                    }
                }
            
           
         
            
            [self.starTime setTitle:dic[@"startime"] forState:UIControlStateNormal];
            [self.endTime setTitle:dic[@"endtime"] forState:UIControlStateNormal];
            
            self->_timeLabel.text =[NSString stringWithFormat:@"设定: %@-%@ %@ %@",dic[@"startime"],dic[@"endtime"],self.stringFirst,self.stringTwo];
            self->_titleView.hidden = NO;
            
            self.twoLabel.text = [NSString stringWithFormat:@"%@开始%@%@h",dic[@"startime"],self.stringFirst,[self timeInter:dic[@"startime"] endTime:dic[@"endtime"]]];
        }
        
        
    } failBlock:^(NSError *error) {
//        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
}
-(NSString *)timeInter:(NSString *)starTime endTime:(NSString *)endTime
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"HH:mm"];
//    NSDate *startDate = [self.cachedDateFormatter dateFromString:starTime];
//    NSDate *endDate = [self.cachedDateFormatter dateFromString:endTime];
    NSDate *startDate = [dateFormatter dateFromString:starTime];
    NSDate *endDate = [dateFormatter dateFromString:endTime];
    NSTimeInterval time = [endDate timeIntervalSinceDate:startDate];
//
    double hourr = time/3600;
    int hour =(int)hourr%24;
//
    double minutee = time/60;
    int minute =(int)minutee%60;
    double m = (double)minute/60.f;
//   double minute =(time/60)%60;
//   double hour = (time/3600)%24;
    return [NSString stringWithFormat:@"%.2f",hour+m];
    
//    return @"1.5h";
    
}
#pragma mark -设定定时-
-(void)setTiming
{
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    NSDictionary *dic = @{
                          @"start":_starTime.titleLabel.text,
                          @"end":_endTime.titleLabel.text
                          };
        NSString *cmd = [self dictionaryToJson:dic];
    

    
    //    NSString *parameter =[NSString stringWithFormat:@"smstype=REG&phone=%@&appid=1288&motime=%@&sign=%@",_phoneField.text,[[PruManerge sharePruManerge]getTime],[[[DivEncode sharePruManerge]getPrukeyMD5:md5] lowercaseString]];
    
    NSString *first = @"1";
    if ([self.stringFirst isEqualToString:@"连续运行"]) {
        first = @"0";
    }
    NSString *two = @"1";
    if ([self.stringTwo isEqualToString:@"一次"]) {
        two = @"0";
    }
    NSDictionary *dicc=@{
                         @"motime":[[PruManerge sharePruManerge]getTime],
                         @"did":self.controlDic[@"did"],
                         @"appid":@"1288",
                         @"isloop":two,
                         @"mode":first,
                         @"t1":cmd,
                         @"token":[token getValue]
                         };
    
    NSString *parameter =[NSString stringWithFormat:@"isloop=%@&mode=%@&t1=%@&did=%@&token=%@&appid=1288&motime=%@&sign=%@",two,first,cmd,self.controlDic[@"did"],[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dicc]];
    
    //    NSDictionary *dic =@{
    //                         //                         @"smstype":@"REG",
    //                         //                         @"phone":_phoneField.text
    //                         };
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/dvc/setTiming";
    
    if ([self.oneKey isEqualToString:@"2"]) {
        url = @"http://smart.airmedic.cn:9088/arm/api/dvc/setTiming";
        NSDictionary *diccc=@{
                             @"motime":[[PruManerge sharePruManerge]getTime],
                             @"appid":@"1288",
                             @"isloop":two,
                             @"mode":first,
                             @"t1":cmd,
                             @"token":[token getValue]
                             };
        
    parameter =[NSString stringWithFormat:@"isloop=%@&mode=%@&t1=%@&token=%@&appid=1288&motime=%@&sign=%@",two,first,cmd,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:diccc]];
    }
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:@{} parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            self->_titleView.hidden = NO;
            self->_timeLabel.text =[NSString stringWithFormat:@"设定: %@-%@ %@ %@",self->_starTime.titleLabel.text,self->_endTime.titleLabel.text,self.stringFirst,self.stringTwo];
//            self.fourLabel.text = self.stringFirst;
//            self.twoLabel.text = [NSString stringWithFormat:@"%@开始%@%@h",dic[@"startime"],self.stringFirst,[self timeInter:self->_starTime.titleLabel.text endTime:self->_endTime.titleLabel.text]];

            [MBProgressHUD showMessage:@"定时设定成功"];
        }
        
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
}
#pragma mark-取消定时-
-(void)cancleTiming
{
    
//    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
    //    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
//    NSDictionary *dic = @{
//                          @"start":_starTime.titleLabel.text,
//                          @"end":_endTime.titleLabel.text
//                          };
//    NSString *cmd = [self dictionaryToJson:dic];
    
    
    
    //    NSString *parameter =[NSString stringWithFormat:@"smstype=REG&phone=%@&appid=1288&motime=%@&sign=%@",_phoneField.text,[[PruManerge sharePruManerge]getTime],[[[DivEncode sharePruManerge]getPrukeyMD5:md5] lowercaseString]];
    
    NSString *first = @"1";
    if ([self.stringFirst isEqualToString:@"连续运行"]) {
        first = @"0";
    }
    NSString *two = @"1";
    if ([self.stringTwo isEqualToString:@"一次"]) {
        two = @"0";
    }
    NSDictionary *dicc=@{
                         @"motime":[[PruManerge sharePruManerge]getTime],
                         @"did":self.controlDic[@"did"],
                         @"appid":@"1288",
                         @"token":[token getValue]
                         };
    
    NSString *parameter =[NSString stringWithFormat:@"did=%@&token=%@&appid=1288&motime=%@&sign=%@",self.controlDic[@"did"],[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dicc]];
    
    //    NSDictionary *dic =@{
    //                         //                         @"smstype":@"REG",
    //                         //                         @"phone":_phoneField.text
    //                         };
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/dvc/delTiming";
    
    if ([self.oneKey isEqualToString:@"2"]) {
        url = @"http://smart.airmedic.cn:9088/arm/api/dvc/delTiming";
        NSDictionary *diccc=@{
                              @"motime":[[PruManerge sharePruManerge]getTime],
                              @"appid":@"1288",
                              @"token":[token getValue]
                              };
        
        parameter =[NSString stringWithFormat:@"token=%@&appid=1288&motime=%@&sign=%@",[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:diccc]];
    }
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:@{} parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
//        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            
            [MBProgressHUD showMessage:@"删除设定成功"];
            self->_titleView.hidden = YES;
            _twoLabel.text = @"无定时";
        }
        
        
    } failBlock:^(NSError *error) {
//        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
}
-(void)didfAction:(UIGestureRecognizer *)ges
{
    if (self->_currentF ==3) {
        self->_currentF =0;
    }else
    {
        self->_currentF++;
    }
      [self getControl:[NSString stringWithFormat:@"%ld",_currentF] num:@"4" btn:nil];

//    if (btn.tag ==10) {
////        for (UIButton *bbtn in self.progress1View.subviews) {
////            bbtn.backgroundColor = rgba(217, 215, 217, 1);
////        }
////        btn.backgroundColor = RGB(0x90e1f4);;
//        [self getControl:@"0" num:@"4" btn:btn];
//
//    }else if (btn.tag == 11)
//    {
////        for (UIButton *bbtn in self.progress1View.subviews) {
////            if (bbtn.tag ==10 || bbtn.tag ==11) {
////                bbtn.backgroundColor = RGB(0x90e1f4);;
////            }else
////            {
////                bbtn.backgroundColor = rgba(217, 215, 217, 1);
////            }
////        }
//          [self getControl:@"1" num:@"4" btn:btn];
//    }else if (btn.tag == 12)
//    {
////        for (UIButton *bbtn in self.progress1View.subviews)
////        {
////            bbtn.backgroundColor = RGB(0x90e1f4);;
////        }
//        [self getControl:@"2" num:@"4" btn:btn];
//    }else
//    {
//        [self getControl:@"3" num:@"4" btn:btn];
//    }
    
//    NSInteger tag = btn.tag;
//    NSString *sting = @"弱灯";
//    _itemView.image = [UIImage imageNamed:@"弱灯"];
//
//    if (tag ==11) {
//        sting = @"中灯";
//        _itemView.image = [UIImage imageNamed:@"中灯"];
//
//    }else if(tag == 12)
//    {
//        sting = @"强灯";
//        _itemView.image = [UIImage imageNamed:@"强灯"];
//    }

//    [[NSNotificationCenter defaultCenter] postNotificationName:@"changeNoti" object:sting];
}
#pragma mark -更改氛围灯UI-
-(void)changeFenWeiDeng:(UIButton *)btn num:(NSInteger)num
{
    

    if (num!=100)
    {
        
        NSString *sting = @"关灯";

    if (num ==0) {
        _itemView.image = [UIImage imageNamed:@"关灯"];

//        for (UIButton *bbtn in self.progress1View.subviews) {
//            bbtn.backgroundColor = rgba(217, 215, 217, 1);
//            if (bbtn.tag ==10) {
//                bbtn.backgroundColor = RGB(0x90e1f4);;
//            }
//        }
        _progress1View.progress = 0;

        
    }else if (num == 1)
    {
        _itemView.image = [UIImage imageNamed:@"弱灯"];
        sting = @"弱灯";
        _progress1View.progress = 0.33;

//        for (UIButton *bbtn in self.progress1View.subviews) {
//            bbtn.backgroundColor = rgba(217, 215, 217, 1);
//            if (bbtn.tag ==10 || bbtn.tag ==11) {
//                bbtn.backgroundColor = RGB(0x90e1f4);;
//            }else
//            {
//                bbtn.backgroundColor = rgba(217, 215, 217, 1);
//            }
//        }
        
     
    }else if (num == 2)
    {
        _itemView.image = [UIImage imageNamed:@"中灯"];
        sting = @"中灯";
        _progress1View.progress = 0.66;


//        for (UIButton *bbtn in self.progress1View.subviews) {
//            if (bbtn.tag ==10 || bbtn.tag ==11||bbtn.tag ==12) {
//                bbtn.backgroundColor = RGB(0x90e1f4);;
//            }else
//            {
//                bbtn.backgroundColor = rgba(217, 215, 217, 1);
//            }
//        }
    }else
    {
        _itemView.image = [UIImage imageNamed:@"强灯"];
        sting = @"强灯";
        _progress1View.progress = 1.0;


//        for (UIButton *bbtn in self.progress1View.subviews)
//        {
//            bbtn.backgroundColor = RGB(0x90e1f4);;
//        }
    }
    
    if (self.openOrClose ==0) {
        _itemView.image = [UIImage imageNamed:@"关机"];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"changeNoti" object:@"关机"];
    }else
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"changeNoti" object:sting];

    }
       
        
    }else
    {
        if (btn.tag ==10) {
//            for (UIButton *bbtn in self.progress1View.subviews) {
//                bbtn.backgroundColor = rgba(217, 215, 217, 1);
//                if (bbtn.tag ==10) {
//                    bbtn.backgroundColor = RGB(0x90e1f4);;
//                }
//
//            }
            _progress1View.progress = 0;

        }else if (btn.tag == 11)
        {
            _progress1View.progress = 0.33;

//            for (UIButton *bbtn in self.progress1View.subviews) {
//                if (bbtn.tag ==10 || bbtn.tag ==11) {
//                    bbtn.backgroundColor = RGB(0x90e1f4);;
//                }else
//                {
//                    bbtn.backgroundColor = rgba(217, 215, 217, 1);
//                }
//            }
        }else if (btn.tag == 12)
        {
            _progress1View.progress = 0.66;

//            for (UIButton *bbtn in self.progress1View.subviews) {
//                if (bbtn.tag ==10 || bbtn.tag ==11|| bbtn.tag ==12) {
//                    bbtn.backgroundColor = RGB(0x90e1f4);;
//                }else
//                {
//                    bbtn.backgroundColor = rgba(217, 215, 217, 1);
//                }
//            }
        }else
        {
//            for (UIButton *bbtn in self.progress1View.subviews)
//            {
//                bbtn.backgroundColor = RGB(0x90e1f4);;
//            }
            _progress1View.progress = 1.0;

        }
        NSInteger tag = btn.tag;
        
        NSString *sting = @"关灯";
        
        if (tag ==10) {
            _itemView.image = [UIImage imageNamed:@"关灯"];

        }else if(tag == 11)
        {
            sting = @"弱灯";
            _itemView.image = [UIImage imageNamed:@"弱灯"];
        }else if(tag == 12)
        {
            sting = @"中灯";
            _itemView.image = [UIImage imageNamed:@"中灯"];

        }else
        {
            sting = @"强灯";

            _itemView.image = [UIImage imageNamed:@"强灯"];

        }
        
        if (self.openOrClose ==0) {
            _itemView.image = [UIImage imageNamed:@"关机"];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"changeNoti" object:@"关机"];
        }else
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"changeNoti" object:sting];
            
        }
        
    }
}
-(void)didPAction:(UIGestureRecognizer *)ges
{
//    if (btn.tag ==100) {
//        [self getControl:@"1" num:@"3" btn:btn];
//    }else if (btn.tag == 101)
//    {
//        [self getControl:@"2" num:@"3" btn:btn];
//
//    }else
//    {
//        [self getControl:@"3" num:@"3" btn:btn];
//    }
    
    if (self->_currentFL ==3) {
        self->_currentFL =1;
    }else
    {
        self->_currentFL++;
    }
    [self getControl:[NSString stringWithFormat:@"%ld",_currentFL] num:@"3" btn:nil];

}
#pragma mark -更改风力UI-
-(void)changeFengLi:(UIButton *)btn num:(NSInteger)num
{
    if (num!=100)
    {
        
        NSString *gifa = @"0.7x_a.gif";
        NSString *gifb = @"0.7x_b.gif";
        if (num==1) {
//            for (UIButton *bbtn in self.progressView.subviews) {
//                bbtn.backgroundColor = rgba(217, 215, 217, 1);
//                if (bbtn.tag ==100) {
//                    bbtn.backgroundColor = RGB(0x90e1f4);;
//                }
//            }
            _progressView.progress = 0.33;

            
        }else if (num ==2)
        {
            gifa = @"1.3x_a.gif";
            gifb = @"1.3x_b.gif";
//            for (UIButton *bbtn in self.progressView.subviews) {
//                if (bbtn.tag ==100 || bbtn.tag ==101) {
//                    bbtn.backgroundColor = RGB(0x90e1f4);;
//                }else
//                {
//                    bbtn.backgroundColor = rgba(217, 215, 217, 1);
//                }
//            }

            _progressView.progress = 0.66;

        }else
        {
            gifa = @"2x_a.gif";
            gifb = @"2x_b.gif";
//            for (UIButton *bbtn in self.progressView.subviews)
//            {
//                bbtn.backgroundColor = RGB(0x90e1f4);;
//            }

            _progressView.progress = 1;

        }
        _gifa = gifa;
        _gifb = gifb;
        
        NSDictionary *dic = @{
                              @"gifa":gifa,
                              @"gifb":gifb
                              };
//        NSString *filepath = [[NSBundle bundleWithPath:[[NSBundle mainBundle] bundlePath]] pathForResource:dic[@"gifb"] ofType:nil];
//         self.loadingimage.animatedImage = [FLAnimatedImage animatedImageWithGIFData:[NSData dataWithContentsOfFile:filepath]];
        
        
        self.loadingimage.image = [YYImage imageNamed:gifb];

        [[NSNotificationCenter defaultCenter] postNotificationName:@"didChange" object:nil userInfo:dic];

        if (_openOrClose==0) {
            self.loadingimage.hidden = YES;
        }else
        {
            self.loadingimage.hidden = NO;
        }

    }else{
    
    if (btn.tag ==100) {
//        for (UIButton *bbtn in self.progressView.subviews) {
//            bbtn.backgroundColor = rgba(217, 215, 217, 1);
//        }
//        btn.backgroundColor = RGB(0x90e1f4);;
         _progressView.progress = 0.33;
        
    }else if (btn.tag == 101)
    {
//        for (UIButton *bbtn in self.progressView.subviews) {
//            if (bbtn.tag ==100 || bbtn.tag ==101) {
//                bbtn.backgroundColor = RGB(0x90e1f4);;
//            }else
//            {
//                bbtn.backgroundColor = rgba(217, 215, 217, 1);
//            }
//        }
        _progressView.progress = 0.66;
    }else
    {
//        for (UIButton *bbtn in self.progressView.subviews)
//        {
//            bbtn.backgroundColor = RGB(0x90e1f4);;
//        }
         _progressView.progress = 1;
    }

    
    NSInteger tag = btn.tag;
    NSString *gifa = @"0.7x_a.gif";
    NSString *gifb = @"0.7x_b.gif";
    
    if (tag ==101) {
        gifa = @"1.3x_a.gif";
        gifb = @"1.3x_b.gif";
        
    }else if(tag == 102)
    {
        gifa = @"2x_a.gif";
        gifb = @"2x_b.gif";
    }
    _gifa = gifa;
    _gifb = gifb;
    
    NSDictionary *dic = @{
                          @"gifa":gifa,
                          @"gifb":gifb
                          };
//        NSString *filepath = [[NSBundle bundleWithPath:[[NSBundle mainBundle] bundlePath]] pathForResource:dic[@"gifb"] ofType:nil];
//         self.loadingimage.animatedImage = [FLAnimatedImage animatedImageWithGIFData:[NSData dataWithContentsOfFile:filepath]];
        
        self.loadingimage.image = [YYImage imageNamed:gifb];

        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"didChange" object:nil userInfo:dic];
        if (_openOrClose==0) {
            self.loadingimage.hidden = YES;
        }else
        {
            self.loadingimage.hidden = NO;
        }
}

    
}

-(void)didStar:(UIButton *)btn
{
    if (btn.tag ==1) {
        NSLog(@"点击了开始");
        HYTimePickerView *picker = [[HYTimePickerView alloc] initDatePackerWithStartHour:@"00" endHour:@"24" period:1 selectedHour:@"08" selectedMin:@"00"];
        picker.delegate = self;
        [picker show];
        _btnTag =1;
    }else
    {
        NSLog(@"点击了结束");
        HYTimePickerView *picker = [[HYTimePickerView alloc] initDatePackerWithStartHour:@"00" endHour:@"24" period:1 selectedHour:@"08" selectedMin:@"00"];
        picker.delegate = self;
        [picker show];
        _btnTag =2;

    }
}

-(void)didDAction:(UIButton *)btn
{

    for (UIButton *btnnn in self.downView.subviews) {
        btnnn.backgroundColor  =rgba(217, 215, 217, 1);
    }
    btn.backgroundColor  =RGB(0x90e1f4);;
    self.stringTwo = btn.titleLabel.text;

}
-(void)didAction:(UIButton *)btn
{
    for (UIButton *btnn in self.middleView.subviews) {
        btnn.backgroundColor  =rgba(217, 215, 217, 1);
    }
    btn.backgroundColor  =RGB(0x90e1f4);;
    self.stringFirst = btn.titleLabel.text;
}
-(void)didActionOpen:(UIButton *)btn
{
//    for (UIButton *btnn in self.middleView.subviews) {
//        btnn.backgroundColor  =rgba(217, 215, 217, 1);
//    }
//    btn.backgroundColor  =RGB(0x90e1f4);;
    self.stringFirstOpen = btn.titleLabel.text;
    if ([self.stringFirstOpen isEqualToString:@"连续运行"]) {
        [self getControl:@"0" num:@"1" btn:btn];
    }else
    {
        [self getControl:@"1" num:@"1" btn:btn];
    }
    
    
}


#pragma mark -选择时间回调-
-(void)timePickerViewDidSelectRow:(NSString *)time{
    
    NSLog(@"%@",time);
    if (_btnTag ==1) {
        [self.starTime setTitle:time forState:UIControlStateNormal];
    }else
    {
        [self.endTime setTitle:time forState:UIControlStateNormal];
    }
//    _startTime.text = time;
}

+ (UIColor*) randomColor{
    NSInteger r = arc4random() % 255;
    NSInteger g = arc4random() % 255;
    NSInteger b = arc4random() % 255;
    return [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1];
}

@end
