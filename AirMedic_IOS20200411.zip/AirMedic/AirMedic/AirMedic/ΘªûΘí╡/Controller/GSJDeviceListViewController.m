//
//  TTCompanionViewController.m
//  天天练琴(学生)
//
//  Created by kaka on 2019/3/14.
//  Copyright © 2019年 kaka. All rights reserved.
//

#import "GSJDeviceListViewController.h"
#import "GSJDeviceListTableViewCell.h"
#import "GSJSearchDeviceViewController.h"
#import "GSJListDetailViewController.h"
@interface GSJDeviceListViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIView *middleView;

@property (nonatomic,strong) UITableView *mainTableView;
@property (nonatomic,strong) NSMutableArray *mainArray;
@property (nonatomic,strong) UILabel *noData;
@property (nonatomic,strong) dispatch_source_t timer;
@end

@implementation GSJDeviceListViewController
-(void)dealloc
{
    if (_timer) {
        dispatch_source_cancel(_timer);
        _timer = nil;
    }
}
-(UILabel *)noData
{
    if (!_noData) {
        _noData = [[UILabel alloc]initWithFrame:CGRectMake(0, 200, ATGetDeviceWidth, 20)];
        _noData.text = @"暂无设备";
        [_mainTableView addSubview:_noData];
        _noData.textAlignment = NSTextAlignmentCenter;
    }
    return _noData;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    [self getMyfriends];
}
-(UITableView *)mainTableView
{
    if (!_mainTableView) {
        _mainTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 66+iPhoneX_SPACE_TOP, ATGetDeviceWidth, ATGetDeviceHeight-66-50-iPhoneX_SPACE_TOP)];
        [self.view addSubview:_mainTableView];
        if (@available(iOS 11.0, *)) {
            _mainTableView.estimatedRowHeight = 0;
            _mainTableView.estimatedSectionFooterHeight = 0;
            _mainTableView.estimatedSectionHeaderHeight = 0;
            _mainTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        } else {
            self.automaticallyAdjustsScrollViewInsets = NO;
            NSLog(@"10f");
        }
        _mainTableView.delegate = self;
        _mainTableView.dataSource = self;
        _mainTableView.tableFooterView = [[UIView alloc]init];
        _mainTableView.backgroundColor =[UIColor whiteColor];
        _mainTableView.separatorStyle = UITableViewCellEditingStyleNone;     //让tableview不显示分割线
        
        
    }
    return _mainTableView;
}
-(UIView *)headView
{
    if (!_headView) {
        _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, 44+22+iPhoneX_SPACE_TOP)];
        [self.view addSubview:_headView];
        _headView.backgroundColor = [UIColor whiteColor];
        
    }
    return _headView;
}
-(NSMutableArray *)mainArray
{
    if (!_mainArray) {
        _mainArray = [NSMutableArray array];
    }
    return _mainArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    self.view.backgroundColor =[UIColor colorWithRed:249/255.0 green:247/255.0 blue:245/255.0 alpha:1.0];
    
        UILabel *headLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,15+22+iPhoneX_SPACE_TOP,ATGetDeviceWidth,19)];
        [self.headView addSubview:headLabel];
        NSMutableAttributedString *headString = [[NSMutableAttributedString alloc] initWithString:@"设备列表" attributes:@{NSFontAttributeName: [UIFont fontWithName:@"PingFang-SC-Medium" size: 16],NSForegroundColorAttributeName: [UIColor blackColor]}];
        headLabel.attributedText = headString;
        headLabel.textAlignment = NSTextAlignmentCenter;
    
//
//        UIButton *btn  = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-80,36,70,15)];
//        [self.headView addSubview:btn];
//        //    [btn setImage:[UIImage imageNamed:@"icon-kefu"] forState:UIControlStateNormal];
//        [btn setTitle:@"兑换记录" forState:UIControlStateNormal];
//        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//        [btn addTarget:self action:@selector(didKeFuAction) forControlEvents:UIControlEventTouchUpInside];
//        btn.titleLabel.font = [UIFont systemFontOfSize:15];
    
        UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(6,34+iPhoneX_SPACE_TOP,23,23)];
        [self.view addSubview:leftBtn];
//        [leftBtn setImage:[UIImage imageNamed:@"菜单"] forState:UIControlStateNormal];
        [leftBtn setBackgroundImage:[UIImage imageNamed:@"菜单"] forState:UIControlStateNormal];

        [leftBtn addTarget:self action:@selector(didMy) forControlEvents:UIControlEventTouchUpInside];
    //
    //    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(42, 14, 70, 14)];
    //    [self.middleView addSubview:label];
    //    label.text = @"综合(默认)";
    //    label.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0];
    //    label.font = [UIFont systemFontOfSize:14];
    //
    //
    //    UIButton *categoryBtn  = [[UIButton alloc]initWithFrame:CGRectMake(161,14,50,13)];
    //    [self.middleView addSubview:categoryBtn];
    //    [categoryBtn setImage:[UIImage imageNamed:@"icon-drop"] forState:UIControlStateNormal];
    //    [categoryBtn addTarget:self action:@selector(didCategory) forControlEvents:UIControlEventTouchUpInside];
    //    [categoryBtn setTitle:@"分类" forState:UIControlStateNormal];
    //    categoryBtn.titleLabel.font = [UIFont systemFontOfSize:13];
    //    [categoryBtn setTitleColor: [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0] forState:UIControlStateNormal];
    //    CGFloat imageWidth = categoryBtn.imageView.bounds.size.width;
    //    CGFloat labelWidth = categoryBtn.titleLabel.bounds.size.width;
    //    categoryBtn.imageEdgeInsets = UIEdgeInsetsMake(0, labelWidth, 0, -labelWidth);
    //    categoryBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -imageWidth, 0, imageWidth);
    //
    //    UILabel *credit = [[UILabel alloc]initWithFrame:CGRectMake(290, 14, 27, 13)];
    //    [self.middleView addSubview:credit];
    //    credit.text = @"学分";
    //    credit.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0];
    //    credit.font = [UIFont systemFontOfSize:13];
    //
    //
    //    UIButton *upBtn  = [[UIButton alloc]initWithFrame:CGRectMake(324,8,13,13)];
    //    [self.middleView addSubview:upBtn];
    //    [upBtn setImage:[UIImage imageNamed:@"icon-down"] forState:UIControlStateNormal];
    //    [upBtn addTarget:self action:@selector(didUp) forControlEvents:UIControlEventTouchUpInside];
    //
    //    UIButton *downBtn  = [[UIButton alloc]initWithFrame:CGRectMake(324,15,13,13)];
    //    [self.middleView addSubview:downBtn];
    //    [downBtn setImage:[UIImage imageNamed:@"icon-droph"] forState:UIControlStateNormal];
    //    [downBtn addTarget:self action:@selector(didDown) forControlEvents:UIControlEventTouchUpInside];
    //
//        [self.mainArray addObject:@"11"];
//        [self.mainArray addObject:@"11"];
//        [self.mainArray addObject:@"11"];
//        [self.mainArray addObject:@"11"];
//        [self.mainArray addObject:@"11"];
//        [self.mainArray addObject:@"11"];
//        self.mainTableView.userInteractionEnabled = YES;
    
//    [self getMyfriends];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth/2, ATGetDeviceHeight-50, ATGetDeviceWidth/2, 50)];
    [self.view addSubview:btn];
    btn.backgroundColor =  RGB(0x90e1f4);;
    [btn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];
    [btn setTitle:@"添加设备" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    btn.tag = 0;
    
    UIButton *registerBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-50, ATGetDeviceWidth/2, 50)];
    [self.view addSubview:registerBtn];
    registerBtn.backgroundColor = RGB(0x0088c7);
    [registerBtn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];
    [registerBtn setTitle:@"一键设定" forState:UIControlStateNormal];
    [registerBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    registerBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    registerBtn.tag = 1;
}
-(void)didAction:(UIButton *)btn
{
    if (btn.tag == 1) {
//        TTRegisterViewController *vc = [[TTRegisterViewController alloc]init];
//        [self presentViewController:vc animated:YES completion:nil];
        NSInteger num = 0;
        if (self.mainArray.count!=0) {
        for (int i = 0; i<self.mainArray.count;i++)
        {
            NSDictionary *dic = self.mainArray[i];

            if ([dic[@"isonline"] integerValue]==1) {
                GSJListDetailViewController *vc = [[GSJListDetailViewController alloc]init];
                vc.dic = dic;
                vc.oneKey = @"2";
                [self presentViewController:vc animated:NO completion:nil];
                return;
            }else
            {
                num++;
            }
            
            if (num == self.mainArray.count) {
                [MBProgressHUD showMessage:@"没有在线设备，无法一键设定"];
            }
        }
        
    }

        
    }else
    {
        GSJSearchDeviceViewController *vc = [[GSJSearchDeviceViewController alloc]init];
        [self presentViewController:vc animated:YES completion:nil];
//        TTPassLoginViewController *vc = [[TTPassLoginViewController alloc]init];
//        [self presentViewController:vc animated:YES completion:nil];
    }
    if (_timer) {
        dispatch_source_cancel(_timer);
        _timer = nil;
    }
}
//tableView自带的左滑删除
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    //第二组可以左滑删除
    return YES;
    
}
// 定义编辑样式
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleDelete;
    
}
// 进入编辑模式，按下出现的编辑按钮后,进行删除操作
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *dic = self.mainArray[indexPath.section];
      if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [self deleteBtn:dic[@"did"] num:indexPath.section];
    }
    
}
// 修改编辑按钮文字
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath {
    return @"删除";
}



#pragma maek -点击事件-
#pragma maek -删除设备接口-

-(void)deleteBtn:(NSString *)did num:(NSInteger)num
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    
    NSDictionary *dic=@{
                        @"appid":@"1288",
                        @"did":did,
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"token":[token getValue]
                        };
    NSString *parameter =[NSString stringWithFormat:@"did=%@&token=%@&appid=1288&motime=%@&sign=%@",did,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];

    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/dvc/unbind";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:@{} parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            [self.mainArray removeObjectAtIndex:num];
            [self.mainTableView reloadData];;
        }
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];

}
-(void)didMy
{
    NSLog(@"我的资料");
//    //把最前面的视图控制器dismiss掉
//    UIViewController *parentVC = self.presentingViewController;
//    UIViewController *bottomVC;
//    while (parentVC) {
//        bottomVC = parentVC;
//        parentVC = parentVC.presentingViewController;
//    }
//    [bottomVC dismissViewControllerAnimated:NO completion:^{
        //dismiss后再切换根视图
        [UIApplication sharedApplication].delegate.window.rootViewController = [GSJMyViewController new];
        if (_timer) {
            dispatch_source_cancel(_timer);
            _timer = nil;
        }
//    }];
}
-(void)didUp
{
    
}
-(void)didCategory
{
    NSLog(@"点击了分类");
}
-(void)didKeFuAction
{
    NSLog(@"点击了兑换记录");
}
-(void)didBackAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark ------加载tableView-------
-(void)loadNewData
{
}
#pragma mark -UITableViewDelegate-
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.mainArray.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    return 10;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *Id =[NSString stringWithFormat:@"cellId%ld",(long)indexPath.section];
    
    
    GSJDeviceListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Id];
    //    ZFFiancialListDetailModel *model = self.mainNewArray[indexPath.section];
    NSDictionary *dic = self.mainArray[indexPath.section];
    if (!cell) {
        cell = [[GSJDeviceListTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Id];
    }
    cell.backgroundColor= rgba(244, 242, 239, 1);
    cell.nameLabel.text = dic[@"dvcnm"];
    NSString *top1 = @"蓝在线";
    NSString *middle1 = @"蓝开关";
    NSString *down1 = @"蓝液量";

    



//        cell.nameLabel.text = @"MEDIC S1";

    NSString *top = @"在线";
    if ([dic[@"isonline"] integerValue] ==0) {
        top = @"离线";
        top1 = @"灰在线";
        down1 = @"灰液量";
    }
    NSString *middle = @"运行";
    if ([dic[@"ison"] integerValue] ==0) {
        middle = @"关闭";
        middle1 = @"灰开关";
    }
    NSString *down = @"0%";
    NSInteger num=0;
    if ([dic[@"isonline"] integerValue]==1) {
        if ([dic[@"attr6"] isKindOfClass:[NSNull class]]) {
            num = 0;
        }else
        {
            num = [dic[@"attr6"] integerValue];

        }
       
        if (num>=40&&num<97) {
            down = @"100%";
        }
        if (num>=97&&num<119) {
            down = @"80%";
        }
        if (num>=119&&num<141) {
            down = @"60%";
        }
        if (num>=141&&num<164) {
            down = @"40%";
        }
        if (num>=164&&num<=191) {
            down = @"20%";
        }
    }
    
    
    cell.topImage.image = [UIImage imageNamed:top1];
    cell.middleImage.image = [UIImage imageNamed:middle1];
    cell.downImage.image = [UIImage imageNamed:down1];
    
    cell.topLabel.text = top;
    cell.middleLabel.text = middle;
    cell.downLabel.text = down;

    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (_timer) {
        dispatch_source_cancel(_timer);
        _timer = nil;
    }
    NSDictionary *dic = self.mainArray[indexPath.section];
    GSJListDetailViewController *vc = [[GSJListDetailViewController alloc]init];
    vc.dic = dic;
    [self presentViewController:vc animated:NO completion:nil];

}
#pragma mark -获取设备列表-
-(void)getMyfriends
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    
    NSDictionary *dic=@{
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"token":[token getValue]
                        };

    NSString *parameter =[NSString stringWithFormat:@"token=%@&appid=1288&motime=%@&sign=%@",[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/dvc/mylist";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        [self.mainArray removeAllObjects];
        if ([response[@"code"] isEqualToString:@"10000"]) {
            [self.mainArray addObjectsFromArray:response[@"data"]];
        }
        [self.mainTableView reloadData];
        if (self.mainArray.count ==0) {
            self.noData.hidden  =NO;
        }else
        {
            self.noData.hidden =YES;
        }
        
        if (!self.timer) {
            NSTimeInterval period = [response[@"other"][@"refreshsec"] integerValue];
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
            self->_timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
            dispatch_source_set_timer(self->_timer, dispatch_walltime(NULL, 0), period * NSEC_PER_SEC, 0);
            // 事件回调
            dispatch_source_set_event_handler(self->_timer, ^{
                dispatch_async(dispatch_get_main_queue(), ^{
                    NSLog(@"Count");
                    //网络请求 doSomeThing...
                    [self getMyfriends];
                    
                });
            });
            
            // 开启定时器
            dispatch_resume(self->_timer);
        }
        
        
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        self.noData.hidden  =NO;
    }];
    
}

@end
