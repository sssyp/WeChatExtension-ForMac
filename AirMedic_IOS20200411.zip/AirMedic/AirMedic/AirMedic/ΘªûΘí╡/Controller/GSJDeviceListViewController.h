//
//  GSJDeviceListViewController.h
//  AirMedic
//
//  Created by kaka on 2019/8/8.
//  Copyright © 2019 gsj. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GSJDeviceListViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
