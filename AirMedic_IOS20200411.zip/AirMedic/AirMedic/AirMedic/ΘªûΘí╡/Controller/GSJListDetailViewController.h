//
//  GSJListDetailViewController.h
//  AirMedic
//
//  Created by gsj on 2019/8/11.
//  Copyright © 2019年 gsj. All rights reserved.
//

#import "BaseViewController.h"

@interface GSJListDetailViewController : BaseViewController
@property (nonatomic,strong) NSDictionary *dic;
@property (nonatomic,copy) NSString *oneKey;//一键设定2
@end
