//
//  TTLoginViewController.m
//  天天练琴(学生)
//
//  Created by kaka on 2019/3/14.
//  Copyright © 2019年 kaka. All rights reserved.
//


#import "GSJAddEquipmentViewController.h"
#import "GSJSearchDeviceViewController.h"
#import "GSJDeviceListViewController.h"
@interface GSJAddEquipmentViewController ()
@end

@implementation GSJAddEquipmentViewController
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if ([self.login isEqualToString:@"2"]) {
        [self getLogin];
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    
    
}
-(void)initUI
{
    self.view.userInteractionEnabled = YES;
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIView *mainView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, ATGetDeviceHeight-50)];
    [self.view addSubview:mainView];
    
    UIImageView *backView = [[UIImageView alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-250)/2, 100, 250, 250)];
    [mainView addSubview:backView];
    //    backView.image = [UIImage imageNamed:@"bg"];
    backView.contentMode = UIViewContentModeScaleAspectFill;
    backView.userInteractionEnabled = YES;
    backView.image = [UIImage imageNamed:@"添加设备 机器俯瞰图 俯瞰度高6.168"];
    
    UIButton *leftBtn = [[UIButton alloc]initWithFrame:CGRectMake(10, 20+iPhoneX_SPACE_TOP, 23, 23)];
    [mainView addSubview:leftBtn];
    //    leftBtn.backgroundColor =  [UIColor colorWithRed:152/255.0 green:203/255.0 blue:214/255.0 alpha:1.0];
    [leftBtn addTarget:self action:@selector(didMy) forControlEvents:UIControlEventTouchUpInside];
//    [leftBtn setTitle:@"我的资料" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:10];
    [leftBtn setBackgroundImage:[UIImage imageNamed:@"菜单"] forState:UIControlStateNormal];

//    leftBtn.backgroundColor = [UIColor redColor];
//    leftBtn.layer.masksToBounds = YES;
//    leftBtn.layer.cornerRadius = 25;

    UILabel *title  = [[UILabel alloc]initWithFrame:CGRectMake(0, 400, ATGetDeviceWidth, 20)];
    [mainView addSubview:title];
    title.text = @"除菌，消臭，防交叉感染";
    title.textAlignment = NSTextAlignmentCenter;
    title.font = [UIFont systemFontOfSize:16];
    
    UILabel *device  = [[UILabel alloc]initWithFrame:CGRectMake(0, 450, ATGetDeviceWidth, 20)];
    [mainView addSubview:device];
    device.text = @"My AIR MEDIC";
    device.textAlignment = NSTextAlignmentCenter;
    device.font = [UIFont systemFontOfSize:14];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-50, ATGetDeviceWidth, 50)];
    [self.view addSubview:btn];
//    btn.backgroundColor =  [UIColor colorWithRed:123/255.0 green:183/255.0 blue:191/255.0 alpha:1.0];
    [btn addTarget:self action:@selector(didAction:) forControlEvents:UIControlEventTouchUpInside];
    [btn setTitle:@"添加设备" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:18];
    btn.tag = 0;
    btn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];

    
}
-(void)didAction:(UIButton *)btn
{
    GSJSearchDeviceViewController *vc = [[GSJSearchDeviceViewController alloc]init];
    [self presentViewController:vc animated:YES completion:nil];

}
-(void)didMy
{
    NSLog(@"我的资料");
    //把最前面的视图控制器dismiss掉
//    UIViewController *parentVC = self.presentingViewController;
//    UIViewController *bottomVC;
//    while (parentVC) {
//        bottomVC = parentVC;
//        parentVC = parentVC.presentingViewController;
//    }
//    [bottomVC dismissViewControllerAnimated:NO completion:^{
        //dismiss后再切换根视图
    
        [UIApplication sharedApplication].delegate.window.rootViewController = [GSJMyViewController new];
//    }];
}
-(void)getLogin
{
    NSString *uuid = [[NSUserDefaults standardUserDefaults]valueForKey:@"uuid"];
    
    NSString *name =      [[NSUserDefaults standardUserDefaults]valueForKey:@"userPhoneName"];
    NSString *password =      [[NSUserDefaults standardUserDefaults]valueForKey:@"userPhonePassWord"];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    
    NSDictionary *dic=@{
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"passwd":password,
                        @"phone":name,
                        @"mac":uuid
                        };
    
    NSString *parameter =[NSString stringWithFormat:@"passwd=%@&mac=%@&phone=%@&appid=1288&motime=%@&sign=%@",password,uuid,name,[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/sso/login";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"])
        {
            
            [token whriteValue:response[@"data"][@"token"]];
            [[NSUserDefaults standardUserDefaults]setValue:response[@"data"][@"nickname"] forKey:@"name"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            if ([response[@"data"][@"dvccnt"] integerValue ] !=0) {
                [UIApplication sharedApplication].delegate.window.rootViewController = [GSJDeviceListViewController new];
            }
            
            //            if (response[@"data"]) {
            //                 GSJAddEquipmentViewController *vc = [[GSJAddEquipmentViewController alloc]init];
            
            //            }else
            //            {
            //                GSJDeviceListViewController *vc = [[GSJDeviceListViewController alloc]init];
            //                [self presentViewController:vc animated:YES completion:nil];
            //            }
        }
        
    } failBlock:^(NSError *error) {
    }];

}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
