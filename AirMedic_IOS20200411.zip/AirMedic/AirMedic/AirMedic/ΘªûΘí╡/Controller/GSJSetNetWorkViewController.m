//
//  GSJSearchDeviceViewController.m
//  AirMedic
//
//  Created by kaka on 2019/8/8.
//  Copyright © 2019 gsj. All rights reserved.
//

#import "GSJSetNetWorkViewController.h"
#import "GSJDeviceListViewController.h"
#import "Reachability.h"

@interface GSJSetNetWorkViewController ()<UITextFieldDelegate,EasyLinkFTCDelegate>
{
    Reachability *wifiReachability;
    EASYLINK *easylink_config;
    EasyLinkMode easylinkMode;
    NSData *targetSsid;
    NSMutableDictionary *deviceIPConfig;


}
@property (nonatomic,strong) UIView *headView;
@property (nonatomic,strong) UIView *middleView;
@property (nonatomic,strong) UITextField *passField;
@property (nonatomic,strong) UILabel *passLabel;
@property (nonatomic,strong) dispatch_source_t timer;
@property (nonatomic,strong) dispatch_source_t secondTimer;
@property (nonatomic,copy) NSString *mac;
@property (nonatomic,strong) UIButton *btn;
@property (nonatomic,assign) NSInteger gcdIdx;
@property (nonatomic,assign) NSInteger macIs;//1表示35秒没有获取到mac
@property (nonatomic,strong) NSDictionary *messageDic;
/*
 Notification method handler when app enter in forground
 @param the fired notification object
 */
- (void)appEnterInforground:(NSNotification*)notification;

/*
 Notification method handler when app enter in background
 @param the fired notification object
 */
- (void)appEnterInBackground:(NSNotification*)notification;

/*
 Notification method handler when status of wifi changes
 @param the fired notification object
 */
- (void)wifiStatusChanged:(NSNotification*)notification;

@end

@implementation GSJSetNetWorkViewController
-(UIView *)headView
{
    if (!_headView) {
        _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, 44+22+iPhoneX_SPACE_TOP)];
        [self.view addSubview:_headView];
        
    }
    return _headView;
}
-(UIView *)middleView
{
    if (!_middleView) {
        _middleView = [[UIView alloc]initWithFrame:CGRectMake(0, 150+iPhoneX_SPACE_TOP, ATGetDeviceWidth, 100)];
        [self.view addSubview:_middleView];
        _middleView.backgroundColor = rgba(153, 153, 153, 1);
        
    }
    return _middleView;
}
-(void)dealloc
{
    if (_timer) {
        dispatch_source_cancel(_timer);
        _timer = nil;
    }
    if (_secondTimer) {
        dispatch_source_cancel(_secondTimer);
        _secondTimer = nil;
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    [self geiMessage];
    self.macIs = 0;
    
    self.mac = @"";
    // wifi notification when changed.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(wifiStatusChanged:) name:kReachabilityChangedNotification object:nil];
    

    if( easylink_config == nil){
        easylink_config = [[EASYLINK alloc]initForDebug:YES WithDelegate:self];
    }
    deviceIPConfig = [[NSMutableDictionary alloc] initWithCapacity:5];
    targetSsid = [NSData data];
    easylinkMode = EASYLINK_AWS;
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appEnterInforground:) name:UIApplicationDidBecomeActiveNotification object:nil];

    
    self.view.backgroundColor =[UIColor colorWithRed:249/255.0 green:247/255.0 blue:245/255.0 alpha:1.0];
    
    UILabel *headLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,15+22+iPhoneX_SPACE_TOP,ATGetDeviceWidth,19)];
    [self.headView addSubview:headLabel];
    NSMutableAttributedString *headString = [[NSMutableAttributedString alloc] initWithString:@"添加设备" attributes:@{NSFontAttributeName: [UIFont fontWithName:@"PingFang-SC-Medium" size: 16],NSForegroundColorAttributeName: [UIColor blackColor]}];
    headLabel.attributedText = headString;
    headLabel.textAlignment = NSTextAlignmentCenter;
    
    
    UIButton *leftBtn  = [[UIButton alloc]initWithFrame:CGRectMake(6,34+iPhoneX_SPACE_TOP,23,23)];
    [self.view addSubview:leftBtn];
    [leftBtn setImage:[UIImage imageNamed:@"icon-back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(didMy) forControlEvents:UIControlEventTouchUpInside];
    
    
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,100+iPhoneX_SPACE_TOP,ATGetDeviceWidth,19)];
    [self.view addSubview:titleLabel];
    NSMutableAttributedString *titleString = [[NSMutableAttributedString alloc] initWithString:@"请输入以下网络的密码" attributes:@{NSFontAttributeName: [UIFont fontWithName:@"PingFang-SC-Medium" size: 16],NSForegroundColorAttributeName: [UIColor blackColor]}];
    titleLabel.attributedText = titleString;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    _passLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,130+iPhoneX_SPACE_TOP,ATGetDeviceWidth,14)];
    [self.view addSubview:_passLabel];
//    NSMutableAttributedString *passString = [[NSMutableAttributedString alloc] initWithString:@"TP_Link_6078" attributes:@{NSFontAttributeName: [UIFont fontWithName:@"PingFang-SC-Medium" size: 14],NSForegroundColorAttributeName: [UIColor blackColor]}];
    _passLabel.text = @"";
    _passLabel.textAlignment = NSTextAlignmentCenter;
    
    UIView *inputView = [[UIView alloc]initWithFrame:CGRectMake(30, 160+iPhoneX_SPACE_TOP, ATGetDeviceWidth-60, 50)];
    [self.view addSubview:inputView];
    inputView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    inputView.layer.borderWidth = 1;
    
    _passField = [[UITextField alloc]initWithFrame:CGRectMake(10, 0, ATGetDeviceWidth-60-50, 50)];
    [inputView addSubview:_passField];
    _passField.placeholder = @"密码";
    _passField.secureTextEntry = YES;
    _passField.delegate = self;
    
    
    UIButton *keyBtn =[[UIButton alloc]initWithFrame:CGRectMake(ATGetDeviceWidth-60-40, 15, 35, 20)];
    [inputView addSubview:keyBtn];
    [keyBtn addTarget:self action:@selector(didShowAction:) forControlEvents:UIControlEventTouchUpInside];
    [keyBtn setImage:[UIImage imageNamed:@"icon_bukejian"] forState:UIControlStateNormal];
    [keyBtn setImage:[UIImage imageNamed:@"icon_kejian"] forState:UIControlStateSelected];
    
    
   

    
    
    UIImageView *headImage = [[UIImageView alloc]initWithFrame:CGRectMake((ATGetDeviceWidth-375)/2, 280+iPhoneX_SPACE_TOP, 125*3, 330)];
    [self.view addSubview:headImage];
    headImage.image = [UIImage imageNamed:@"连接无线 机器俯瞰图 有阴影图层 14"];
    
    _btn= [[UIButton alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-50, ATGetDeviceWidth, 50)];
    [self.view addSubview:_btn];
//    btn.backgroundColor =  [UIColor colorWithRed:152/255.0 green:203/255.0 blue:214/255.0 alpha:1.0];
    [_btn addTarget:self action:@selector(didNext) forControlEvents:UIControlEventTouchUpInside];
    [_btn setTitle:@"配网" forState:UIControlStateNormal];
    [_btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _btn.titleLabel.font = [UIFont systemFontOfSize:14];
    _btn.tag = 0;
    _btn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];

    
    wifiReachability = [Reachability reachabilityForInternetConnection];  //监测Wi-Fi连接状态
    [wifiReachability startNotifier];
    
    NetworkStatus netStatus = [wifiReachability currentReachabilityStatus];
    if ( netStatus != NotReachable ) {
         _passLabel.text = [EASYLINK ssidForConnectedNetwork];
        targetSsid = [EASYLINK ssidDataForConnectedNetwork];
    }
    
}
#pragma maek -点击事件-
-(void)didAction:(UIButton *)btn
{
//    GSJSearchDeviceViewController *vc = [[GSJSearchDeviceViewController alloc]init];
//    [self presentViewController:vc animated:YES completion:nil];
    
}
-(void)didMy
{
    [easylink_config stopTransmitting];
    [easylink_config unInit];
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)didNext
{
    NSLog(@"下一步");
   
    
    NetworkStatus netStatus = [wifiReachability currentReachabilityStatus];
    if ( netStatus == NotReachable) {// No activity if no wifi
        [MBProgressHUD showMessage:@"请检查您的网络"];
        return;
    }
      if ([_passLabel.text isEqualToString:@""])
    {
        [MBProgressHUD showMessage:@"请连接wifi"];
        return;
    }
     if([_passField.text isEqualToString:@""]) {
        [MBProgressHUD showMessage:@"请输入密码"];
        return;
    }
    [self startTransmitting:easylinkMode];
    NSInteger secTime = [self.messageDic[@"netconfigtime"] integerValue];

    [MBProgressHUD showIconMessage:@"loading" ToView:self.view  RemainTime:secTime];

    NSInteger sec = [self.messageDic[@"nomacstart"] integerValue];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if ([self.mac isEqualToString:@""]) {
            NSLog(@"无MAC情况开始35S");
            self.macIs = 1;
            [self timeRetrun];
        }
    });
    

//    [_btn removeTarget:self action:NULL forControlEvents:UIControlEventTouchUpInside];
//    [_btn addTarget:self action:@selector(didCancle) forControlEvents:UIControlEventTouchUpInside];
//    [_btn setTitle:@"取消配网" forState:UIControlStateNormal];
//    _btn.backgroundColor = [UIColor redColor];
    //把最前面的视图控制器dismiss掉
//    UIViewController *parentVC = self.presentingViewController;
//    UIViewController *bottomVC;
//    while (parentVC) {
//        bottomVC = parentVC;
//        parentVC = parentVC.presentingViewController;
//    }
//    [bottomVC dismissViewControllerAnimated:NO completion:^{
//        //dismiss后再切换根视图
//        [UIApplication sharedApplication].delegate.window.rootViewController = [GSJDeviceListViewController new];
//    }];
    
}
-(void)timeRetrun
{
    //设置时间间隔
    self.gcdIdx = 0;
    NSInteger sec = [self.messageDic[@"pollint"] integerValue];
    NSInteger gcdIndex = [self.messageDic[@"netconfigtime"] integerValue]-[self.messageDic[@"nomacstart"] integerValue];
    NSInteger index = gcdIndex/sec+1;
    NSTimeInterval period = sec;
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    _secondTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    dispatch_source_set_timer(_secondTimer, dispatch_walltime(NULL, 0), period * NSEC_PER_SEC, 0);
    // 事件回调
    dispatch_source_set_event_handler(_secondTimer, ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            self.gcdIdx++;
            
            if(self.gcdIdx == index) {
                // 终止定时器
                if (self.secondTimer) {
                    dispatch_source_cancel(self.secondTimer);
                }
                
                [MBProgressHUD showMessage:@"配网失败"];
                
                //                [self->_btn removeTarget:self action:NULL forControlEvents:UIControlEventTouchUpInside];
                //                self->_btn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];
                [self->easylink_config stopTransmitting];
                //                [self->_btn addTarget:self action:@selector(didNext) forControlEvents:UIControlEventTouchUpInside];
                //                [self->_btn setTitle:@"配网" forState:UIControlStateNormal];
                return ;
            }
            NSLog(@"Count");
            
            //网络请求 doSomeThing...
            [self findDevice:self.type mac:@""];
            
        });
    });
    
    // 开启定时器
    dispatch_resume(_secondTimer);
}
-(void)didCancle
{
    NSLog(@"取消配网");
    [_btn removeTarget:self action:NULL forControlEvents:UIControlEventTouchUpInside];

    _btn.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"窄背景"]];

    [self->easylink_config stopTransmitting];
    [_btn addTarget:self action:@selector(didNext) forControlEvents:UIControlEventTouchUpInside];
    [_btn setTitle:@"配网" forState:UIControlStateNormal];
    
    if (self.timer) {
        dispatch_source_cancel(self.timer);

    }
    if (self.secondTimer) {
        dispatch_source_cancel(self.secondTimer);
    }
    
}
-(void)didShowAction:(UIButton *)btn
{
    btn.selected =!btn.selected;
    if (btn.selected) {
        _passField.secureTextEntry = NO;
    }else
    {
        _passField.secureTextEntry = YES;
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.view endEditing:YES];
    return YES;
}


- (void)appEnterInforground:(NSNotification*)notification{
    NetworkStatus netStatus = [wifiReachability currentReachabilityStatus];
    
    if ( netStatus != NotReachable && ![[EASYLINK ssidForConnectedNetwork] hasPrefix:@"EasyLink_"] && easylink_config.softAPSending == false) {
        _passLabel.text = [EASYLINK ssidForConnectedNetwork];
        targetSsid = [EASYLINK ssidDataForConnectedNetwork];
//        ipAddress.text = @"Automatic";
//        ssidField.userInteractionEnabled = NO;
//
//        NSString *password = [apInforRecord objectForKey:ssidField.text];
//        if(password == nil) password = @"";
//        [passwordField setText: password];
//
//        [deviceIPConfig setObject:@YES forKey:@"DHCP"];
//        [deviceIPConfig setObject:[EASYLINK getIPAddress] forKey:@"IP"];
//        [deviceIPConfig setObject:[EASYLINK getNetMask] forKey:@"NetMask"];
//        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"GateWay"];
//        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"DnsServer"];
    }
}
- (void)wifiStatusChanged:(NSNotification*)notification{
    NetworkStatus netStatus = [wifiReachability currentReachabilityStatus];
    
    /* iOS has connect to a wireless router */
    if ( netStatus != NotReachable && ![[EASYLINK ssidForConnectedNetwork] hasPrefix:@"EasyLink_"] && easylink_config.softAPSending == false) {
        _passLabel.text = [EASYLINK ssidForConnectedNetwork];

//        ssidField.text = [EASYLINK ssidForConnectedNetwork];
        targetSsid = [EASYLINK ssidDataForConnectedNetwork];
//        NSString *password = [apInforRecord objectForKey:ssidField.text];
//        if(password == nil) password = @"";
//        [passwordField setText:password];
//
//        [deviceIPConfig setObject:@YES forKey:@"DHCP"];
//        [deviceIPConfig setObject:[EASYLINK getIPAddress] forKey:@"IP"];
//        [deviceIPConfig setObject:[EASYLINK getNetMask] forKey:@"NetMask"];
//        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"GateWay"];
//        [deviceIPConfig setObject:[EASYLINK getGatewayAddress] forKey:@"DnsServer"];
    }
}
- (void)startTransmitting: (EasyLinkMode)mode {
    NSMutableDictionary *wlanConfig = [NSMutableDictionary dictionaryWithCapacity:20];
    
    if([targetSsid length] > 0) [wlanConfig setObject:targetSsid forKey:KEY_SSID];
    else [wlanConfig setObject:[_passLabel.text dataUsingEncoding:NSUTF8StringEncoding] forKey:KEY_SSID];
    if([_passField.text length] > 0) [wlanConfig setObject:_passField.text forKey:KEY_PASSWORD];
    [wlanConfig setObject:[NSNumber numberWithBool:[[deviceIPConfig objectForKey:@"DHCP"] boolValue]] forKey:KEY_DHCP];
    
    if([[deviceIPConfig objectForKey:@"IP"] length] > 0)  [wlanConfig setObject:[deviceIPConfig objectForKey:@"IP"] forKey:KEY_IP];
    if([[deviceIPConfig objectForKey:@"NetMask"] length] > 0)  [wlanConfig setObject:[deviceIPConfig objectForKey:@"NetMask"] forKey:KEY_NETMASK];
    if([[deviceIPConfig objectForKey:@"GateWay"] length] > 0)  [wlanConfig setObject:[deviceIPConfig objectForKey:@"GateWay"] forKey:KEY_GATEWAY];
    if([[deviceIPConfig objectForKey:@"DnsServer"] length] > 0)  [wlanConfig setObject:[deviceIPConfig objectForKey:@"DnsServer"] forKey:KEY_DNS1];
    
//    NSString *userInfo = [userInfoField.text length]? userInfoField.text : @"";
    NSString *userInfo =  @"";

    const char *temp = [userInfo cStringUsingEncoding:NSUTF8StringEncoding];
    [easylink_config prepareEasyLink:wlanConfig info:[NSData dataWithBytes:temp length:strlen(temp)] mode:mode ];
    [self sendAction];
    targetSsid = [wlanConfig objectForKey:KEY_SSID];
    
//    [MBProgressHUD showLoadToView:self.view];
}
-(void) sendAction
{
    [easylink_config transmitSettings];
}
#pragma mark -发现接口回调-
- (void)onFound:(NSNumber *)client withName:(NSString *)name mataData: (NSDictionary *)mataDataDict
{
    
    NSLog(@"Found new device using bonjour==================");
    NSLog(@"%@======%@-----%@",client,name,mataDataDict);
//    self.mac =[NSString stringWithFormat:@"%@",mataDataDict[@"MAC"]];
    NSIndexPath* indexPath;
    NSMutableDictionary *foundModule = [NSMutableDictionary dictionaryWithDictionary:mataDataDict];
    NSMutableDictionary *updateSettings;
    NSData *tempData;
    NSUInteger index = 0xFF;
    
    [foundModule setValue:name forKey:@"N"];
    [foundModule setObject:@NO forKey:@"FTC"];
    
    tempData = [mataDataDict objectForKey:@"FW"];
    if( tempData != nil ) [foundModule setValue:[[NSString alloc] initWithData:tempData encoding:NSUTF8StringEncoding] forKey:@"FW"];
    
    tempData = [mataDataDict objectForKey:@"HD"];
    if( tempData != nil ) [foundModule setValue:[[NSString alloc] initWithData:tempData encoding:NSUTF8StringEncoding] forKey:@"HD"];
    
    tempData = [mataDataDict objectForKey:@"PO"];
    if( tempData != nil ) [foundModule setValue:[[NSString alloc] initWithData:tempData encoding:NSUTF8StringEncoding] forKey:@"PO"];
    
    tempData = [mataDataDict objectForKey:@"RF"];
    if( tempData != nil ) [foundModule setValue:[[NSString alloc] initWithData:tempData encoding:NSUTF8StringEncoding] forKey:@"RF"];
    
    tempData = [mataDataDict objectForKey:@"MAC"];
    if( tempData != nil ) [foundModule setValue:[[NSString alloc] initWithData:tempData encoding:NSUTF8StringEncoding] forKey:@"MAC"];
    
    self.mac = [[NSString alloc] initWithData:[mataDataDict objectForKey:@"MAC"] encoding:NSUTF8StringEncoding];
    NSLog(@"mac==============%@",self.mac);
    [foundModule setValue:client forKey:@"client"];
    updateSettings = [NSMutableDictionary dictionaryWithCapacity:10];
    [foundModule setValue:updateSettings forKey:@"update"];
    
    
    if (![self.mac isEqualToString:@""])
    {
        if (self.macIs !=1) {
             NSLog(@"有MAC情况开始");
            [self timeRetrun];
        }
    }
    /* Device already existed */
//    for( NSDictionary *object in self.foundModules){
//        if ([[object objectForKey:@"N"] isEqualToString:[foundModule objectForKey:@"N"]] ){
//            index = [self.foundModules indexOfObject:object];
//            [self.foundModules replaceObjectAtIndex:index withObject:object];
//            indexPath = [NSIndexPath indexPathForRow:index inSection:0];
//            [foundModuleTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]
//                                        withRowAnimation:UITableViewRowAnimationLeft];
//        }
//    }
    
    /* Find a new device */
//    if (index == 0xFF){
//        [foundModule setObject: [NSNumber numberWithInteger:arc4random()] forKey:@"tag"];
//        [self.foundModules addObject:foundModule];
//        indexPath = [NSIndexPath indexPathForRow:[self.foundModules indexOfObject:foundModule] inSection:0];
//
//        [foundModuleTableView insertRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]
//                                    withRowAnimation:UITableViewRowAnimationRight];
//    }
    
    
    /*Correct AP info input, save to file*/
//    if([[apInforRecord objectForKey:_passLabel.text] isEqualToString:_passField.text] == NO){
//        [apInforRecord setObject:_passField.text forKey:_passLabel.text];
//        [apInforRecord writeToFile:apInforRecordFile atomically:YES];
//    }
    
//    [easyLinkSendingView close];
//    [easyLinkUAPSendingView close];
//    [self updateDeviceCountLable];
    //每隔一分钟执行一次打印
    // GCD定时器
//    static dispatch_source_t _timer;
    //设置时间间隔
//    NSTimeInterval period = 5.0f;
//    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
//    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
//    dispatch_source_set_timer(_timer, dispatch_walltime(NULL, 0), period * NSEC_PER_SEC, 0);
//    // 事件回调
//    dispatch_source_set_event_handler(_timer, ^{
//        dispatch_async(dispatch_get_main_queue(), ^{
//            NSLog(@"Count");
//            //网络请求 doSomeThing...
//            [self findDevice:self.type mac:@""];
//
//        });
//    });
//
//    // 开启定时器
//    dispatch_resume(_timer);
    
    // 关闭定时器
    // dispatch_source_cancel(_timer);

//    if(otaAlertView != nil){
//        [otaAlertView close];
//        otaAlertView = nil;
//    }
}


#pragma mark-设备发现接口（配网指令发出5秒后轮询，直至发现或者超时)-
-(void)findDevice:(NSString *)type mac:(NSString *)mac
{
    
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    if ([self.mac isEqualToString:@""]) {
        NSLog(@"无mac的情况轮休");
        NSDictionary *dic=@{
                            @"type":type,
                            @"appid":@"1288",
                            @"motime":[[PruManerge sharePruManerge]getTime],
                            @"token":[token getValue]
                            };
        NSString *parameter =[NSString stringWithFormat:@"type=%@&token=%@&appid=1288&motime=%@&sign=%@",type,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
        
        
        NSString *url = @"http://smart.airmedic.cn:9088/arm/api/dvc/findDevice";
        
        
        [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
            
        } successBlock:^(id response) {
            
            NSLog(@"%@",response);
            if ([response[@"code"] isEqualToString:@"10000"]) {
                //            [MBProgressHUD hideHUDForView:self.view];
                
                [[NSUserDefaults standardUserDefaults]setObject:response[@"did"] forKey:@"clientid"];
                if (self.timer) {
                    dispatch_source_cancel(self.timer);
                    self.timer =nil;
                }
                if (self.secondTimer) {
                    dispatch_source_cancel(self.secondTimer);
                    self.secondTimer =nil;
                }
                [self->easylink_config stopTransmitting];
                [UIApplication sharedApplication].delegate.window.rootViewController = [GSJDeviceListViewController new];
            }else
            {
            }
            
        } failBlock:^(NSError *error) {
            
        }];
    }else
    {
        NSLog(@"有mac的情况轮休");
        NSDictionary *dic=@{
                            @"type":type,
                            @"mac":self.mac,
                            @"appid":@"1288",
                            @"motime":[[PruManerge sharePruManerge]getTime],
                            @"token":[token getValue]
                            };
        NSString *parameter =[NSString stringWithFormat:@"mac=%@&type=%@&token=%@&appid=1288&motime=%@&sign=%@",self.mac,type,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
        
        
        NSString *url = @"http://smart.airmedic.cn:9088/arm/api/dvc/findDevice";
        
        
        [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
            
        } successBlock:^(id response) {
            
            NSLog(@"%@",response);
            if ([response[@"code"] isEqualToString:@"10000"]) {
                            [MBProgressHUD hideHUDForView:self.view];

                [[NSUserDefaults standardUserDefaults]setObject:response[@"did"] forKey:@"clientid"];
                if (self.timer) {
                    dispatch_source_cancel(self.timer);
                    self.timer = nil;
                }
                if (self.secondTimer) {
                    dispatch_source_cancel(self.secondTimer);
                    self.secondTimer =nil;
                }
                [self->easylink_config stopTransmitting];
                
                [MBProgressHUD showMessage:@"配网成功"];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [UIApplication sharedApplication].delegate.window.rootViewController = [GSJDeviceListViewController new];
                });


            }else
            {
            }
            
        } failBlock:^(NSError *error) {
            
        }];
    }
    
}
-(void)geiMessage
{
    
    NSDictionary *dic=@{
                        
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"token":[token getValue]
                        };
    NSString *parameter =[NSString stringWithFormat:@"token=%@&appid=1288&motime=%@&sign=%@",[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    
    
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/dvc/netconfig";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            //            [MBProgressHUD hideHUDForView:self.view];
            self.messageDic = response[@"data"];
            
        }else
        {
        }
        
    } failBlock:^(NSError *error) {
        
    }];
}
@end
