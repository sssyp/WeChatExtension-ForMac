//
//  GSJListDetailViewController.m
//  AirMedic
//
//  Created by gsj on 2019/8/11.
//  Copyright © 2019年 gsj. All rights reserved.
//

#import "GSJListDetailViewController.h"
#import "ChildViewController.h"
#import "MQTTClient.h"
#import "MQTTSessionManager.h"
#define MQTTPORT        @"8785"
#define MQTTCLIENT      @"MQTTClient";

//#define MQTTHOST @"ssl://qq.airmedic.cn:8785" // 测试库地址
#define MQTTHOST @"qq.airmedic.cn" // 测试库地址


@interface GSJListDetailViewController ()<FSPageContentViewDelegate,FSSegmentTitleViewDelegate,MQTTSessionDelegate,MQTTSessionManagerDelegate>
@property (nonatomic, strong) FSPageContentView *pageContentView;
@property (nonatomic, strong) FSSegmentTitleView *titleView;

@property (nonatomic, strong) MQTTSession       *mySession;
@property (nonatomic,strong) MQTTCFSocketTransport  *transport;
@property (nonatomic,strong) NSMutableArray           *firstDictionary;
@property (nonatomic,strong) MQTTSessionManager  *mySessionManager;
@property (nonatomic,strong) NSDictionary *mainDic;



@end

@implementation GSJListDetailViewController
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    NSString *key =[NSString stringWithFormat:@"smt/%@/upd_status",_dic[@"did"]];
    [self.mySessionManager.session unsubscribeTopic:key unsubscribeHandler:^(NSError *error) {
        NSLog(@"取消订阅成功");
    }];
     [self.mySessionManager disconnect];
}
//- (void)viewWillDisappear:(BOOL)animated{
//    [super viewWillDisappear:animated];
    //主动和服务端断开
//    [self.mySession disconnect];
    
//}
- (MQTTCFSocketTransport *)transport{
    
    if (!_transport) {
        _transport = [[MQTTCFSocketTransport alloc] init];
        _transport.host = MQTTHOST; // 设置MQTT服务器的地址
        _transport.tls = YES;
        _transport.port = [MQTTPORT intValue]; // 设置MQTT服务器的端口
    }
    return _transport;
}
#pragma mark - 绑定
- (void)bindWithUserName:(NSString *)username password:(NSString *)password cliendId:(NSString *)cliendId isSSL:(BOOL)isSSL port:(NSInteger)port host:(NSString *)host  keepalive:(NSInteger)keepalive{
    self.mySessionManager = [[MQTTSessionManager alloc]initWithPersistence:YES maxWindowSize:1024 maxMessages:1024 maxSize:1024];
//    self.mySessionManager = [[MQTTSessionManager alloc]init];

    self.mySessionManager.delegate = self;

    [self.mySessionManager connectTo:host
                                port:port
                                 tls:YES
                           keepalive:keepalive
                               clean:YES
                                auth:YES
                                user:username
                                pass:password
                                will:NO
                           willTopic:nil
                             willMsg:nil
                             willQos:MQTTQosLevelAtMostOnce
                      willRetainFlag:NO
                        withClientId:cliendId
                      securityPolicy:[self customSecurityPolicy]
                        certificates:nil
                       protocolLevel:4];


//    self.isDiscontent = NO;
    NSString *key =[NSString stringWithFormat:@"smt/%@/upd_status",_dic[@"did"]];
    self.mySessionManager.subscriptions =@{key:[NSNumber numberWithInteger:0]};
    
}
- (MQTTSSLSecurityPolicy *)customSecurityPolicy
{
    MQTTSSLSecurityPolicy *securityPolicy = [MQTTSSLSecurityPolicy policyWithPinningMode:MQTTSSLPinningModeNone];
    
    securityPolicy.allowInvalidCertificates = YES;
    securityPolicy.validatesCertificateChain = YES;
    securityPolicy.validatesDomainName = NO;
    return securityPolicy;
}
#pragma mark - 订阅
- (void)subscribeTopic:(NSString *)topic{
    
    NSLog(@"当前需要订阅-------- topic = %@",topic);
}
#pragma mark ---- 状态
- (void)sessionManager:(MQTTSessionManager *)sessionManager didChangeState:(MQTTSessionManagerState)newState {
    
    switch (newState) {
        case MQTTSessionManagerStateConnected:
            NSLog(@"eventCode -- 连接成功");
            break;
        case MQTTSessionManagerStateConnecting:
            NSLog(@"eventCode -- 连接中");
            
            break;
        case MQTTSessionManagerStateClosed:
            NSLog(@"eventCode -- 连接被关闭");
            break;
        case MQTTSessionManagerStateError:
            NSLog(@"eventCode -- 连接错误");
            break;
        case MQTTSessionManagerStateClosing:
            NSLog(@"eventCode -- 关闭中");
            
            break;
        case MQTTSessionManagerStateStarting:
            NSLog(@"eventCode -- 连接开始");
            
            break;
            
        default:
            break;
    }
}

- (NSString *)lowerMD5:(NSString *)inPutText
{
    //传入参数,转化成char
    const char *cStr = [inPutText UTF8String];
    //开辟一个16字节的空间
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    /*
     extern unsigned char * CC_MD5(const void *data, CC_LONG len, unsigned char *md)官方封装好的加密方法
     把str字符串转换成了32位的16进制数列（这个过程不可逆转） 存储到了md这个空间中
     */
    CC_MD5(cStr, (CC_LONG)strlen(cStr), result);
    
    return [[NSString stringWithFormat:@"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
             result[0], result[1], result[2], result[3],
             result[4], result[5], result[6], result[7],
             result[8], result[9], result[10], result[11],
             result[12], result[13], result[14], result[15]
             ] lowercaseString];  //大小写注意
}
#pragma mark ---  初始化MQTT
- (void) initMQTTSocket:(NSString *)userName salt:(NSString *)salt port:(NSInteger )port host:(NSString *)host keepalive:(NSInteger)keepalive
{

    NSString *md5 = [NSString stringWithFormat:@"clientid=%@&%@",userName,salt];
    NSString *password =  [[[DivEncode sharePruManerge]getPrukeyMD5:md5] lowercaseString];
    NSLog(@"拿到的密码小写：%@",password);
    [self bindWithUserName:userName password:password cliendId:userName isSSL:YES port:port host:host keepalive:keepalive];
    
}

#pragma mark ----  接收消息
-(void)handleMessage:(NSData *)data onTopic:(NSString *)topic retained:(BOOL)retained
{
    NSString *result = [[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding];
    NSDictionary *jsonDic = [self dictionaryWithJsonString:result];
    
    NSLog(@"收到的订阅消息=====%@",jsonDic);
//    [[NSNotificationCenter defaultCenter]postNotificationName:@"receiveMessage" object:jsonDic];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"receiveMessage" object:nil userInfo:jsonDic];
}

-(NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString{
    if (jsonString == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}
/* 字典转json 字符串 */
-(NSString*)dictionaryToJson:(NSDictionary *)dic
{
    
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:nil error:&parseError];
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
}

#pragma mark -  断线重连-
-(void)reConnect
{
    [self getCid];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reConnect) name:@"reConect" object:nil];
    
    [self getCid];
   NSDictionary *dic = [[NSUserDefaults standardUserDefaults]valueForKey:@"location"];
    
    if ([dic isKindOfClass:[NSNull class]] || [dic isEqual:[NSNull null]]) {
        [self getDvcinfo:@{}];
    }else
    {
        if ([dic  isEqual:@{}]) {
            [self getDvcinfo:@{}];
        }else
        {
        [self getWeather:dic];
        }
    }
//    if (![dic isKindOfClass:[NSNull class]] && ![dic isEqual:[NSNull null]]) {
//        [self getWeather:dic];
//    }else
//    {
//        [self getDvcinfo:@{}];
//    }

}

#pragma mark-获取天气情况-
-(void)getWeather:(NSDictionary *)diccc
{
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//  NSString *cityY = [diccc[@"city"] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    

    NSDictionary *dic=@{
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"city":diccc[@"city"],
                        @"appid":@"1288",
                        @"token":[token getValue],
                        @"area":diccc[@"location"]
                        };
    NSString *parameter =[NSString stringWithFormat:@"area=%@&city=%@&token=%@&appid=1288&motime=%@&sign=%@",diccc[@"location"],diccc[@"city"],[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];


    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/common/weather";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"获取天气=====%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            
            [self getDvcinfo:response[@"data"]];
        }else
        {
            [self getDvcinfo:@{}];
        }
        
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
}
#pragma mark -获取id链接mqtt-
-(void)getCid
{
    NSString *uuid = [[NSUserDefaults standardUserDefaults]valueForKey:@"uuid"];

//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    NSDictionary *dic=@{
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"mac":uuid
                        };
    NSString *parameter =[NSString stringWithFormat:@"mac=%@&motime=%@&sign=%@",uuid,[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];

    NSString *url = @"http://smart.airmedic.cn:8180/qq/linx/config";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        
        NSLog(@"获取mqttcid====%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            self.mainDic =response[@"data"];
            NSInteger port = [self.mainDic[@"sslport"] integerValue];
            NSLog(@"port============%ld",port);
            NSString *host =self.mainDic[@"server"];
            NSInteger keepalive = [self.mainDic[@"keepalive"] integerValue];
            [self initMQTTSocket:response[@"data"][@"clientid"] salt:response[@"data"][@"salt"] port:port host:host keepalive:keepalive];
        }
        
        
    } failBlock:^(NSError *error) {
        
    }];
}
#pragma mark-获取设备面板情况-
-(void)getDvcinfo:(NSDictionary *)weatherDic
{
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    
    NSDictionary *dic=@{
                         @"did":self.dic[@"did"],
                         @"appid":@"1288",
                         @"motime":[[PruManerge sharePruManerge]getTime],
                         @"token":[token getValue]
                         };
    NSString *parameter =[NSString stringWithFormat:@"did=%@&token=%@&appid=1288&motime=%@&sign=%@",self.dic[@"did"],[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dic]];
    

    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/dvc/dvcinfo";
    
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:dic parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"设备面板====%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            
            self.automaticallyAdjustsScrollViewInsets = NO;
            self.view.backgroundColor = [UIColor whiteColor];
            self.title = @"pageContentView";
            self.titleView = [[FSSegmentTitleView alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-100, CGRectGetWidth(self.view.bounds), 100) titles:@[@"液量",@"风力",@"开/关",@"定时",@"氛围灯"] delegate:self indicatorType:FSIndicatorTypeEqualTitle];
            self.titleView.titleSelectFont = [UIFont systemFontOfSize:10];
            self.titleView.selectIndex = 2;
            self.titleView.isSelect  = 2;

            [self.view addSubview:self.titleView];
            
            NSMutableArray *childVCs = [[NSMutableArray alloc]init];
            for (NSString *title in @[@"液量",@"风力",@"开/关",@"定时",@"氛围灯"]) {
                
                ChildViewController *vc = [[ChildViewController alloc]init];
                vc.titleStr = title;
                vc.weatherDic = weatherDic;
                vc.controlDic = self.dic;
                vc.deviceDic = response[@"data"];
                if ([self.oneKey isEqualToString:@"2"]) {
                    vc.oneKey = self.oneKey;
                }
                [childVCs addObject:vc];
            }
            self.pageContentView = [[FSPageContentView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, ATGetDeviceHeight-100) childVCs:childVCs parentVC:self delegate:self];
            self.pageContentView.contentViewCurrentIndex = 2;
            //    self.pageContentView.contentViewCanScroll = NO;//设置滑动属性
            [self.view addSubview:self.pageContentView];
        }else
        {
            self.automaticallyAdjustsScrollViewInsets = NO;
            self.view.backgroundColor = [UIColor whiteColor];
            self.title = @"pageContentView";
            self.titleView = [[FSSegmentTitleView alloc]initWithFrame:CGRectMake(0, ATGetDeviceHeight-100, CGRectGetWidth(self.view.bounds), 100) titles:@[@"液量",@"风力",@"开/关",@"定时",@"氛围灯"] delegate:self indicatorType:FSIndicatorTypeEqualTitle];
            self.titleView.titleSelectFont = [UIFont systemFontOfSize:10];
            self.titleView.selectIndex = 2;
            self.titleView.isSelect  = 2;
            [self.view addSubview:self.titleView];
            
            NSMutableArray *childVCs = [[NSMutableArray alloc]init];
            for (NSString *title in @[@"液量",@"风力",@"开/关",@"定时",@"氛围灯"]) {
                
                ChildViewController *vc = [[ChildViewController alloc]init];
                vc.titleStr = title;
                vc.weatherDic = weatherDic;
                vc.controlDic = self.dic;
                vc.deviceDic = @{};
                if ([self.oneKey isEqualToString:@"2"]) {
                    vc.oneKey = self.oneKey;
                }
                [childVCs addObject:vc];
            }
            self.pageContentView = [[FSPageContentView alloc]initWithFrame:CGRectMake(0, 0, ATGetDeviceWidth, ATGetDeviceHeight-100) childVCs:childVCs parentVC:self delegate:self];
            self.pageContentView.contentViewCurrentIndex = 2;
            //    self.pageContentView.contentViewCanScroll = NO;//设置滑动属性
            [self.view addSubview:self.pageContentView];
        }
        
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
}

#pragma mark -delegate-
- (void)FSSegmentTitleView:(FSSegmentTitleView *)titleView startIndex:(NSInteger)startIndex endIndex:(NSInteger)endIndex
{
    self.pageContentView.contentViewCurrentIndex = endIndex;
    self.title = @[@"液量",@"风力",@"开/关",@"定时",@"氛围灯"][endIndex];
}
- (void)FSSegmentTitleOpen:(NSInteger)open
{
    if (open == 0) {
        [self getControl:@"0" num:@"0"];
        
    }else
    {
        [self getControl:@"1" num:@"0"];

    }
}
#pragma mark -开关-
-(void)getControl:(NSString *)level num:(NSString *)num
{
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //    NSString *md5 = @"interlnx&aY4N!bAAds";
//    NSString *md5 = [NSString stringWithFormat:@"%@%@%@",[[PruManerge sharePruManerge]getTime],@"1288",@"interlnx&aY4N!bAAds"];
    NSDictionary *dic = @{
                          num:[NSNumber numberWithInteger:[level integerValue]]
                          };
    NSString *cmd = [self dictionaryToJson:dic];
    
    
    NSDictionary *dicc=@{
                         @"did":self.dic[@"did"],
                         @"cmd":cmd,
                        @"appid":@"1288",
                        @"motime":[[PruManerge sharePruManerge]getTime],
                        @"token":[token getValue]
                        };
    NSString *parameter =[NSString stringWithFormat:@"did=%@&cmd=%@&token=%@&appid=1288&motime=%@&sign=%@",self.dic[@"did"],cmd,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:dicc]];
    
    //    NSDictionary *dic =@{
    //                         //                         @"smstype":@"REG",
    //                         //                         @"phone":_phoneField.text
    //                         };
    NSString *url = @"http://smart.airmedic.cn:9088/arm/api/cmd/control";
    if ([self.oneKey isEqualToString:@"2"]) {
        url = @"http://smart.airmedic.cn:9088/arm/api/cmd/onekey";
        NSDictionary *diccc=@{
                             @"cmd":cmd,
                             @"appid":@"1288",
                             @"motime":[[PruManerge sharePruManerge]getTime],
                             @"token":[token getValue]
                             };
        parameter =[NSString stringWithFormat:@"cmd=%@&token=%@&appid=1288&motime=%@&sign=%@",cmd,[token getValue],[[PruManerge sharePruManerge]getTime],[[DivEncode sharePruManerge] md5Codesign:diccc]];
    }
    
    [XDNetworking postWithUrl:url refreshRequest:NO cache:NO params:@{} parameter:parameter progressBlock:^(int64_t bytesRead, int64_t totalBytes) {
        
    } successBlock:^(id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"%@",response);
        if ([response[@"code"] isEqualToString:@"10000"]) {
            if ([level isEqualToString:@"1"]) {
                [MBProgressHUD showMessage:@"打开设备"];

            }else
            {
                [MBProgressHUD showMessage:@"关闭设备"];

            }
        }else
        {
            [MBProgressHUD showMessage:response[@"msg"]];

        }
        
        
    } failBlock:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
}

- (void)FSContenViewDidEndDecelerating:(FSPageContentView *)contentView startIndex:(NSInteger)startIndex endIndex:(NSInteger)endIndex
{
    self.titleView.selectIndex = endIndex;
    self.title = @[@"液量",@"风力",@"开/关",@"定时",@"氛围灯"][endIndex];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
