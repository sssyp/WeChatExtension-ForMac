//
//  ChildViewController.h
//  FSScrollContentViewDemo
//
//  Created by 冯顺 on 2017/5/3.
//  Copyright © 2017年 fengshun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChildViewController : UIViewController

@property (nonatomic, strong) NSString *titleStr;
@property (nonatomic,strong) NSDictionary *dic;//风力
@property (nonatomic,copy) NSString *fenString;//氛围
@property (nonatomic,strong) NSDictionary *weatherDic;//天气
@property (nonatomic,strong) NSDictionary *controlDic;//控制字典
@property (nonatomic,strong) NSDictionary *deviceDic;//设备字典
@property (nonatomic,copy) NSString *oneKey;//一键设定2 
@property (nonatomic,strong) NSDictionary *notiDic;//收到的消息
@end
