//
//  GSJAddEquipmentViewController.h
//  AirMedic
//
//  Created by kaka on 2019/8/8.
//  Copyright © 2019 gsj. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GSJAddEquipmentViewController : BaseViewController
@property (nonatomic,copy) NSString *login;//2表示是登录进来的
@end

NS_ASSUME_NONNULL_END
