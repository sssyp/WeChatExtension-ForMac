//
//  GSJDeviceListTableViewCell.h
//  AirMedic
//
//  Created by kaka on 2019/8/8.
//  Copyright © 2019 gsj. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GSJDeviceListTableViewCell : UITableViewCell
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,strong) UILabel *topLabel;
@property (nonatomic,strong) UILabel *middleLabel;
@property (nonatomic,strong) UILabel *downLabel;
@property (nonatomic,strong) UIImageView *headImage;
@property (nonatomic,strong) UIImageView *topImage;
@property (nonatomic,strong) UIImageView *middleImage;
@property (nonatomic,strong) UIImageView *downImage;
@property (nonatomic,strong) UITextField *nameField;
@property (nonatomic,strong) UILabel *decLable;
@property (nonatomic,strong) UIImageView *jianView;


@end

NS_ASSUME_NONNULL_END
