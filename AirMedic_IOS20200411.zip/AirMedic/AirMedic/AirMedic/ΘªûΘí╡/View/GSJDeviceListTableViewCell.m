//
//  GSJDeviceListTableViewCell.m
//  AirMedic
//
//  Created by kaka on 2019/8/8.
//  Copyright © 2019 gsj. All rights reserved.
//

#import "GSJDeviceListTableViewCell.h"

@implementation GSJDeviceListTableViewCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _nameLabel = [[UILabel alloc]init];
        [self addSubview:_nameLabel];
        [_nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(140);
            make.top.equalTo(self).offset(0);
            make.width.mas_equalTo(100);
            make.height.mas_equalTo(100);
        }];
        _nameLabel.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
        _nameLabel.font = [UIFont systemFontOfSize:14];
        _nameLabel.numberOfLines = 0;
        
        _nameField = [[UITextField alloc]init];
        [self addSubview:_nameField];
        [_nameField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(140);
            make.top.equalTo(self).offset(0);
            make.width.mas_equalTo(ATGetDeviceWidth-140);
            make.height.mas_equalTo(100);
        }];
        _nameField.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0];
        _nameField.textAlignment = NSTextAlignmentLeft;
        _nameField.font = [UIFont systemFontOfSize:14];
        _nameField.hidden = YES;
        
        
        
        _decLable = [[UILabel alloc]init];
        [self addSubview:_decLable];
        [_decLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(140);
            make.top.equalTo(self).offset(0);
            make.width.mas_equalTo(160);
            make.height.mas_equalTo(100);
        }];
        _decLable.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0];
        _decLable.textAlignment = NSTextAlignmentCenter;
        _decLable.font = [UIFont systemFontOfSize:14];
        _decLable.hidden = YES;
        _decLable.numberOfLines = 0;
        
        _jianView = [[UIImageView alloc]init];
        [self addSubview:_jianView];
        [_jianView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-10);
            make.top.equalTo(self).offset(43);
            make.width.mas_equalTo(13);
            make.height.mas_equalTo(13);
        }];
        _jianView.image = [UIImage imageNamed:@"icon-jiantou"];
        _jianView.hidden =YES;
        
        
        _headImage = [[UIImageView alloc]init];
        [self addSubview:_headImage];
        [_headImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).offset(15);
            make.top.equalTo(self).offset(10);
            make.width.mas_equalTo(120);
            make.height.mas_equalTo(80);
        }];
        _headImage.image = [UIImage imageNamed:@"设备列表图 默认图5.111"];
        
        
        _topImage = [[UIImageView alloc]init];
        [self addSubview:_topImage];
        [_topImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-60);
            make.top.equalTo(self).offset(20);
            make.width.mas_equalTo(15);
            make.height.mas_equalTo(15);
        }];
        
        _middleImage = [[UIImageView alloc]init];
        [self addSubview:_middleImage];
        [_middleImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-60);
            make.top.equalTo(self).offset(20+25);
            make.width.mas_equalTo(15);
            make.height.mas_equalTo(15);
        }];
        
        _downImage = [[UIImageView alloc]init];
        [self addSubview:_downImage];
        [_downImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-60);
            make.top.equalTo(self).offset(20+50);
            make.width.mas_equalTo(15);
            make.height.mas_equalTo(15);
        }];
        
        _topLabel = [[UILabel alloc]init];
        [self addSubview:_topLabel];
        [_topLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-10);
            make.top.equalTo(self).offset(20);
            make.width.mas_equalTo(40);
            make.height.mas_equalTo(15);
        }];
        _topLabel.font = [UIFont systemFontOfSize:14];
        
        _middleLabel = [[UILabel alloc]init];
        [self addSubview:_middleLabel];
        [_middleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-10);
            make.top.equalTo(self).offset(20+25);
            make.width.mas_equalTo(40);
            make.height.mas_equalTo(15);
        }];
        _middleLabel.font = [UIFont systemFontOfSize:14];

        
        _downLabel = [[UILabel alloc]init];
        [self addSubview:_downLabel];
        [_downLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self).offset(-10);
            make.top.equalTo(self).offset(20+50);
            make.width.mas_equalTo(40);
            make.height.mas_equalTo(15);
        }];
        _downLabel.font = [UIFont systemFontOfSize:14];

        //        _headImage.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1.0];
        //        _headImage.textAlignment = NSTextAlignmentRight;
        //        _headImage.font = [UIFont systemFontOfSize:14];
        
        
    }
    return self;
}

@end
